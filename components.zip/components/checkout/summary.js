import LineItem from "@/components/layout/cart/line-item";
import ShippingCostsNewCustomer from "@/components/layout/cart/shipping-costs-new-customer";
import Link from "next/link";
import { NumericFormat } from "react-number-format";
import { useDispatch } from "react-redux";

const CheckoutSummary = ({ active, isNewCustomer, swCart, snippets }) => {
  const dispatch = useDispatch();
  return (
    <>
      <div className="headline-small">
        {snippets.next.checkout.summary.title}
      </div>
      <div className="mt-4 rounded-lg border border-gray-200 bg-white px-1 md:px-4">
        <h3 className="sr-only">Items in your cart</h3>

        {swCart && swCart.lineItems && swCart.lineItems.length > 0 ? (
          <>
            <ul className={"px-4"}>
              {swCart.lineItems.map((product) => (
                <LineItem
                  key={product.id}
                  product={product}
                  dispatch={dispatch}
                  snippets={snippets}
                />
              ))}
            </ul>

            <dl className="space-y-6 border-t border-gray-200 px-4 py-6 sm:px-6">
              <div className="flex items-center justify-between">
                <dt className="text-sm">
                  {snippets.next.checkout.summary.subtotal}
                </dt>
                <dd className="text-sm font-medium text-neutral-900">
                  <NumericFormat
                    value={swCart.price.positionPrice}
                    decimalSeparator=","
                    decimalScale="2"
                    fixedDecimalScale="true"
                    displayType={"text"}
                    thousandSeparator="."
                    suffix={" €"}
                  />{" "}
                  *
                </dd>
              </div>
              {swCart.deliveries.map((delivery) => (
                <div
                  key={delivery.shippingMethod.id}
                  className="flex items-center justify-between"
                >
                  <dt className="text-sm">{delivery.shippingMethod.name}</dt>
                  <dd className="text-sm font-medium text-neutral-900">
                    <NumericFormat
                      value={delivery.shippingCosts.unitPrice}
                      decimalSeparator=","
                      decimalScale="2"
                      fixedDecimalScale="true"
                      displayType={"text"}
                      thousandSeparator="."
                      suffix={" €"}
                    />{" "}
                    *
                  </dd>
                </div>
              ))}
              <div className="flex items-center justify-between border-t border-gray-200 pt-6">
                <dt className="text-base font-bold">
                  {snippets.next.checkout.summary.total}
                </dt>
                <dd className="text-base font-bold text-neutral-900">
                  <NumericFormat
                    value={swCart.price.totalPrice}
                    decimalSeparator=","
                    decimalScale="2"
                    fixedDecimalScale="true"
                    displayType={"text"}
                    thousandSeparator="."
                    suffix={" €"}
                  />{" "}
                  *
                </dd>
              </div>
            </dl>

            {isNewCustomer && <ShippingCostsNewCustomer />}

            <p className={"body-extra-small px-5 text-base-50 text-center"}>
              {snippets.next.checkout.summary.legalText}
              <Link
                href={snippets.next.checkout.summary.legal.link1Url}
                target={"_blank"}
                className={"text-link"}
              >
                {snippets.next.checkout.summary.legal.link1}
              </Link>
              ,{" "}
              <Link
                href={snippets.next.checkout.summary.legal.link2Url}
                target={"_blank"}
                className={"text-link"}
              >
                {snippets.next.checkout.summary.legal.link2}
              </Link>{" "}
            </p>

            <div className="px-4 py-4 sm:px-6">
              <button
                type="submit"
                className="w-full btn-primary"
                disabled={!active}
              >
                <svg
                  className="animate-spin -ml-1 mr-3 h-5 w-5 text-white"
                  xmlns="http://www.w3.org/2000/svg"
                  fill="none"
                  viewBox="0 0 24 24"
                >
                  <circle
                    className="opacity-25"
                    cx="12"
                    cy="12"
                    r="10"
                    stroke="currentColor"
                    strokeWidth="4"
                  ></circle>
                  <path
                    className="opacity-75"
                    fill="currentColor"
                    d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                  ></path>
                </svg>
                <span>{snippets.next.checkout.summary.orderButton}</span>
              </button>
              <p
                className={
                  "body-extra-small px-5 text-base-300 text-center mt-2"
                }
              >
                {snippets.next.checkout.summary.orderInfo}
              </p>
            </div>
            <p className={"body-extra-small text-base-300 text-center pb-2"}>
              {snippets.next.checkout.summary.lastInfo}
            </p>
          </>
        ) : (
          <div className={"text-center p-4"}>
            <div className="body-small-emphasis mb-2">
              {snippets.next.checkout.summary.cartEmpty}
            </div>
            <Link
              href={"/"}
              target={"_self"}
              className={"btn-primary btn-small"}
            >
              {snippets.next.checkout.summary.cartEmptyButton}
            </Link>
          </div>
        )}
      </div>
    </>
  );
};

export default CheckoutSummary;

"use client";

import {
  setNotificationMessage,
  setNotificationSuccess,
  setShowNotifications,
} from "@/redux/notifications/notifications";
import cookie from "js-cookie";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { useDispatch, useSelector } from "react-redux";

import FormdataHelper from "@/helper/formdata.helper";
import axiosInstance from "@/shopware/client";
import * as gtag from "@/utility/gtag";
//import {fbEvent} from "@netzkombyse/facebook-conversion-api-nextjs";
import CheckoutAddress from "@/components/checkout/address";
import CheckoutSummary from "@/components/checkout/summary";

const CheckoutForm = ({
  paymentMethods,
  shippingMethods,
  countries,
  salutations,
  snippets,
}) => {
  const [active, setActive] = useState(true);
  const [isNewCustomer, setIsNewCustomer] = useState(true);
  const dispatch = useDispatch();
  const swCart = useSelector((state) => state.cart.swCart);
  const [useBillingAddress, setUseBillingAddress] = useState(true);

  const router = useRouter();

  if (swCart && swCart.lineItems && swCart.lineItems.length > 0) {
    /*
    fbEvent({
      eventName: 'InitiateCheckout',
      currency: 'EUR',
      value: swCart.price.totalPrice,
      numItems: swCart.lineItems.length,
      products: swCart.lineItems.map((product) => (
          {
            sku: product.payload.productNumber,
            quantity: product.quantity,
          }
      )),
      enableStandardPixel: true,
      testEventCode: process.env.NEXT_PUBLIC_FB_TEST_EVENT_CODE
    });
    */
  }

  /* handle register */
  async function handleRegister(event) {
    event.preventDefault();

    /*
    fbEvent({
      eventName: 'Purchase',
      currency: 'EUR',
      value: swCart.price.totalPrice,
      numItems: swCart.lineItems.length,
      products: swCart.lineItems.map((product) => (
          {
            sku: product.payload.productNumber,
            quantity: product.quantity,
          }
      )),
      enableStandardPixel: true,
      testEventCode: process.env.NEXT_PUBLIC_FB_TEST_EVENT_CODE
    });*/

    setActive(false);

    const formData = FormdataHelper.FormDataObject(event.target);
    if (useBillingAddress) {
      delete formData.shippingAddress;
    }
    formData.storefrontUrl = process.env.NEXT_PUBLIC_SW_APP_URL;
    formData.guest = true;
    formData.acceptedDataProtection = true;

    axiosInstance.defaults.headers["sw-context-token"] =
      cookie.get("cartToken");
    await axiosInstance
      .post("/account/register", formData)
      .then((res) => {
        //set new context token
        cookie.set("orderToken", res.headers["sw-context-token"], {
          expires: 365, // days
          path: "/",
          sameSite: "lax",
        });
        createOrder();
      })
      .catch((error) => {
        console.log(error.response.data.errors);
        let errorMessage = "";
        if (
          error.response.data.errors[0].code === "VIOLATION::IS_BLANK_ERROR"
        ) {
          errorMessage = "Bitte füllen Sie alle Pflichtfelder aus.";
        } else {
          errorMessage =
            "Es ist ein Fehler aufgetreten. Bitte versuchen Sie es erneut.";
        }

        dispatch(setNotificationMessage(errorMessage));
        dispatch(setNotificationSuccess(false));
        dispatch(setShowNotifications(true));

        setTimeout(() => {
          dispatch(setShowNotifications(false));
        }, 5000);
      });
  }

  /* create order */
  async function createOrder() {
    axiosInstance.defaults.headers["sw-context-token"] =
      cookie.get("orderToken");

    let lineItems = [];

    swCart.lineItems.map((item) => {
      lineItems.push({
        id: item.payload.productNumber,
        name: item.label,
        brand: process.env.NEXT_PUBLIC_BRAND_NAME,
        price: item.price.unitPrice,
        quantity: item.quantity,
      });
    });
    gtag.dataLayer({ ecommerce: null });
    gtag.dataLayer({
      event: "purchase",
      ecommerce: {
        purchase: {
          currency: "EUR",
          value: swCart.price.totalPrice,
          products: lineItems,
        },
      },
    });

    await axiosInstance
      .post("/checkout/order", {})
      .then((res) => {
        initiatePayment(res.data.id);
      })
      .catch((error) => {
        console.log(error.response.data.errors);
        let errorMessage = "";
        if (
          error.response.data.errors[0].code === "VIOLATION::IS_BLANK_ERROR"
        ) {
          errorMessage = "Bitte füllen Sie alle Pflichtfelder aus.";
        } else {
          errorMessage =
            "Es ist ein Fehler aufgetreten. Bitte versuchen Sie es erneut.";
        }

        dispatch(setNotificationMessage(errorMessage));
        dispatch(setNotificationSuccess(false));
        dispatch(setShowNotifications(true));

        setTimeout(() => {
          dispatch(setShowNotifications(false));
        }, 5000);
      });
  }

  /* initiate payment */
  async function initiatePayment(orderId) {
    axiosInstance.defaults.headers["sw-context-token"] =
      cookie.get("orderToken");
    await axiosInstance
      .post("/handle-payment", {
        orderId: orderId,
        finishUrl:
          process.env.NEXT_PUBLIC_CHECKOUT_FINISH_URL +
          "?id=" +
          orderId +
          "&success",
        errorUrl:
          process.env.NEXT_PUBLIC_CHECKOUT_ERROR_URL +
          "?id=" +
          orderId +
          "&error",
      })
      .then((res) => {
        if (res.data.redirectUrl) {
          router.push(res.data.redirectUrl);
        } else {
          router.push("/checkout/success?id=" + orderId + "&success");
        }
      })
      .catch((error) => {
        let errorMessage = "";
        if (
          error.response.data.errors[0].code === "VIOLATION::IS_BLANK_ERROR"
        ) {
          errorMessage = "Bitte füllen Sie alle Pflichtfelder aus.";
        } else {
          errorMessage =
            "Es ist ein Fehler aufgetreten. Bitte versuchen Sie es erneut.";
        }

        dispatch(setNotificationMessage(errorMessage));
        dispatch(setNotificationSuccess(false));
        dispatch(setShowNotifications(true));

        setTimeout(() => {
          dispatch(setShowNotifications(false));
        }, 5000);
      });
  }

  return (
    <>
      <main className={"mx-auto max-w-7xl px-6 md:px-12 xl:px-0 my-12"}>
        <form onSubmit={handleRegister}>
          <div className="relative lg:flex lg:space-x-12 p-0">
            {swCart &&
              paymentMethods &&
              shippingMethods &&
              countries &&
              salutations && (
                <div className={"w-full lg:w-6/12"}>
                  <CheckoutAddress
                    useBillingAddress={useBillingAddress}
                    setUseBillingAddress={setUseBillingAddress}
                    paymentMethods={paymentMethods}
                    shippingMethods={shippingMethods}
                    countries={countries}
                    salutations={salutations}
                    setIsNewCustomer={setIsNewCustomer}
                    swCart={swCart}
                    snippets={snippets}
                  />
                </div>
              )}

            {swCart && (
              <aside className="lg:sticky top-0 w-full lg:w-6/12 justify-center">
                <CheckoutSummary
                  active={active}
                  isNewCustomer={isNewCustomer}
                  swCart={swCart}
                  snippets={snippets}
                />
              </aside>
            )}
          </div>
        </form>
      </main>
    </>
  );
};

export default CheckoutForm;

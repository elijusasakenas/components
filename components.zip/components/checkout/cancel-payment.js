"use client";

import { fetchClient } from "@/utility/fetch-client";
import { useRouter, useSearchParams } from "next/navigation";
import { useState } from "react";
import useSWR from "swr";
import { SelectPayment } from "./select-payment";

const CancelPayment = ({ paymentMethods }) => {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState(null);

  const { data, error } = useSWR(
    {
      path: "order",
      method: "POST",
      body: {
        filter: [
          {
            type: "equals",
            field: "id",
            value: searchParams.get("id"),
          },
        ],
        associations: {
          lineItems: [],
          deliveries: [],
        },
      },
    },
    fetchClient
  );

  if (error) console.log(error);
  if (!data) return null;

  if (data.orders.total === 0) router.push("/checkout/empty");

  return (
    <div className="mt-10 border-t border-gray-200 pt-10 max-w-7xl mx-auto">
      <SelectPayment
        selectedPaymentMethod={selectedPaymentMethod}
        setSelectedPaymentMethod={setSelectedPaymentMethod}
        paymentMethods={paymentMethods}
        orderId={data.orders.elements[0].id}
      />
    </div>
  );
};

export default CancelPayment;

import { fetchClient } from "@/utility/fetch-client";
import {
  Card,
  CardContent,
  CardHeader,
  FormControl,
  FormControlLabel,
  Radio,
  RadioGroup,
} from "@mui/material";
import { NumericFormat } from "react-number-format";

export const SelectDelivery = ({
  selectedDeliveryMethod,
  setSelectedDeliveryMethod,
  deliveryMethods,
}) => {
  return (
    <FormControl className="w-full">
      <RadioGroup
        sx={{
          display: "grid",
        }}
        className="md:grid-cols-3 gap-4"
        aria-labelledby="deliveries-radio-buttons-group-label"
        name="deliveries-radio-buttons-group"
        value={selectedDeliveryMethod}
        onChange={(event) =>
          changeDeliveryMethod(event.target.value, setSelectedDeliveryMethod)
        }
      >
        {deliveryMethods.map((deliveryMethod) => (
          <FormControlLabel
            sx={{ margin: 0, alignItems: "stretch", width: "100%" }}
            key={deliveryMethod.id}
            value={deliveryMethod.id}
            className={"body-extra-small"}
            control={
              <DeliveryRadio
                label={deliveryMethod.translated.name}
                description={deliveryMethod.translated.description}
                price={deliveryMethod.prices[0].currencyPrice[0].gross}
              />
            }
          />
        ))}
      </RadioGroup>
    </FormControl>
  );
};

const DeliveryRadio = (props) => {
  return (
    <Card sx={{ width: "100%" }}>
      <CardHeader
        action={<Radio {...props} />}
        title={props.label}
        classes={{ title: "body-extra-small" }}
        subheader={
          <NumericFormat
            value={props.price}
            decimalSeparator=","
            decimalScale="2"
            fixedDecimalScale="true"
            displayType={"text"}
            thousandSeparator="."
            suffix={" €"}
          />
        }
      ></CardHeader>
      <CardContent>{props.description}</CardContent>
    </Card>
  );
};

function changeDeliveryMethod(shippingMethodId, setSelectedDeliveryMethod) {
  fetchClient({
    path: "context",
    method: "PATCH",
    body: { shippingMethodId: shippingMethodId },
  });

  setSelectedDeliveryMethod(shippingMethodId);
}

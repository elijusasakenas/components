import { useEffect } from 'react';

const useUpdateShippingAddress = (setShippingAddressFirstName, setShippingAddressLastName, setShippingAddressAdditionalAddressLine1) => {
    useEffect(() => {
        const handleInputChange = () => {
            const firstName = document.getElementById("firstName").value;
            const lastName = document.getElementById("lastName").value;
            const additionalAddressLine1 = `Kommission ${firstName} ${lastName}`;
            setShippingAddressFirstName(firstName);
            setShippingAddressLastName(lastName);
            setShippingAddressAdditionalAddressLine1(additionalAddressLine1);
        };

        const firstNameInput = document.getElementById("firstName");
        const lastNameInput = document.getElementById("lastName");

        if (firstNameInput && lastNameInput) {
            firstNameInput.addEventListener('input', handleInputChange);
            lastNameInput.addEventListener('input', handleInputChange);
        }

        return () => {
            if (firstNameInput && lastNameInput) {
                firstNameInput.removeEventListener('input', handleInputChange);
                lastNameInput.removeEventListener('input', handleInputChange);
            }
        };
    }, [setShippingAddressFirstName, setShippingAddressLastName, setShippingAddressAdditionalAddressLine1]);
};

export default useUpdateShippingAddress;
import { fetchClient } from "@/utility/fetch-client";
import {
  Card,
  CardContent,
  CardHeader,
  FormControl,
  FormControlLabel,
  Radio,
  RadioGroup,
} from "@mui/material";
import { useRouter } from "next/navigation";

export const SelectPayment = ({ selectedPaymentMethod, setSelectedPaymentMethod, paymentMethods, orderId }) => {
  const router = useRouter();

  return (
    <FormControl className="w-full">
      <RadioGroup
        sx={{
          display: "grid",
        }}
        className="md:grid-cols-3 gap-4"
        aria-labelledby="payments-radio-buttons-group-label"
        name="payments-radio-buttons-group"
        value={selectedPaymentMethod}
        onChange={
          orderId ? 
          (event) => handlePaymentSelection(event.target.value, setSelectedPaymentMethod, orderId, router) :
          (event) => changePaymentMethod(event.target.value, setSelectedPaymentMethod)}
      >
        {paymentMethods.map((paymentMethod) => (
          <FormControlLabel
            sx={{ margin: 0, alignItems: "stretch", width: "100%" }}
            key={paymentMethod.id}
            value={paymentMethod.id}
            className={"body-extra-small"}
            control={
              <PaymentRadio
                label={paymentMethod.translated.name}
                description={paymentMethod.translated.description}
                image={paymentMethod.media?.url}
              />
            }
          />
        ))}
      </RadioGroup>
    </FormControl>
  );
};

const PaymentRadio = (props) => {
  return (
    <Card sx={{ width: "100%" }}>
      <CardHeader
        action={<Radio {...props} />}
        title={props.label}
      ></CardHeader>
      {props.description && <CardContent>{props.description}</CardContent>}
    </Card>
  );
};

function changePaymentMethod(paymentMethodId, setSelectedPaymentMethod) {
  fetchClient({
    path: "context",
    method: "PATCH",
    body: { paymentMethodId: paymentMethodId },
  });

  setSelectedPaymentMethod(paymentMethodId);
}

const handlePaymentSelection = async (paymentMethodId, setSelectedPaymentMethod, orderId, router) => {
  setSelectedPaymentMethod(paymentMethodId);
  await updatePaymentMethod(paymentMethodId, orderId);
  const paymentData = await initiatePayment(orderId);
  if(paymentData.redirectUrl) router.push(paymentData.redirectUrl)
}

const updatePaymentMethod = async (paymentMethodId, orderId) => {
  await fetchClient({
    path: "order/payment", 
    method: "POST",
    body: {
      paymentMethodId: paymentMethodId,
      orderId: orderId,
    }
  })
}

const initiatePayment = async (orderId) => {
  const data = await fetchClient({
    path: "handle-payment",
    method: "POST",
    body: {
      orderId: orderId,
      finishUrl: process.env.NEXT_PUBLIC_CHECKOUT_FINISH_URL + "?id=" + orderId + "&success",
      errorUrl: process.env.NEXT_PUBLIC_CHECKOUT_ERROR_URL + "?id=" + orderId + "&error",
    }
  })

  return data
}
"use client";

import { fetchClient } from "@/utility/fetch-client";
import { useRouter, useSearchParams } from "next/navigation";
import useSWR from "swr";
import LineItem from "../layout/cart/line-item";

const SuccessList = () => {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { data, error } = useSWR(
    {
      path: "order",
      method: "POST",
      body: {
        fields: ["id", "lineItems", "deliveries", "cover", "price"],
        filter: [
          {
            type: "equals",
            field: "id",
            value: searchParams.get("id"),
          },
        ],
        associations: {
          lineItems: [],
          deliveries: [],
        },
      },
    },
    fetchClient
  );

  if (error) console.log(error);
  if (!data) return null;

  if (data.orders.total === 0) router.push("/checkout/empty");

  const order = data.orders.elements[0];

  /*
  const order = data.orders.elements[0];
  order.lineItems.forEach((item) => {
    if (item.type === "product") {
      push([
        "addEcommerceItem",
        item.payload.productNumber,
        item.label,
        "",
        item.unitPrice,
        item.quantity,
      ]);
    }
  });
  push(["trackEcommerceOrder", order.orderNumber, order.price.totalPrice]);*/

  return (
    order && (
      <ul className={"px-4"}>
        {order.lineItems.map((product) => (
          <LineItem key={product.id} product={product} />
        ))}
      </ul>
    )
  );
};

export default SuccessList;
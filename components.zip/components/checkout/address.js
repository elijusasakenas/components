import { setLoading } from "@/redux/loading/loading";
import axiosInstance from "@/shopware/client";
import useUpdateShippingAddress from "./UdateShippingAddress";

import StoreLocatorSelect from "@/components/StoreLocator/StoreLocatorSelect";
import CheckMarkIcon from "@/icons/check-mark";
import {
  CheckCircleIcon,
  ExclamationTriangleIcon,
  XCircleIcon,
  XMarkIcon,
} from "@heroicons/react/20/solid";
import {
  Checkbox,
  Collapse,
  FormControl,
  FormControlLabel,
  InputLabel,
  MenuItem,
  Select,
  TextField,
} from "@mui/material";
import { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { SelectDelivery } from "./select-delivery";
import { SelectPayment } from "./select-payment";

const CheckoutAddress = ({
  useBillingAddress,
  setUseBillingAddress,
  paymentMethods,
  shippingMethods,
  countries,
  salutations,
  setIsNewCustomer,
  swCart,
  snippets,
}) => {
  const dispatch = useDispatch();

  const deliveryMethods = shippingMethods;

  /* salutation */
  const [selectedSalutation, setSelectedSalutation] = useState(null);

  const [shippingAddressCompany, setShippingAddressCompany] = useState("");
  const [shippingAddressFirstName, setShippingAddressFirstName] = useState("");
  const [shippingAddressLastName, setShippingAddressLastName] = useState("");
  const [shippingAddressStreet, setShippingAddressStreet] = useState("");
  const [
    shippingAddressAdditionalAddressLine1,
    setShippingAddressAdditionalAddressLine1,
  ] = useState("");
  const [shippingAddressZipcode, setShippingAddressZipcode] = useState("");
  const [shippingAddressCity, setShippingAddressCity] = useState("");

  // Use the custom hook to update shipping address
  useUpdateShippingAddress(
    setShippingAddressFirstName,
    setShippingAddressLastName,
    setShippingAddressAdditionalAddressLine1
  );

  /* street number validation */
  const [streetNumberValid, setStreetNumberValid] = useState(true);
  const validateStreetField = (event, value) => {
    event.preventDefault();
    const valueMatch = value.match(/[0-9]/gi);
    if (!valueMatch) {
      setStreetNumberValid(false);
    } else {
      setStreetNumberValid(true);
    }
  };

  /* billing address */
  //const [useBillingAddress, setUseBillingAddress] = useState(true);
  const [selectedBillingCountry, setSelectedBillingCountry] = useState(null);
  /*  is new Customer */

  /* shipping address */
  const [selectedShippingSalutation, setSelectedShippingSalutation] =
    useState(null);
  const [selectedShippingCountry, setSelectedShippingCountry] = useState(null);
  function handleShippingAddress() {
    setUseBillingAddress(!useBillingAddress);
  }

  /* delivery */
  const [selectedDeliveryMethod, setSelectedDeliveryMethod] = useState(null);

  /* payment */
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState(null);

  const [selectedShippingTo, setSelectedShippingTo] = useState("customer");
  const [selectedStore, setSelectedStore] = useState(null);

  /* check for real new customer */
  const checkRealNewCustomer = async function (event) {
    const valid = String(event.target.value)
      .toLowerCase()
      .match(
        /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|.(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
      );
    if (valid) {
      await axiosInstance
        .post("/netzkom/custom/is-real-new-customer/", {
          email: event.target.value,
        })
        .then((res) => {
          //set default delivery method
          let cartDeliveryMethod = deliveryMethods.find(
            (method) =>
              !method.customFields.hasOwnProperty(
                "custom_netzkom_promotion_new-customer"
              ) ||
              method.customFields["custom_netzkom_promotion_new-customer"] ===
                false
          );

          if (res.data.result.customerId) {
            setIsNewCustomer(false);
          } else {
            setIsNewCustomer(false);
            //set promo delivery method
            cartDeliveryMethod = deliveryMethods.find(
              (method) =>
                method.customFields["custom_netzkom_promotion_new-customer"] ===
                true
            );
          }
          // set delivery method
          setSelectedDeliveryMethod(cartDeliveryMethod);
        });
    }
  };
  function compare(a, b) {
    if (a.position < b.position) {
      return -1;
    }
    if (a.position > b.position) {
      return 1;
    }
    return 0;
  }

  paymentMethods.sort(compare);

  /* apple pay */
  const [applePayMethod, setApplePayMethod] = useState(false);

  useEffect(() => {
    if (window.ApplePaySession) {
      setApplePayMethod(true);
    }
    if (
      swCart &&
      swCart.lineItems &&
      deliveryMethods &&
      paymentMethods &&
      countries &&
      salutations
    ) {
      if (swCart.lineItems.length !== 0) {
        const cartDeliveryMethod = deliveryMethods.find(
          (method) => method.id === swCart.deliveries[0].shippingMethod.id
        );
        const cartPaymentMethod = paymentMethods.find(
          (method) => method.id === swCart.transactions[0].paymentMethodId
        );
        setSelectedDeliveryMethod(cartDeliveryMethod.id);
        setSelectedPaymentMethod(cartPaymentMethod.id);
        setSelectedSalutation(
          selectedSalutation ? selectedSalutation : salutations[0].id
        );
        setSelectedShippingSalutation(
          selectedShippingSalutation
            ? selectedShippingSalutation
            : salutations[0].id
        );
        setSelectedBillingCountry(
          selectedBillingCountry ? selectedBillingCountry : countries[0].id
        );
        setSelectedShippingCountry(
          selectedShippingCountry ? selectedShippingCountry : countries[0].id
        );

        dispatch(setLoading(false));
      }
    }
  }, [
    swCart,
    deliveryMethods,
    paymentMethods,
    countries,
    salutations,
    selectedSalutation,
    selectedShippingSalutation,
    selectedBillingCountry,
    selectedShippingCountry,
    dispatch,
  ]);

  const onSelectStoreLocation = (store) => {
    setSelectedStore(store);
    setSelectedShippingSalutation("018d598517d571ba91c5c8c65bd866d8");
    setSelectedShippingCountry("018d598517d571ba91c5c8c65cb95094");

    setShippingAddressCompany(store.name || "");
    setShippingAddressFirstName(
      `${document.getElementById("firstName").value}`
    );
    setShippingAddressLastName(`${document.getElementById("lastName").value}`);
    setShippingAddressStreet(store.address_line_1 || "");
    setShippingAddressAdditionalAddressLine1(
      `Kommission ${document.getElementById("firstName").value} ${
        document.getElementById("lastName").value
      }` || ""
    );
    setShippingAddressZipcode(store.postcode || "");
    setShippingAddressCity(store.city || "");
  };

  const onSelectShippingTo = (shippingTo) => {
    setSelectedShippingTo(shippingTo);
    shippingTo === "store"
      ? setUseBillingAddress(false)
      : setUseBillingAddress(true);
  };

  return (
    <>
      {/* e-Mail / Phone */}
      <div>
        <div className="headline-small">
          {snippets.next.checkout.address.contact.title}
        </div>

        <div className="mt-4">
          <TextField
            sx={{
              "& .MuiOutlinedInput-input:focus": {
                boxShadow: "none",
              },
            }}
            error={false}
            helperText=""
            label={snippets.next.checkout.address.contact.mail}
            type="email"
            id="email"
            name="email"
            required={true}
            fullWidth
            size="small"
          />
        </div>

        <div className="mt-4">
          <TextField
            sx={{
              "& .MuiOutlinedInput-input:focus": {
                boxShadow: "none",
              },
            }}
            error={false}
            helperText=""
            label={snippets.next.checkout.address.contact.mobile}
            type="tel"
            id="billingAddressPhoneNumber"
            name="billingAddress[phoneNumber]"
            fullWidth
            size="small"
          />
        </div>
        <div className={"body-extra-small text-base-300 mt-1"}>
          {snippets.next.checkout.address.contact.mobileInfo}
        </div>
      </div>

      {/* Billing Address */}
      <div className="mt-10 border-t border-gray-200 pt-10">
        <div className="headline-small">
          {snippets.next.checkout.address.billingAddress.title}
        </div>

        <div className="mt-4 grid grid-cols-1 gap-y-6 sm:grid-cols-2 sm:gap-x-4">
          <div className={"col-span-2"}>
            <div className="mt-1">
              <FormControl
                sx={{ m: 0, minWidth: "100%" }}
                size="small"
                className="bg-white"
              >
                <InputLabel id="demo-select-small-label">
                  {snippets.next.checkout.address.billingAddress.salutation}
                </InputLabel>
                <Select
                  labelId="salutationId-label"
                  id="salutationId"
                  name="salutationId"
                  value={selectedSalutation ? selectedSalutation : ""}
                  label={
                    snippets.next.checkout.address.billingAddress.salutation
                  }
                  onChange={(event) =>
                    setSelectedSalutation(event.target.value)
                  }
                >
                  {salutations.map((salutation) => (
                    <MenuItem key={salutation.id} value={salutation.id}>
                      {salutation.translated.displayName}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </div>
          </div>
          <div className={"col-span-2 sm:col-span-1"}>
            <TextField
              sx={{
                "& .MuiOutlinedInput-input:focus": {
                  boxShadow: "none",
                },
              }}
              error={false}
              helperText=""
              label={snippets.next.checkout.address.billingAddress.firstName}
              type="text"
              id="firstName"
              name="firstName"
              required
              fullWidth
              size="small"
            />
          </div>

          <div className={"col-span-2 sm:col-span-1"}>
            <TextField
              sx={{
                "& .MuiOutlinedInput-input:focus": {
                  boxShadow: "none",
                },
              }}
              error={false}
              helperText=""
              label={snippets.next.checkout.address.billingAddress.lastName}
              type="text"
              id="lastName"
              name="lastName"
              required
              fullWidth
              size="small"
            />
          </div>

          <div className={"col-span-2"}>
            <TextField
              sx={{
                "& .MuiOutlinedInput-input:focus": {
                  boxShadow: "none",
                },
              }}
              error={false}
              helperText=""
              label={snippets.next.checkout.address.billingAddress.streetNumber}
              type="text"
              id="billingAddressAddressStreet"
              name="billingAddress[street]"
              required
              onBlur={(event) => validateStreetField(event, event.target.value)}
              fullWidth
              size="small"
            />
            {streetNumberValid ? null : (
              <div className="rounded-md border border-yellow-400 bg-yellow-50 p-2 px-4 mt-2">
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <ExclamationTriangleIcon
                      className="h-6 w-6 text-yellow-400"
                      aria-hidden="true"
                    />
                  </div>
                  <div className="ml-3">
                    <p className="text-sm font-medium text-yellow-700">
                      {
                        snippets.next.checkout.address.billingAddress
                          .streetNumberForget
                      }
                    </p>
                  </div>
                  <div className="ml-auto pl-3">
                    <div className="-mx-1.5 -my-1.5">
                      <button
                        type="button"
                        className="inline-flex rounded-md border border-yellow-400 bg-base-500 p-1.5 text-yellow-700 hover:bg-yellow-400 hover:text-base-50 focus:outline-none focus:ring-2 focus:ring-green-600 focus:ring-offset-2 focus:ring-offset-green-50"
                        onClick={() => setStreetNumberValid(true)}
                      >
                        <span className="sr-only">Dismiss</span>
                        <XMarkIcon className="h-5 w-5" aria-hidden="true" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
          <div className={"col-span-2"}>
            <TextField
              sx={{
                "& .MuiOutlinedInput-input:focus": {
                  boxShadow: "none",
                },
              }}
              error={false}
              helperText=""
              label={snippets.next.checkout.address.billingAddress.additional}
              type="text"
              required={false}
              id="billingAddressAdditionalAddressLine1"
              name="billingAddress[additionalAddressLine1]"
              fullWidth
              size="small"
            />
          </div>
          <div className={"mr-2 sm:mr-0"}>
            <TextField
              sx={{
                "& .MuiOutlinedInput-input:focus": {
                  boxShadow: "none",
                },
              }}
              inputProps={{
                inputMode: "numeric",
                pattern: "[0-9]*",
                minLength: 5,
                maxLength: 5,
              }}
              error={false}
              helperText=""
              label={snippets.next.checkout.address.billingAddress.zipcode}
              type="text"
              required={true}
              id="billingAddressZipcode"
              name="billingAddress[zipcode]"
              fullWidth
              size="small"
            />
          </div>
          <div className={"col-span-1"}>
            <TextField
              sx={{
                "& .MuiOutlinedInput-input:focus": {
                  boxShadow: "none",
                },
              }}
              error={false}
              helperText=""
              label={snippets.next.checkout.address.billingAddress.city}
              type="text"
              required={true}
              id="billingAddressCity"
              name="billingAddress[city]"
              fullWidth
              size="small"
            />
          </div>

          {
            <div className={"col-span-2 sm:col-span-1"}>
              <FormControl
                sx={{ m: 0, minWidth: "100%" }}
                size="small"
                className="bg-white"
              >
                <InputLabel id="demo-select-small-label">
                  {snippets.next.checkout.address.billingAddress.land}
                </InputLabel>
                <Select
                  labelId="salutationId-label"
                  id="billingAddressCountryId"
                  name="billingAddress[countryId]"
                  value={selectedBillingCountry ? selectedBillingCountry : ""}
                  label={snippets.next.checkout.address.billingAddress.land}
                  onChange={(event) =>
                    setSelectedBillingCountry(event.target.value)
                  }
                >
                  {countries.map((country) => (
                    <MenuItem key={country.id} value={country.id}>
                      {country.translated.name}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </div>
          }
        </div>
      </div>

      {/* Shipping Address */}
      <div className="mt-10 border-t border-gray-200 pt-10">
        <div className="headline-small  mb-2 ">
          {snippets.next.checkout.address.shippingAddress.title}
        </div>
        <div className={"grid grid-cols-1 lg:grid-cols-2 gap-3"}>
          <div
            className={`overflow-hidden border rounded-lg bg-white shadow  hover:border-primary ${
              selectedShippingTo === "store"
                ? "border-gray-200"
                : "border-primary"
            } `}
            onClick={() => onSelectShippingTo("customer")}
          >
            <div className={"px-4 py-5 sm:p-6  cursor-pointer"}>
              <p className={"body-small-emphasis"}>
                {
                  snippets.next.checkout.address.shippingAddress.desiredLocation
                    .title
                }
              </p>
              <ul
                className={"body-small list-none list-outside body-extra-small"}
              >
                <li className={"flex gap-2 mt-2"}>
                  <CheckMarkIcon className="h-4 w-5 fill-base-50" />
                  <span>
                    {
                      snippets.next.checkout.address.shippingAddress
                        .desiredLocation.check1
                    }
                  </span>
                </li>
                <li className={"flex gap-2 mt-2"}>
                  <CheckMarkIcon className="h-4 w-5 fill-base-50" />
                  <span>
                    {
                      snippets.next.checkout.address.shippingAddress
                        .desiredLocation.check2
                    }
                  </span>
                </li>
              </ul>
            </div>
          </div>
          <div
            className={`overflow-hidden border rounded-lg bg-white shadow  hover:border-primary ${
              selectedShippingTo === "customer"
                ? "border-gray-200"
                : "border-primary"
            } `}
            onClick={() => onSelectShippingTo("store")}
          >
            <div className={"px-4 py-5 sm:p-6  cursor-pointer"}>
              <p className={"body-small-emphasis"}>
                {
                  snippets.next.checkout.address.shippingAddress.fromDealer
                    .title
                }
              </p>
              <ul
                className={"body-small list-none list-outside body-extra-small"}
              >
                <li className={"flex gap-2 mt-2"}>
                  <CheckMarkIcon className="h-4 w-5 fill-base-50" />
                  <span>
                    {
                      snippets.next.checkout.address.shippingAddress.fromDealer
                        .check1
                    }
                  </span>
                </li>
                <li className={"flex gap-2 mt-2"}>
                  <CheckMarkIcon className="h-4 w-5 fill-base-50" />
                  <span>
                    {
                      snippets.next.checkout.address.shippingAddress.fromDealer
                        .check2
                    }
                  </span>
                </li>
                <li className={"flex gap-2 mt-2"}>
                  <CheckMarkIcon className="h-4 w-5 fill-base-50" />
                  <span>
                    {
                      snippets.next.checkout.address.shippingAddress.fromDealer
                        .check3
                    }
                  </span>
                </li>
              </ul>
            </div>
          </div>
        </div>

        {/* storeLocator component */}
        {selectedShippingTo === "store" && (
          <StoreLocatorSelect
            onSelect={onSelectStoreLocation}
            snippets={snippets}
          />
        )}

        <div className="headline-small mt-4">
          {snippets.next.checkout.address.shippingAddress.title2}
          {selectedShippingTo === "customer" && (
            <FormControlLabel
              className={"float-right text-sm "}
              label={
                !useBillingAddress
                  ? snippets.next.checkout.address.shippingAddress
                      .isNotBillingAddress
                  : snippets.next.checkout.address.shippingAddress
                      .isBillingAddress
              }
              sx={{
                "& .MuiFormControlLabel-label": {
                  fontSize: "0.875rem",
                  color: "rgb(104, 115, 130); text-decoration: underline;",
                },
              }}
              labelPlacement="start"
              control={
                <Checkbox
                  icon={<XCircleIcon className={"h-5 w-5 text-gray-200"} />}
                  checkedIcon={
                    <CheckCircleIcon className={"h-5 w-5 text-orange-200"} />
                  }
                  checked={useBillingAddress}
                  onChange={handleShippingAddress}
                  inputProps={{ "aria-label": "controlled" }}
                />
              }
            />
          )}
        </div>
        {selectedShippingTo === "store" && (
          <p className="body-extra-small-emphasis mb-4">
            {snippets.next.checkout.address.shippingAddress.fromDealer.info}
          </p>
        )}
        <Collapse in={!useBillingAddress}>
          <div className="mt-4 grid grid-cols-1 gap-y-6 sm:grid-cols-2 sm:gap-x-4">
            <div className={"col-span-2"}>
              <div className="mt-1">
                <FormControl
                  sx={{ m: 0, minWidth: "100%" }}
                  size="small"
                  className="bg-white"
                >
                  <InputLabel id="demo-select-small-label">
                    {snippets.next.checkout.address.shippingAddress.salutation}
                  </InputLabel>
                  <Select
                    labelId="salutationId-label"
                    id="shippingAddressSalutationId"
                    name="shippingAddress[salutationId]"
                    disabled={selectedShippingTo === "store"}
                    value={
                      selectedShippingSalutation
                        ? selectedShippingSalutation
                        : ""
                    }
                    label={
                      snippets.next.checkout.address.shippingAddress.salutation
                    }
                    onChange={(event) =>
                      setSelectedShippingSalutation(event.target.value)
                    }
                  >
                    {salutations.map((salutation) => (
                      <MenuItem key={salutation.id} value={salutation.id}>
                        {salutation.translated.displayName}
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
              </div>
            </div>
            <div className={"col-span-2"}>
              <TextField
                sx={{
                  "& .MuiOutlinedInput-input:focus": {
                    boxShadow: "none",
                  },
                }}
                error={false}
                required={selectedShippingTo === "store"}
                helperText=""
                label={snippets.next.checkout.address.shippingAddress.company}
                type="text"
                id="shippingAddressCompany"
                name="shippingAddress[company]"
                fullWidth
                size="small"
                disabled={selectedShippingTo === "store"}
                value={shippingAddressCompany}
                onChange={(e) => setShippingAddressCompany(e.target.value)}
              />
            </div>

            <div className={"col-span-2 sm:col-span-1"}>
              <TextField
                sx={{
                  "& .MuiOutlinedInput-input:focus": {
                    boxShadow: "none",
                  },
                }}
                error={false}
                required={!useBillingAddress}
                disabled={selectedShippingTo === "store"}
                helperText=""
                label={snippets.next.checkout.address.shippingAddress.firstName}
                type="text"
                id="shippingAddressFirstName"
                name="shippingAddress[firstName]"
                fullWidth
                size="small"
                value={shippingAddressFirstName}
                onChange={(e) => setShippingAddressFirstName(e.target.value)}
              />
            </div>

            <div className={"col-span-2 sm:col-span-1"}>
              <TextField
                sx={{
                  "& .MuiOutlinedInput-input:focus": {
                    boxShadow: "none",
                  },
                }}
                error={false}
                helperText=""
                required={!useBillingAddress}
                disabled={selectedShippingTo === "store"}
                label={snippets.next.checkout.address.shippingAddress.lastName}
                type="text"
                id="shippingAddressLastName"
                name="shippingAddress[lastName]"
                fullWidth
                size="small"
                value={shippingAddressLastName}
                onChange={(e) => setShippingAddressLastName(e.target.value)}
              />
            </div>

            <div className="col-span-2">
              <TextField
                sx={{
                  "& .MuiOutlinedInput-input:focus": {
                    boxShadow: "none",
                  },
                }}
                error={false}
                helperText=""
                required={!useBillingAddress}
                disabled={selectedShippingTo === "store"}
                label={
                  snippets.next.checkout.address.shippingAddress.streetNumber
                }
                type="text"
                id="shippingAddressAddressStreet"
                name="shippingAddress[street]"
                fullWidth
                size="small"
                value={shippingAddressStreet}
                onChange={(e) => setShippingAddressStreet(e.target.value)}
              />
            </div>
            <div className={"col-span-2"}>
              <TextField
                sx={{
                  "& .MuiOutlinedInput-input:focus": {
                    boxShadow: "none",
                  },
                }}
                error={false}
                helperText=""
                label={
                  snippets.next.checkout.address.shippingAddress.additional
                }
                disabled={selectedShippingTo === "store"}
                type="text"
                id="shippingAddressAdditionalAddressLine1"
                name="shippingAddress[additionalAddressLine1]"
                fullWidth
                size="small"
                value={shippingAddressAdditionalAddressLine1}
                onChange={(e) =>
                  setShippingAddressAdditionalAddressLine1(e.target.value)
                }
                inputProps={{ maxLength: 30 }}
              />
            </div>
            <div className={"col-span-1 mr-2 sm:mr-0"}>
              <TextField
                sx={{
                  "& .MuiOutlinedInput-input:focus": {
                    boxShadow: "none",
                  },
                }}
                inputProps={{
                  inputMode: "numeric",
                  pattern: "[0-9]*",
                  minLength: 5,
                  maxLength: 5,
                }}
                error={false}
                helperText=""
                required={!useBillingAddress}
                disabled={selectedShippingTo === "store"}
                label={snippets.next.checkout.address.shippingAddress.zipcode}
                type="text"
                id="shippingAddressZipcode"
                name="shippingAddress[zipcode]"
                fullWidth
                size="small"
                value={shippingAddressZipcode}
                onChange={(e) => setShippingAddressZipcode(e.target.value)}
              />
            </div>
            <div className={"col-span-1"}>
              <TextField
                sx={{
                  "& .MuiOutlinedInput-input:focus": {
                    boxShadow: "none",
                  },
                }}
                error={false}
                helperText=""
                required={!useBillingAddress}
                disabled={selectedShippingTo === "store"}
                label={snippets.next.checkout.address.shippingAddress.city}
                type="text"
                id="shippingAddressCity"
                name="shippingAddress[city]"
                fullWidth
                size="small"
                value={shippingAddressCity}
                onChange={(e) => setShippingAddressCity(e.target.value)}
              />
            </div>
            <div className={"col-span-2"}>
              <FormControl
                sx={{ m: 0, minWidth: "100%" }}
                size="small"
                className="bg-white"
                disabled={selectedShippingTo === "store"}
              >
                <InputLabel id="demo-select-small-label">Land</InputLabel>
                <Select
                  labelId="salutationId-label"
                  id="shippingAddressCountryId"
                  name="shippingAddress[countryId]"
                  value={selectedShippingCountry ? selectedShippingCountry : ""}
                  label={snippets.next.checkout.address.shippingAddress.land}
                  onChange={(event) =>
                    setSelectedShippingCountry(event.target.value)
                  }
                >
                  {countries.map((country) => (
                    <MenuItem key={country.id} value={country.id}>
                      {country.translated.name}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </div>
          </div>
        </Collapse>
      </div>

      {/* Delivery */}
      <div className="mt-10 border-t border-gray-200 pt-10">
        <div className="headline-small mb-2">
          {snippets.next.checkout.address.shippingAddress.delivery.title}
        </div>
        <SelectDelivery
          selectedDeliveryMethod={selectedDeliveryMethod}
          setSelectedDeliveryMethod={setSelectedDeliveryMethod}
          deliveryMethods={deliveryMethods}
        />
      </div>

      {/* Payment */}
      <div className="mt-10 border-t border-gray-200 pt-10 pb-12">
        <div className="headline-small mb-2">
          {snippets.next.checkout.address.shippingAddress.payment.title}
        </div>
        <SelectPayment
          selectedPaymentMethod={selectedPaymentMethod}
          setSelectedPaymentMethod={setSelectedPaymentMethod}
          paymentMethods={paymentMethods}
        />
      </div>
    </>
  );
};

export default CheckoutAddress;

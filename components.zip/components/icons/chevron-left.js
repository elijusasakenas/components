import React from 'react';
export default function ChevronLeftIcon({className = 'h-6 w-6 fill-base-50 hover:fill-orange-200'}) {
    return (
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none"  className={className}>
            <path d="M15.3164 17.7109C15.1797 17.8477 14.9883 17.8477 14.8516 17.7109L9.10938 11.9961C9 11.8594 9 11.668 9.10938 11.5312L14.8516 5.81641C14.9883 5.67969 15.1797 5.67969 15.3164 5.81641L15.8633 6.33594C15.9727 6.47266 15.9727 6.69141 15.8633 6.80078L10.9141 11.75L15.8633 16.7266C15.9727 16.8359 15.9727 17.0547 15.8633 17.1914L15.3164 17.7109Z"/>
        </svg>
    );
}
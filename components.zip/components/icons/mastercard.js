import React from 'react';
export default function MasterCardIcon({className = 'h-6 w-6 fill-base-50 hover:fill-orange-200'}) {
    return (
        <svg width="28" height="36" viewBox="0 0 28 36" fill="none" xmlns="http://www.w3.org/2000/svg">
            <g clipPath="url(#clip0_7107_35050)">
                <path fillRule="evenodd" clipRule="evenodd" d="M10.1099 24.6609H17.6039V11.3148H10.1099V24.6609Z"
                      fill="#FF5F00"/>
                <path fillRule="evenodd" clipRule="evenodd"
                      d="M10.5856 17.9881C10.5856 15.2805 11.8648 12.8691 13.8568 11.3151C12.3998 10.1784 10.5618 9.50037 8.56385 9.50037C3.83407 9.50037 0 13.3005 0 17.9881C0 22.6757 3.83407 26.4759 8.56385 26.4759C10.5618 26.4759 12.3998 25.7978 13.8568 24.6611C11.8648 23.1069 10.5856 20.6957 10.5856 17.9881Z"
                      fill="#EB001B"/>
                <path fillRule="evenodd" clipRule="evenodd"
                      d="M27.4462 23.2473V22.918H27.3593L27.2596 23.1445L27.1597 22.918H27.0729V23.2473H27.134V22.9988L27.2278 23.2131H27.2913L27.385 22.9984V23.2473H27.4462ZM26.8964 23.2473V22.9741H27.0077V22.9184H26.7246V22.9741H26.8357V23.2473H26.8964ZM27.7136 17.9878C27.7136 22.6754 23.8793 26.4755 19.1497 26.4755C17.1518 26.4755 15.3135 25.7974 13.8568 24.6608C15.8488 23.1068 17.128 20.6953 17.128 17.9878C17.128 15.2804 15.8488 12.8689 13.8568 11.3147C15.3135 10.1781 17.1518 9.5 19.1497 9.5C23.8793 9.5 27.7136 13.3002 27.7136 17.9878Z"
                      fill="#F79E1B"/>
            </g>
            <defs>
                <clipPath id="clip0_7107_35050">
                    <rect width="28" height="17" fill="white" transform="translate(0 9.5)"/>
                </clipPath>
            </defs>
        </svg>
    );
}

import React from 'react';
export default function NavSeparationBar({ className }) {
    return (
        <svg xmlns="http://www.w3.org/2000/svg" width="10" height="18" viewBox="0 0 10 18" fill="none" className={className}>
            <path d="M0.605988 16.7402L8.60599 0.740234L9.49999 1.18823L1.49999 17.1882L0.605988 16.7402Z" fill="#D1D5DB" />
        </svg>
    );
}
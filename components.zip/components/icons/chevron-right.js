import React from 'react';
export default function ChevronRightIcon({className = 'h-6 w-6 fill-base-50 hover:fill-orange-200'}) {
    return (
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none"  className={className}>
            <path d="M9.65625 5.81641C9.79297 5.67969 9.98438 5.67969 10.1211 5.81641L15.8633 11.5312C15.9727 11.668 15.9727 11.8594 15.8633 11.9961L10.1211 17.7109C9.98438 17.8477 9.79297 17.8477 9.65625 17.7109L9.10938 17.1914C9 17.0547 9 16.8359 9.10938 16.7266L14.0586 11.75L9.10938 6.80078C9 6.69141 9 6.47266 9.10938 6.33594L9.65625 5.81641Z"/>
        </svg>
    );
}
import React from 'react';
export default function StarFilledIcon({className = 'h-6 w-6 fill-base-50 hover:fill-orange-200'}) {
    return (
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" className={className}>
            <path d="M11.0371 3.7226C11.4355 2.92573 12.5644 2.95893 12.9297 3.7226L15.1211 8.13862L19.9687 8.83588C20.832 8.96869 21.164 10.0312 20.5332 10.6621L17.0469 14.082L17.8769 18.8964C18.0098 19.7597 17.0801 20.4238 16.3164 20.0253L12 17.7343L7.65038 20.0253C6.8867 20.4238 5.95702 19.7597 6.08983 18.8964L6.91991 14.082L3.43358 10.6621C2.80272 10.0312 3.13475 8.96869 3.99803 8.83588L8.87889 8.13862L11.0371 3.7226Z"/>
        </svg>
    );
}
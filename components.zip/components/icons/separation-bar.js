import React from 'react';
export default function SeparationBar({ className,stroke = "#E5E5E5" }) {
    return (
        <svg xmlns="http://www.w3.org/2000/svg" width="340" height="2" viewBox="0 0 340 2" fill="none" className={className}>
            <path d="M0 1H340" stroke={stroke} />
        </svg>
    );
}
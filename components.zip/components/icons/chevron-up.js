import React from 'react';
export default function ChevronUpIcon({className = 'h-6 w-6 fill-base-50 hover:fill-orange-200'}) {
    return (
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none"  className={className}>
            <path d="M6.53906 14.5938C6.40234 14.457 6.40234 14.2656 6.53906 14.1289L12.2539 8.38672C12.3906 8.27734 12.582 8.27734 12.7188 8.38672L18.4336 14.1289C18.5703 14.2656 18.5703 14.457 18.4336 14.5938L17.9141 15.1406C17.7773 15.25 17.5586 15.25 17.4492 15.1406L12.5 10.1914L7.52344 15.1406C7.41406 15.25 7.19531 15.25 7.05859 15.1406L6.53906 14.5938Z"/>
        </svg>
    );
}
import React from 'react';
export default function ChevronDownIcon({className = 'h-6 w-6 fill-base-50 hover:fill-orange-200'}) {
    return (
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none"  className={className}>
            <path d="M18.4336 9.34375C18.5703 9.45312 18.5703 9.67188 18.4336 9.80859L12.7188 15.5234C12.582 15.6602 12.3906 15.6602 12.2539 15.5234L6.53906 9.80859C6.40234 9.67188 6.40234 9.45312 6.53906 9.34375L7.05859 8.79688C7.19531 8.66016 7.41406 8.66016 7.52344 8.79688L12.5 13.7461L17.4492 8.79688C17.5586 8.66016 17.7773 8.66016 17.9141 8.79688L18.4336 9.34375Z"/>
        </svg>
    );
}
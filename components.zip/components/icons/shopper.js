const ShopperIcon = ({className}) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="50"
    height="29"
    viewBox="0 0 50 29"
    fill="none"
    className={className}
  >
    <path
      fill-rule="evenodd"
      clip-rule="evenodd"
      d="M20.8497 1.77348C20.8497 1.77348 20.3466 1.34994 19.5919 1.13816C19.3127 1.05983 18.1947 1.34134 16.5733 1.34994C15.2724 1.35683 12.925 0.730006 11.7937 1.13816C10.6625 1.54632 12.2969 1.56171 13.3031 1.98525C13.5864 2.10451 14.2662 2.61752 14.3093 2.62057C15.4011 2.69792 17.0986 2.19702 18.8372 2.19702C21.3528 2.19702 20.8497 1.77348 20.8497 1.77348Z"
      fill="black"
      stroke="black"
      stroke-width="1.20107"
    />
    <path
      d="M15.6138 2.8159L20.9333 18.2508"
      stroke="black"
      stroke-width="1.20107"
    />
    <ellipse
      cx="8.70779"
      cy="18.2507"
      rx="8.70779"
      ry="8.77671"
      stroke="black"
      stroke-width="1.20107"
    />
    <ellipse
      cx="8.77211"
      cy="8.71242"
      rx="8.77211"
      ry="8.71242"
      transform="matrix(-0.256921 -0.966432 0.965412 -0.260729 33.1777 29)"
      stroke="black"
      stroke-width="1.20107"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <ellipse
      cx="5.739"
      cy="5.71642"
      rx="5.739"
      ry="5.71642"
      transform="matrix(0.497047 0.867724 -0.86431 0.502959 10.7959 10.3957)"
      stroke="black"
      stroke-width="1.20107"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <ellipse
      cx="39.3349"
      cy="18.2507"
      rx="5.75026"
      ry="5.7051"
      transform="rotate(90 39.3349 18.2507)"
      stroke="black"
      stroke-width="1.20107"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <ellipse
      cx="21.3192"
      cy="20.0667"
      rx="2.10188"
      ry="2.11852"
      stroke="black"
      stroke-width="1.20107"
    />
    <path
      d="M23.421 24.001L21.6193 20.3693L8.40753 19.1587L3.35191 10.3571C2.66201 9.15606 3.52903 7.65817 4.91414 7.65817H13.2118L19.8177 14.619L33.0296 5.23701"
      stroke="black"
      stroke-width="1.20107"
    />
    <path
      d="M22.2197 24.6063L24.6219 23.3957"
      stroke="black"
      stroke-width="1.20107"
      stroke-linecap="round"
    />
    <path
      d="M8.40771 19.1587L17.4158 8.8688"
      stroke="black"
      stroke-width="1.20107"
    />
    <path
      d="M22.8203 18.5534L26.4235 14.7424"
      stroke="black"
      stroke-width="1.20107"
      stroke-linecap="round"
    />
    <path
      d="M28.6702 12.5005L33.6299 7.0529"
      stroke="black"
      stroke-width="1.20107"
      stroke-linecap="round"
    />
    <path
      d="M39.6356 19.1587L37.2334 15.527L31.8286 2.8159H37.2334"
      stroke="black"
      stroke-width="1.20107"
      stroke-linecap="round"
    />
    <path
      fill-rule="evenodd"
      clip-rule="evenodd"
      d="M37.2334 14.6169C37.2334 14.729 37.3691 14.7849 37.448 14.7054V14.7054L44.0249 8.07641C44.4009 7.69741 44.1325 7.0529 43.5986 7.0529H37.2334V14.6169Z"
      stroke="black"
      stroke-width="1.20107"
      stroke-linecap="round"
    />
    <path
      d="M36.0322 7.05285H37.2333"
      stroke="black"
      stroke-width="1.20107"
      stroke-linecap="round"
    />
  </svg>
);

export default ShopperIcon;

import dynamic from "next/dynamic";
import ProductStream from "@/shopware/product_stream";

const ProductBox = dynamic(() => import("../product/box"), {
  ssr: false,
});

const ProductSlider = () => {
  const stream = ProductStream("018e5c282a1379a4a28dd0a833d8008c", 4);

  if (!stream) return "Loading...";

  return (
    <div className="bg-white">
      <div className="mx-auto py-6 pb-12 lg:py-16 px-6 lg:px-8 xl:px-0 lg:max-w-7xl"
        data-lt-tmp-id="lt-394125"
        spellCheck="false"
        data-gramm="false">
          <p className="h2 text-blue-600 md:text-center mb-3">
            Beste Fahrräder
          </p>


          <div className="bg-white mt-10">
            <div className="mx-auto lg:max-w-7xl">
              <div className="mt-4 grid grid-cols-1 gap-y-6 sm:grid-cols-2 sm:gap-x-6 lg:grid-cols-4 xl:gap-x-8">
                {stream.map((product) =>
                  product.seoUrls ? (
                    <ProductBox
                      product={product}
                      key={product.id}
                    />
                  ) : null
                )}
              </div>
            </div>
          </div>
        
      </div>
    </div>
  );
};

export default ProductSlider;

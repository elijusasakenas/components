import { useState } from "react";
import Link from "next/link";
import Alert from "@/components/Alert";
import axiosInstance from "@/shopware/client";

export default function CenteredCard() {
  const [newsletteMessage, setNewsletteMessage] = useState("");

  async function handleNewsletterSubmit(event) {
    event.preventDefault();

    let state = false;
    const eventFormData = new FormData(event.target);
    const formData = Object.fromEntries(eventFormData);

    await axiosInstance
      .post("/newsletter/subscribe", formData)
      .then(function (res) {
        //res.data ? state = true : state = false;
      })
      .catch(function (error) {
        setNewsletteMessage(error.message);
      });

    setNewsletteMessage(
      "Vielen Dank für Ihre Anmeldung. Sie erhalten in Kürze eine E-Mail mit einem Bestätigungslink."
    );
  }

  return (
    <>
      <div className="mx-auto py-6 lg:py-10 lg:px-8 xl:px-0">
        {newsletteMessage ? (
          <div className="relative isolate overflow-hidden bg-blue-700 p-6">
            <div className="max-w-7xl mx-auto">
              <Alert
                type={"info"}
                headline="Erfolgreich"
                message={newsletteMessage}
              />
            </div> 
          </div>
        ) : (
          <div className="relative isolate overflow-hidden bg-blue-700 px-6 py-6 md:py-12 md:px-12 xl:py-20">
            <div className="h2 mx-auto max-w-2xl text-center text-base-500">
              Jetzt 5 Euro Rabatt sichern!
            </div>
            <p className="mx-auto mt-2 max-w-xl text-center text-lg leading-6 text-base-500">
              Abonnieren Sie unseren Newsletter und wir schenken Ihnen einen 5 Euro-Gutschein für Ihren nächsten Einkauf.
            </p>
            <form className="mx-auto mt-4 md:flex max-w-md md:gap-x-4" onSubmit={handleNewsletterSubmit}>
              <input type={"hidden"} name={"option"} value={"subscribe"} />
              <input type={"hidden"} name={"storefrontUrl"} value={process.env.NEXT_PUBLIC_SW_APP_URL} />
              <label htmlFor="email" className="sr-only">
                E-Mail Adresse
              </label>
              <input
                id="email"
                name="email"
                type="email"
                autoComplete="email"
                required
                className="w-full flex-auto rounded-md border-0 bg-white px-4 py-[10px] text-sm font-semibold leading-[14px] text-base-200 placeholder:text-base-300"
                placeholder="Geben sie ihre E-Mail Adresse ein"
              />
              <button
                type="submit"
                className="w-full md:w-auto mt-2 md:mt-0 flex-none rounded-md bg-orange px-4 py-[10px] text-sm font-semibold leading-[14px] text-base-500 hover:bg-blue-600"
              >
                Benachrichtige mich
              </button>
            </form>
            <p className={"text-sm text-neutral-100 text-center mt-2"}>
                  Ich habe die{" "}
                  <Link
                    href="/datenschutz#newsletter"
                    className="underline hover:text-orange-500"
                  >
                    Datenschutzbestimmungen
                  </Link>{" "}
                  zur Kenntnis genommen.
                </p>
            
          </div>
        )}
      </div>
    </>
  )
}
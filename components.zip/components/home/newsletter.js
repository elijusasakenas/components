'use client'

import Alert from "@/components/Alert";
import axiosInstance from "@/shopware/client";
import Link from "next/link";
import { useState } from "react";

const Newsletter = ({ ...params }) => {
  const [newsletteMessage, setNewsletteMessage] = useState("");

  async function handleNewsletterSubmit(event) {
    event.preventDefault();

    let state = false;
    const eventFormData = new FormData(event.target);
    const formData = Object.fromEntries(eventFormData);

    await axiosInstance
      .post("/newsletter/subscribe", formData)
      .then(function (res) {
        //res.data ? state = true : state = false;
      })
      .catch(function (error) {
        setNewsletteMessage(error.message);
      });

    setNewsletteMessage(
      "Vielen Dank für Ihre Anmeldung. Sie erhalten in Kürze eine E-Mail mit einem Bestätigungslink."
    );
  }

  const closeNewsletter = () => {
    params.setOpen(false);
  };

  return (
    <div className={"mx-auto max-w-7xl sm:px-6 lg:px-8"}>
        {newsletteMessage ? (
          <div className="relative isolate overflow-hidden bg-blue-800 p-6 sm:rounded-3xl sm:p-12">
            <Alert
              type={"info"}
              headline="Ihre Anmeldung"
              message={newsletteMessage}
            />
          </div>
        ) : (
          <>
            <div className="relative isolate overflow-hidden bg-blue-800 px-6 py-24 sm:rounded-3xl sm:px-24 xl:py-32">
              <p className="mx-auto max-w-2xl text-center text-3xl font-bold tracking-tight text-base-100 sm:text-4xl">
                Jetzt 5 Euro Rabatt sichern!
              </p>
              <p className="mx-auto mt-2 max-w-xl text-center text-lg leading-8 text-base-100">
                Abonnieren Sie unseren Newsletter und wir schenken Ihnen einen 5
                Euro-Gutschein für Ihren nächsten Einkauf.
              </p>
              <form
                className="mx-auto mt-10 flex max-w-md gap-x-4"
                onSubmit={handleNewsletterSubmit}
              >
                <label htmlFor="email-address" className="sr-only">
                  E-Mail Adresse
                </label>
                <input type={"hidden"} name={"option"} value={"subscribe"} />
                <input
                  type={"hidden"}
                  name={"storefrontUrl"}
                  value={process.env.NEXT_PUBLIC_SW_APP_URL}
                />
                <input
                  type="email"
                  name="email"
                  id="email"
                  autoComplete="email"
                  required
                  className="min-w-0 flex-auto rounded-md border-0 bg-white/5 px-3.5 py-2 text-white shadow-sm ring-1 ring-inset ring-white/10 focus:ring-2 focus:ring-inset focus:ring-white sm:text-sm sm:leading-6 appearance-none"
                  placeholder="Ihre E-Mail-Adresse"
                />
                <button
                  type="submit"
                  className="flex-none px-3.5 py-2.5 text-sm font-semibold btn"
                >
                  Anmelden
                </button>
              </form>
              <p className={"text-sm text-gray-100 text-center mt-2"}>
                Ich habe die{" "}
                <Link
                  href="/datenschutz#newsletter"
                  onClick={closeNewsletter}
                  shallow={true}
                  className="underline"
                >
                  Datenschutzbestimmungen
                </Link>{" "}
                zur Kenntnis genommen.
              </p>
            </div>
          </>
        )}
    </div>
  );
};

export default Newsletter;

import Image from "next/image";
import { useState } from "react";
import SizeChose from "./SizeChoose";
import ProductPagination from "./ProductPagination";
import StatusBadge from "./StatusBadge";
import BuyButton from "@/components/Detail/BuyButton";
import BuyForm from "@/components/Detail/BuyForm";

export default function ProductMerch({product, snippets, configurator, setIsLoading,setDetail}) {

    return (
        <div className="flex flex-col items-center text-base-50 pb-14 max-w-[830px] m-auto">
            <div className="flex px-6 flex-col items-start gap-4 pb-12">
                <div className="headline-large capitalize min-[744px]:justify-center flex w-full min-[744px]:text-center">
                    <h1>{product?.translated.name}</h1>
                </div>
            </div>
            <div className="flex justify-center items-center">
                <Image
                    src={'/static/images/merch-prod.png'}
                    alt="Bike"
                    width={800}
                    height={800}
                />
            </div>
            <ProductPagination />
            <div className="flex min-[744px]:flex-row flex-col w-full pb-8 pt-8">
                <BuyForm product={product} snippets={snippets} configurator={configurator} setIsLoading={setIsLoading} setDetail={setDetail} />
            </div>
            <div className="px-6 pt-6">
                <p className="body-small" dangerouslySetInnerHTML={{
                    __html: product?.translated?.description,
                }}
                />
            </div>
        </div>
    );
}
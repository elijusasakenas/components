import React from "react";

export default function ProductPagination() {

    const [active, setActive] = React.useState(false);
    React.useEffect(() => {
        setActive(0);
    }, []);

    return (
        <div className="flex py-8 justify-center items-center gap-[10px]">
            {[...Array(5)].map((_, index) => (
                <button
                    key={index}
                    className={`w-2 h-2 rounded-[10px] ${active === index ? 'bg-orange-200 w-8' : 'bg-[#D8D8D8]'}`}
                    onClick={() => setActive(index)}
                />
            ))}
        </div>
    )
}

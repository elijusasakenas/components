import { NumericFormat } from "react-number-format";
import Link from "next/link";

export default function DisplayPrice({ product, layout, snippets }) {
  return (
    <>
      {product.calculatedPrice?.listPrice ? (
        <span className={"headline-medium"}>
          <NumericFormat
            value={product.calculatedPrice?.unitPrice}
            decimalSeparator=","
            decimalScale="2"
            fixedDecimalScale="true"
            displayType={"text"}
            thousandSeparator="."
            suffix={" €*"}
          />
        </span>
      ) : null}
      <p className="headline-medium">
        <NumericFormat
          value={product.calculatedPrice?.unitPrice}
          decimalSeparator=","
          decimalScale="2"
          fixedDecimalScale="true"
          displayType={"text"}
          thousandSeparator="."
          suffix={" €*"}
        />
      </p>

      {layout !== "exclusive" ? (
        <div className={"body-extra-small"} dangerouslySetInnerHTML={{ __html: snippets.next.detail.taxDefault }} />
      ) : (
        <span className={"body-extra-small"}>{snippets.next.detail.taxExclusive}</span>
      )}
    </>
  );
}

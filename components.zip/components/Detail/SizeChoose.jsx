import { fetchClient } from "@/utility/fetch-client";
import { useEffect, useState } from "react";
import SizingModal from "./SizingModal";

export default function SizeChoose({
  configurator,
  product,
  setDetail,
  activeOptions,
  setActiveOptions,
  snippets
}) {
  const [activeSize, setActiveSize] = useState(null);

  useEffect(() => {
    if (configurator) {
      configurator.map((config) => {
        if (config.name === "Größe") {
          const selectedOption = config.options.find((option) =>
            product.optionIds.includes(option.id)
          );
          if (selectedOption) {
            setActiveSize(selectedOption.translated.name);
          }
        }
      });
    }
  }, [configurator, product?.optionIds]);

  const handleSearch = async (search, index) => {
    if (product.parentId) {
      const newArr = activeOptions;
      newArr[index] = search.id;

      setActiveOptions(newArr);

      const res = await fetchClient({
        path: `product/${product.parentId}/find-variant`,
        method: "POST",
        body: {
          options: activeOptions,
          switchGroup: search.groupId,
        },
      });

      if (res.variantId) {
        const detail = await fetchClient({
          path: `product/${res.variantId}`,
          method: "POST",
          body: {
            associations: {
              media: [],
              properties: { associations: { group: [] } },
              seoUrls: [],
            },
          },
        });

        setDetail(detail.product);
      }
    }
  };

  const handleVariantSelection = (option, index) => {
    handleSearch(option, index);
  };

  return (
    configurator &&
    configurator.map(
      (config, index) =>
        config.name === "Größe" && (
          <div key={index}>
            <div
              className="flex flex-col items-start gap-4 w-full pb-4 min-[744px]:min-w-[50%]"
            >
              <>
                <div className="flex items-center gap-1">
                  <span className="body-small">{snippets.detail.buy.size}</span>
                  <p className="body-small-emphasis">{activeSize}</p>
                </div>
                <div className="flex items-center content-center gap-4 flex-wrap">
                  {config.options.map((option) => (
                    <button
                      key={option.id}
                      onClick={() => handleVariantSelection(option, index)}
                      className={`size-item hover:border-orange-200 focus:border-orange-200 ${
                        product.optionIds.includes(option.id) ? "active" : ""
                      }`}
                    >
                      {option.translated.name}
                    </button>
                  ))}
                </div>
              </>
            </div>

            <SizingModal bikeCode={product.productNumber} />
          </div>
        )
    )
  );
}

import { fetchClient } from "@/utility/fetch-client";
import { useEffect, useState } from "react";

const ColorChoose = ({
  configurator,
  product,
  setDetail,
  activeOptions,
  setActiveOptions,
  snippets
}) => {
  const [activeColor, setActiveColor] = useState("");

  useEffect(() => {
    if (configurator) {
      configurator.map((config) => {
        if (config.name === "Farbe") {
          const selectedOption = config.options.find((option) =>
            product.optionIds.includes(option.id)
          );

          if (selectedOption) {
            setActiveColor(selectedOption.translated.name);
          }
        }
      });
    }
  }, [configurator, product.optionIds]);

  const handleSearch = async (search, index) => {
    if (product.parentId) {
      const newArr = activeOptions;
      newArr[index] = search.id;

      setActiveOptions(newArr);

      const res = await fetchClient({
        path: `product/${product.parentId}/find-variant`,
        method: "POST",
        body: {
          options: activeOptions,
          switchGroup: search.groupId,
        },
      });

      if (res.variantId) {
        const detail = await fetchClient({
          path: `product/${res.variantId}`,
          method: "POST",
          body: {
            associations: {
              media: [],
              properties: { associations: { group: [] } },
              seoUrls: [],
            },
          },
        });

        setDetail(detail.product);
      }
    }
  };

  const handleVariantSelection = (option, index) => {
    handleSearch(option, index);
  };

  return (
    configurator &&
    configurator.map(
      (config, index) =>
        config.name === "Farbe" && (
          <div
            key={index}
            className="flex flex-col items-start gap-3 w-full pb-10"
          >
            <div className="flex">
              <span className="body-small pr-2">{snippets.detail.buy.color}</span>
              <p className="body-small-emphasis">{activeColor}</p>
            </div>
            <div className="flex items-center content-center gap-4 flex-wrap">
              {config.options.map((option) => (
                <button
                  key={option.id}
                  onClick={() => handleVariantSelection(option, index)}
                  className={`color-item hover:border-orange-200 focus:border-orange-200 ${
                    product.optionIds.includes(option.id) ? "active" : ""
                  }`}
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="40"
                    height="40"
                    viewBox="0 0 40 40"
                    fill="none"
                  >
                    <circle
                      cx="20"
                      cy="20"
                      r="20"
                      fill={
                        option.colorHexCode ? option.colorHexCode : "#000000"
                      }
                    />
                  </svg>
                </button>
              ))}
            </div>
          </div>
        )
    )
  );
};

export default ColorChoose;

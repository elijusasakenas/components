import { useRef, useState } from "react";

import { AddToCart } from "@/shopware/cart";
import {
  Description,
  Dialog,
  DialogBackdrop,
  DialogPanel,
  DialogTitle,
  Field,
  Select,
} from "@headlessui/react";
import PropTypes from "prop-types";

export default function BuyButton({
  available,
  customizable,
  product,
  countries = null,
  snippets,
}) {
  const [addCart, setAddCart] = useState(false);

  const handleAddToCartClick = () => {
    setAddCart(true);
  };

  return (
    <>
      {available ? (
        <div className="flex flex-col gap-4 w-full">
          {customizable && (
            <>
              <ConfiguratorSelectLand
                countries={countries}
                orderNumber={product.productNumber}
                productName={product.translated.name}
              />
            </>
          )}

          <button className="btn-primary w-full" onClick={handleAddToCartClick}>
            {addCart && (
              <AddToCart
                productId={product.id}
                quantity={1}
                setAddCart={setAddCart}
                product={product}
                categoryName={
                  product.seoCategory?.translated?.name
                    ? product.seoCategory.translated.name
                    : null
                }
              />
            )}
            {!addCart && <span>{snippets.next.detail.addProduct}</span>}
          </button>
        </div>
      ) : (
        <>
          <div className="flex p-3 flex-col items-center gap-3 rounded-lg bg-base-400">
            <div className="flex items-center gap-2">
              <div>
                <svg
                  width="18"
                  height="21"
                  viewBox="0 0 18 21"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M9 20.5C7.59375 20.5 6.5 19.4062 6.5 18H11.4609C11.4609 19.4062 10.3672 20.5 9 20.5ZM17.3984 14.6797C17.6328 14.9141 17.75 15.2266 17.75 15.5C17.7109 16.1641 17.2422 16.75 16.4609 16.75H1.5C0.71875 16.75 0.25 16.1641 0.25 15.5C0.210938 15.2266 0.328125 14.9141 0.5625 14.6797C1.30469 13.8594 2.75 12.6484 2.75 8.625C2.75 5.61719 4.85938 3.19531 7.75 2.57031V1.75C7.75 1.08594 8.29688 0.5 9 0.5C9.66406 0.5 10.2109 1.08594 10.2109 1.75V2.57031C13.1016 3.19531 15.2109 5.61719 15.2109 8.625C15.2109 12.6484 16.6562 13.8594 17.3984 14.6797Z"
                    fill="#EC7205"
                  />
                </svg>
              </div>
              <div>
                <p className="body-small text-base-50">
                  Benachrichtige mich bei Verfügbarkeit
                </p>
              </div>
            </div>
            <div className="flex pt-3 pb-3 pl-3 pr-2 justify-between items-center rounded-lg border border-base-400 bg-white w-full">
              <input
                type="email"
                placeholder="Deine E-Mail-Adresse"
                className="placeholder:text-base-300 placeholder:font-exo placeholder:text-sm placeholder:leading-6 border-0 p-0"
              />
              <button>
                <svg
                  width="21"
                  height="19"
                  viewBox="0 0 21 19"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M6.19531 8.5625H15.9609L3.53906 3.25L6.19531 8.5625ZM6.19531 10.4375L3.53906 15.7891L15.9609 10.4375H6.19531ZM2.71875 0.867188L20.2188 8.36719C20.6875 8.5625 21 9.03125 21 9.53906C21 10.0078 20.6875 10.4766 20.2188 10.6719L2.71875 18.1719C2.25 18.3672 1.66406 18.25 1.3125 17.8594C0.960938 17.5078 0.882812 16.9219 1.11719 16.4531L4.59375 9.5L1.11719 2.58594C0.882812 2.11719 0.960938 1.53125 1.3125 1.14062C1.66406 0.789062 2.25 0.671875 2.71875 0.867188Z"
                    fill="#131313"
                  />
                </svg>
              </button>
            </div>
          </div>
          <p className="body-small">Datenschutzbestimmungen bla bla</p>
        </>
      )}
    </>
  );
}

BuyButton.propTypes = {
  available: PropTypes.bool.isRequired,
};

export const ConfiguratorSelectLand = ({
  countries,
  orderNumber,
  productName,
}) => {
  let [isOpen, setIsOpen] = useState(false);
  const countriesRef = useRef();

  const onSave = () => {
    const countryIso = countriesRef.current.value.toLowerCase();
    const url =
      process.env.NEXT_PUBLIC_CONFIGURATOR_URL +
      "/?bike=" +
      productName +
      "&ordernumber=" +
      orderNumber +
      "&lang=de&country=" +
      countryIso;
    window.open(url, "_blank");

    setIsOpen(false);
  };

  return (
    countries && (
      <>
        <button
          className="btn-secondary w-full"
          onClick={() => setIsOpen(true)}
        >
          Personalisieren
        </button>
        <Dialog
          open={isOpen}
          onClose={() => setIsOpen(false)}
          className="relative z-50"
        >
          <DialogBackdrop className="fixed inset-0 bg-black bg-opacity-50" />

          <div className="fixed inset-0 flex w-screen items-center justify-center p-4">
            <DialogPanel className="max-w-xl space-y-4 bg-white p-12">
              <DialogTitle className="headline-medium">
                Wohin geht die Rechnung?
              </DialogTitle>

              <Field>
                <Description className="body-small">
                  Damit du dein Fahrrad problemlos konfigurieren und kaufen
                  kannst, musst du hier unbedingt das Land auswählen, in dem
                  deine Rechnungsadresse entspricht. Die Lieferadresse kann
                  abweichen.
                </Description>

                <Select
                  ref={countriesRef}
                  name="countries"
                  aria-label="Länderauswahl"
                  className="mt-4 w-full rounded-lg p-3 transition-all border border-base-400 focus:border-orange-200 focus:ring-0 focus:outline-0"
                >
                  <option value="" disabled>
                    Land auswählen
                  </option>
                  {countries.map((country) => (
                    <option key={country.id} value={country.iso}>
                      {country.translated.name} ({country.iso})
                    </option>
                  ))}
                </Select>
              </Field>

              <div className="flex gap-4 items-center justify-between">
                <button
                  className="btn btn-secondary btn-small"
                  onClick={() => setIsOpen(false)}
                >
                  Abbrechen
                </button>
                <button
                  className="btn btn-primary btn-small"
                  onClick={() => onSave()}
                >
                  Bestätigen
                </button>
              </div>
            </DialogPanel>
          </div>
        </Dialog>
      </>
    )
  );
};

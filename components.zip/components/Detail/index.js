"use client";

import { useEffect, useState } from "react";
import * as gtag from "utility/gtag";
//import { fbEvent } from '@netzkombyse/facebook-conversion-api-nextjs';
import CustomizableLayout from "@/components/Detail/CustomizableLayout";
import ExclusiveLayout from "@/components/Detail/ExclusiveLayout";
import ProductSizeTable from "@/components/Detail/ProductSizeTable";
import ProductSpecifications from "@/components/Detail/ProductSpecifications";
import Breadcrumb from "@/components/breadcrumb";
import Layout from "@/components/layout/templates/default";
import { setLoading } from "@/redux/loading/loading";
import { fetchClient } from "@/utility/fetch-client";
import { useDispatch, useSelector } from "react-redux";
import StandardLayout from "./StandardLayout";

const ProductDetail = ({
  product,
  configurator,
  mainNavigation,
  footerNavigation,
  snippets,
  countries,
  languages,
  foreignKey,
  languageId,
}) => {
  const loading = useSelector((state) => state.loading.loading);
  const [eventViewItemIsFired, setEventFired] = useState(false);
  const [detail, setDetail] = useState(product);
  const [showAdditionalInfos, setShowAdditionalInfos] = useState(false);
  const [sizeTableImage, setSizeTableImage] = useState(null);

  useEffect(() => {
    if (detail && detail.length > 0) {
      Object.keys(detail.translated.customFields).map((key) =>
        key.indexOf("custom_netzkom_additional_product_infos") > -1
          ? setShowAdditionalInfos(true)
          : null
      );

      const sizeTableImageId =
        detail?.translated.customFields.custom_size_table_image;
      if (sizeTableImageId) {
        getMedia(sizeTableImageId).then((res) => {
          setSizeTableImage(res);
        });
      }

      const dataLayer = {
        event: "view_item",
        ecommerce: {
          currency: "EUR",
          value: detail.calculatedPrice?.unitPrice,
          items: [
            {
              item_id: detail.productNumber,
              item_name: detail.translated.name,
              index: 0,
              item_brand: process.env.NEXT_PUBLIC_BRAND_NAME,
              item_category: detail.seoCategory?.translated.name,
              price: detail.calculatedPrice?.unitPrice,
              quantity: 1,
            },
          ],
        },
      };
      if (eventViewItemIsFired === false) {
        gtag.dataLayer(dataLayer);
        setEventFired(true);
      }
    }
  }, [detail, eventViewItemIsFired]);

  useEffect(() => {
    if (detail) {
      /*
            fbEvent({
              eventName: 'ViewContent',
              currency: 'EUR',
              products: {
                sku: detailData.elements[0].productNumber,
                quantity: 1
              },
              value: detailData.elements[0].calculatedPrice?.unitPrice,
              enableStandardPixel: true,
              testEventCode: process.env.NEXT_PUBLIC_FB_TEST_EVENT_CODE
            });*/
    }
  }, [detail]);

  return (
    <Layout
      mainNavigation={mainNavigation}
      footerNavigation={footerNavigation}
      snippets={snippets}
      languages={languages}
      foreignKey={foreignKey}
    >
      <>
        <Breadcrumb
          breadcrumb={detail.seoCategory.breadcrumb}
          path={detail.seoCategory.seoUrls[0].seoPathInfo}
          languageId={languageId}
        />
        {(() => {
          if (detail.cmsPage.name === "Customizable") {
            return (
              <main>
                <CustomizableLayout
                  product={detail}
                  snippets={snippets}
                  configurator={configurator}
                  setLoading={setLoading}
                  setDetail={setDetail}
                  countries={countries}
                />
                <ProductSpecifications detail={detail} snippets={snippets} />
                <ProductSizeTable
                  data={detail.translated.customFields}
                  image={sizeTableImage}
                  snippets={snippets}
                />
              </main>
            );
          } else if (detail.cmsPage.name === "Exclusive") {
            return (
              <>
                <main>
                  <ExclusiveLayout
                    product={detail}
                    snippets={snippets}
                    setLoading={setLoading}
                  />
                  <ProductSpecifications detail={detail} snippets={snippets} />
                  <ProductSizeTable
                    data={detail.translated.customFields}
                    image={sizeTableImage}
                    snippets={snippets}
                  />
                </main>
              </>
            );
          } else {
            return (
              <main>
                <StandardLayout
                  product={detail}
                  snippets={snippets}
                  configurator={configurator}
                  setLoading={setLoading}
                  setDetail={setDetail}
                />
              </main>
            );
          }
        })()}
      </>
    </Layout>
  );
};

export default ProductDetail;

const getMedia = async (id) => {
  const res = await fetchClient({
    path: "media",
    method: "POST",
    body: {
      ids: [id],
    },
  });
  return res[0];
};

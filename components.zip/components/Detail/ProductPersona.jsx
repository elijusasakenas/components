import Image from "next/image";
import { useState } from "react";
import ProductPagination from "./ProductPagination";
import SizeChoose from "./SizeChoose";
import ColorChoose from "./ColorChoose";
import StatusBadge from "./StatusBadge";
import BuyButton from "./BuyButton";

export default function ProductPersona() {

    return (
        <div className="flex flex-col items-center text-base-50 pb-14 m-auto max-w-[830px]">
            <div className="flex px-6 flex-col items-start gap-4 pb-12">
                <div className="headline-large capitalize min-[744px]:justify-center flex w-full">
                    <h1 className="min-[744px]:text-center">Amber Road Trapez Select 2.3</h1>
                </div>
                <div className="body-small min-[744px]:text-center">
                    <p>Gebaut für große Abenteuer. Inklusive Tout Terrain Expedition Fork, Shimano 2x11 GRX-Gruppe und einem leichtgängigen 27,5&quot;-Laufradsatz. Perfekt für Bikepacking-Trips und Straßenabenteuer.</p>
                </div>
            </div>
            <div className="flex justify-center items-center">
                <Image
                    src={'/static/images/pdp-image.png'}
                    alt="Bike"
                    width={1800}
                    height={800}
                />
            </div>
            <div className="flex px-6 flex-col items-center gap-0.5 pt-12">
                <p className="body-extra-small text-base-300">Pictures schon are for illustration purpose only. Actual product may vary.</p>
            </div>
            <div className="flex py-8 justify-center items-center gap-[10px]">
                <ProductPagination />
            </div>
            <div className="flex flex-col items-start w-full px-6 min-[744px]:flex-row min-[744px]:gap-10">
                <div className="min-[744px]:max-w-[50%] w-full min-[744px]:border-r min-[744px]:pr-10">
                    <div className="w-full">
                        <SizeChoose />
                        <div className="flex flex-col ">
                            <div className="flex flex-col justify-center items-center py-2 px-3 rounded-lg border-base-50 border w-fit ">
                                <button className="MS1">So berechnest du deine grösse</button>
                            </div>
                        </div>
                        <ColorChoose />
                    </div>
                </div>
                <div className="min-[744px]:hidden w-full flex justify-center">
                    <svg xmlns="http://www.w3.org/2000/svg" width="342" height="2" viewBox="0 0 342 2" fill="none">
                        <path d="M0 0.964844H342" stroke="#E5E5E5" />
                    </svg>
                </div>
                <div className="flex flex-col items-start gap-6 w-full pt-10">
                    <div className="w-full">
                        <div className="w-fit">
                            <StatusBadge status="available" />
                        </div>
                    </div>
                    <div className="flex flex-col items-start gap-1 min-[744px]:min-w-[50%]">
                        <span className="headline-medium">3.349,00 € *</span>
                        <span className="body-extra-small">inkl. MwSt. <a className="text-link-xsmall">Versandkosten.</a></span>
                    </div>
                    <div className="flex flex-col items-start justify-center w-full">
                       <BuyButton available={false} />
                    </div>
                </div>
            </div>
        </div>
    );
}
import React, { useState, useRef, useEffect } from "react";

export default function ProductSpecifications({ detail, snippets }) {
  const [countProperties, setCountProperties] = useState(0);
  const [showAll, setShowAll] = useState(false);
  const headerRef = useRef(null);
  const toggleShowAll = () => {
    if (showAll) {
      headerRef.current.scrollIntoView({ behavior: "smooth", block: "start" });
    }
    setShowAll((prevShowAll) => !prevShowAll);
  };

  useEffect(() => {
    if (detail?.properties) {
      detail.properties.map((property) => {
        if (
          property.group.customFields?.custom_spezifikation_gruppe_true &&
          property.group.customFields.custom_spezifikation_gruppe_true === true
        ) {
          setCountProperties((prevCountProperties) => prevCountProperties + 1);
        }
      });
    }
  }, [detail]);

  if (!countProperties) {
    return null;
  }

  // Begrenze die Anzahl der angezeigten Einträge, wenn showAll false ist
  const displayedProperties = showAll
    ? detail.properties
    : detail.properties.slice(0, 6);

  return (
    detail.properties &&
    detail.properties.length > 0 && (
      <div ref={headerRef} className="flex flex-col bg-base-400 items-center">
        <div className="flex pt-14 px-6 md:px-12 xl:px-0 pb-8 flex-col justify-center gap-6 w-full max-w-7xl mx-auto">
          <h2 className="headline-large capitalize lg:mx-auto">
            {snippets.detail.specifications.title}
          </h2>
          <p className="B1 lg:mx-auto">
            {snippets.detail.specifications.text}
          </p>
        </div>

        {/* Übergangscontainer für die Eigenschaften */}
        <div
          className={`w-full px-6 md:px-12 xl:px-0 transition-all duration-300 ease-in-out overflow-hidden ${
            showAll ? "max-h-[1000px] opacity-100" : "max-h-96"
          }`}
        >
          <div className="min-[744px]:grid min-[744px]:grid-cols-2 min-[744px]:gap-x-14 min-[1024px]:grid-cols-3 max-w-7xl m-auto">
            {displayedProperties.map(
              (property, index) =>
                property.group.customFields?.custom_spezifikation_gruppe_true &&
                property.group.customFields.custom_spezifikation_gruppe_true ===
                  true && (
                  <div
                    key={index}
                    className="transition-opacity duration-300 ease-in-out"
                  >
                    <div className="flex pt-4 pb-2 flex-col items-start gap-4 flex-auto">
                      <div className="flex flex-col items-start gap-3 w-full border-t-[1px] border-base-300 pt-6">
                        <span className="B4">
                          {property.group.translated.name}{" "}
                        </span>
                        <p className="B1">{property.translated.name}</p>
                      </div>
                    </div>
                  </div>
                )
            )}
          </div>
        </div>

        <div className="flex pt-6 px-6 md:px-12 xl:px-0 pb-14 flex-col items-center gap-2 w-full lg:max-w-96">
          {countProperties > 6 && (
            <button className="btn-secondary w-full" onClick={toggleShowAll}>
              {showAll ? snippets.detail.specifications.less : snippets.detail.specifications.more}
            </button>
          )}
        </div>
      </div>
    )
  );
}

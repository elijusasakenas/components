
export default function StatusBadge({ status, deliveryTime, snippets }) {
  return (
    <div className={`badge ${status}`}>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        width="16"
        height="16"
        viewBox="0 0 16 17"
        fill="none"
      >
        <circle
          cx="8"
          cy="8.96289"
          r="8"
          fill={`${
            status === "available"
              ? "#14B8A6"
              : status === "not available"
              ? "#EF4444"
              : status === "limited stock"
              ? "#8B5CF6"
              : ""
          }`}
        />
      </svg>

      <span className="body-extra-small !leading-4">
        {status === "available"
          ? snippets.next.detail.deliveryShippingTime + deliveryTime
          : status === "not available"
          ? snippets.next.detail.deliveryNotAvailable
          : status === "limited stock"
          ? snippets.next.detail.deliveryLimitedStock
          : ""}
      </span>
    </div>
  );
}

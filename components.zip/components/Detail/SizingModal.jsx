import Script from "next/script";
import { useEffect } from "react";

export default function SizingModal({ bikeCode }) {
  useEffect(() => {
    const OZ_CONFIG = {
      settings: {
        apiKey: "oz_jxX9evxnrbn6ZSP9Cwzlb.rbUpjhkKyKGRB4bss6N4QofwNIRceJy",
        language: "de",
        primary: "hsl(187, 74%, 70%)",
        cta: "rgb(150, 186, 50)",
        buttonTextColor: "#FFF",
        roundness: "2px",
      },
    };
    
    window["___OnlineSizing"] = "oz";
    window["___OnlineSizingConfig"] = OZ_CONFIG;
  }, []);

  return (
    <div className="mb-10">
      <Script
        id={"oz"}
        src="https://widgets.onlinesizing.bike/loader.js"
        strategy="lazyOnload"
      />
      <button
        className="btn-secondary btn-small"
        id="my-custom-oz-button"
        data-oz-widget="sizing"
        data-oz-embed="custom"
        data-oz-code={bikeCode}
        data-oz-name="test"
        data-oz-image="bild"
        data-oz-fullscreen="true"
      >
        So berechnest du deine Grösse
      </button>
    </div>
  );
}

import React from "react";
import Image from "next/image";

export default function ProductSizeTable({data,image,snippets}) {
    let columns = [];
    const values = data?.custom_size_table_values;
    if(values) {
        const rows = values.split('\n');
        columns = rows.map((row) => row.split(';').map((cell) => cell.replace(/<br \/>/g, '')));
    }

    if(columns.length === 0) {
        return null;
    }

    return (
        values &&
        <div className="flex px-6 md:px-12 xl:px-0 w-full flex-col max-w-7xl m-auto py-14">
            <div className="flex pb-9 flex-col justify-center gap-6">
                <span className="headline-large min-[1024px]:text-center">{snippets.detail.sizetable.title}</span>
                <p className="B1 min-[1024px]:text-center">{snippets.detail.sizetable.text}</p>
            </div>
            <div className="flex flex-col w-full items-center">
                <table className="pdp-table max-w-[618px] w-full">
                    {columns.map((column, index) => (
                        index === 0 ? (
                            <thead key={index} className="text-left body-extra-small-emphasis">
                                <tr>
                                    {column.map((cell, index) => (
                                        <th key={index}>{cell}</th>
                                    ))}
                                </tr>
                            </thead>
                        ) : (
                            <tbody key={index} className={`text-left body-extra-small odd:bg-base-500 even:bg-base-400`}>
                                <tr>
                                    {column.map((cell, index) => (
                                        <td key={index}>{cell}</td>
                                    ))}
                                </tr>
                            </tbody>
                        )
                    ))}
                    
                </table>
            </div>
            {image && image.url && (
                <div className="py-24">
                    <Image src={image.url} alt={image.alt ? image.alt : 'size table'} width={image.metaData.width} height={image.metaData.height} />
                </div>
            )}
        </div>
    );

}
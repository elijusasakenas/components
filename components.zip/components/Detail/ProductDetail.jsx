import Image from "next/image";
import { useState } from "react";
import ProductPagination from "./ProductPagination";

export default function ProductDetail() {

    return (
        <div className="flex flex-col items-center text-base-50 pb-14 m-auto max-w-[830px]">
            <div className="flex px-6 flex-col items-start gap-4 pb-12">
                <div className="headline-large capitalize min-[744px]:justify-center flex w-full">
                    <h1 className="min-[744px]:text-center">Amber Road Trapez Select 2.3</h1>
                </div>
                <div className="body-small min-[744px]:text-center">
                    <p>Kombiniere den Komfort eines Trapezrahmens mit einer Shimano Alfine Getriebenabe. Ebenso komfortabel wie praktisch: der wartungsarme Gates Riemenantrieb und das Trekking-Zubehör.</p>
                </div>
            </div>
            <div className="flex justify-center items-center">
                <Image
                    src={'/static/images/pdp-image.png'}
                    alt="Bike"
                    width={1800}
                    height={800}
                />
            </div>
            <div className="flex px-6 flex-col items-center gap-0.5 pt-12">
                <p className="body-extra-small text-base-50">Die gezeigten Bilder dienen nur als Referenz, das tatsächliche Produkt kann abweichen.</p>
                <p className="body-extra-small text-base-300">Pictures schon are for illustration purpose only. Actual product may vary.</p>
            </div>
            <div className="flex py-8 justify-center items-center gap-[10px]">
                <ProductPagination />
            </div>
            <div className="min-[744px]:hidden">
                <svg xmlns="http://www.w3.org/2000/svg" width="342" height="2" viewBox="0 0 342 2" fill="none">
                    <path d="M0 0.964844H342" stroke="#E5E5E5" />
                </svg>
            </div>
            <div className="flex px-6 flex-col items-start pt-10 gap-6 min-[744px]:flex-row">
                <div className="flex flex-col items-start gap-1 min-[744px]:min-w-[50%]">
                    <span className="headline-medium">3.349,00 € *</span>
                    <span className="body-extra-small">inkl. MwSt.</span>
                </div>
                <div className="hidden min-[744px]:block">
                    <svg xmlns="http://www.w3.org/2000/svg" width="2" height="403" viewBox="0 0 2 403" fill="none">
                        <path d="M1 403L1 -1.04904e-05" stroke="#E5E5E5" />
                    </svg>
                </div>
                <div className="flex px-4 pt-4 pb-6 flex-col items-center gap-8 rounded-lg bg-base-400 min-[744px]:min-w-[45%]">
                    <div className="flex flex-col items-center gap-4">
                        <div>
                            <Image
                                src={'/static/images/exclusive-dealer.png'}
                                alt="Exclusive Dealer"
                                width={100}
                                height={79}
                            />
                        </div>
                        <div className="flex flex-col items-start gap-4">
                            <p className="headline-small text-base-50">Dieses Bike bekommst du nur beim Händler</p>
                            <p className="body-small text-base-50">Dieses Modell bauen wir für dich und schicken es dann zum Händler deiner Wahl. Der montiert es fertig und informiert dich, wann und wo du es abholen kannst.</p>
                        </div>
                    </div>
                    <div className="flex justify-center items-center w-full">
                        <button className="btn-primary text-sm w-full">Jetzt Händler finden</button>
                    </div>
                </div>
            </div>
        </div>
    );
}
import DisplayPrice from "@/components/Detail/DisplayPrice";
import ImageSlider from "@/components/Detail/ImageSlider";
import StoreRocketModal from "@/components/StoreLocator/StoreRocketModal";
import { useState } from "react";
import ExclusiveDealer from "../icons/exclusive-dealer";

const ExclusiveLayout = ({ product, snippets, setLoading }) => {
  const [isStoreLocatorOpen, setIsStoreLocatorOpen] = useState(false);
  const openStoreLocator = () => {
    setIsStoreLocatorOpen(true);
  };
  const closeStoreLocator = () => {
    setIsStoreLocatorOpen(false);
  };

  return (
      <div className="flex flex-col items-center text-base-50 pb-14 max-w-[830px] m-auto">
        <div className="flex px-6 md:px-16 xl:px-0 flex-col items-start gap-4 pb-4 w-full">
          <h1 className="headline-large capitalize md:mx-auto">
            {product.translated.name}
          </h1>
        </div>
        {product.translated.customFields && (
            <div
                className={
                  "body-small px-6 md:px-16 xl:px-0 max-w-full md:text-center mb-4"}>
              {product.translated.customFields.custom_product_sage_shortDescription}
            </div>
        )}
        <div className="w-full h-full pb-8 md:pb-14">
          {product.media && (
              <ImageSlider media={product.media} bottomSpace={true}/>
          )}
        </div>

        <div className="relative w-full">
          <div className="w-full flex px-6 flex-col items-center gap-0.5 pt-4 absolute -top-40  md:-top-38 inset-x-0">
            <p className="body-extra-small text-base-300">
              {snippets.detail.image.info}
            </p>
          </div>
        </div>

        <div className="w-full flex px-6 md:px-12 flex-col items-start pt-10 md:pt-0 gap-6 md:gap-10 md:flex-row">
          <div
              className="flex flex-col items-start gap-1 flex-1 md:border-r-[1px] md:border-base-400 md:pr-10 self-stretch">
            <DisplayPrice product={product} layout={"exclusive"}/>
          </div>
          <div
              className="flex px-4 md:px-6 pt-4 pb-6 flex-col items-center gap-8 rounded-lg bg-base-400 md:max-w-[342px]">
            <div className="flex flex-col items-center gap-4">
              <div>
                <ExclusiveDealer/>
              </div>
              <div className="flex flex-col items-start gap-4">
                <p className="headline-small text-base-50">
                  Dieses Bike bekommst du nur beim Händler
                </p>
                <p className="body-small text-base-50">
                  Dieses Modell bauen wir für dich und schicken es dann zum
                  Händler deiner Wahl. Der montiert es fertig und informiert dich,
                  wann und wo du es abholen kannst.
                </p>
              </div>
            </div>
            <div className="flex justify-center items-center w-full">
              <button
                  className="btn-primary text-sm w-full"
                  onClick={openStoreLocator}
              >
                Jetzt Händler finden
              </button>
              {isStoreLocatorOpen && (
                  <StoreRocketModal
                      isStoreLocatorOpen={isStoreLocatorOpen}
                      closeStoreLocator={closeStoreLocator}
                  />
              )}
            </div>
          </div>
        </div>
        <div
            className={
              "body-small px-6 md:px-16 xl:px-0 max-w-full mb-4 mt-12"
            }
            dangerouslySetInnerHTML={{__html: product.translated.description}}
        />
      </div>
  );
};

export default ExclusiveLayout;

import BuyForm from "@/components/Detail/BuyForm";
import ImageSlider from "@/components/Detail/ImageSlider";

const CustomizableLayout = ({
  product,
  snippets,
  configurator,
  setLoading,
  setDetail,
  countries,
}) => {
  return (
      <div className="flex flex-col items-center text-base-50 pb-14 max-w-[830px] m-auto">
          <div className="flex px-6 md:px-16 xl:px-0 flex-col items-start gap-4 pb-4 w-full">
              <h1 className="headline-large capitalize md:mx-auto">
                  {product.translated.name}
              </h1>
          </div>
          {product.translated.customFields && (
              <div
                  className={
                      "body-small px-6 md:px-16 xl:px-0 max-w-full md:text-center mb-4"}>
                  {product.translated.customFields.custom_product_sage_shortDescription}
              </div>
          )}
          <div className="w-full h-full pb-8 md:pb-14">
              {product.media && (
                  <ImageSlider media={product.media} bottomSpace={true}/>
              )}
          </div>
          <div className="relative w-full">
              <div
                  className="w-full flex px-6 flex-col items-center gap-0.5 pt-4 absolute -top-40  md:-top-38 inset-x-0">
                  <p className="body-extra-small text-base-300">
                      {snippets.detail.image.info}
                  </p>
              </div>
          </div>
          <div className="-mt-12 w-full">
              <BuyForm
                  product={product}
                  snippets={snippets}
                  configurator={configurator}
                  setLoading={setLoading}
                  layout={"customizable"}
                  setDetail={setDetail}
                  countries={countries}
              />
          </div>
          <div
              className={
                  "body-small px-6 md:px-16 xl:px-0 max-w-full mb-4 mt-12"
              }
              dangerouslySetInnerHTML={{__html: product.translated.description}}
          />
      </div>
)
    ;
};

export default CustomizableLayout;

import BuyButton from "@/components/Detail/BuyButton";
import ColorChoose from "@/components/Detail/ColorChoose";
import DisplayPrice from "@/components/Detail/DisplayPrice";
import SizeChose from "@/components/Detail/SizeChoose";
import SizingModal from "@/components/Detail/SizingModal";
import StatusBadge from "@/components/Detail/StatusBadge";
import { useState } from "react";

const BuyForm = ({
  product,
  snippets,
  configurator,
  setDetail,
  layout,
  countries,
}) => {
  const [activeOptions, setActiveOptions] = useState([]);

  return (
    activeOptions && (
      <div className="flex min-[744px]:flex-row flex-col w-full pb-8 pt-8 ">
        <div className="px-6 md:pl-12 md:pr-10 lg:pl-0 w-full border-b-[1px] border-base-400 md:border-b-0 md:border-r-[1px]">
          <SizeChose
            product={product}
            configurator={configurator}
            setDetail={setDetail}
            activeOptions={activeOptions}
            setActiveOptions={setActiveOptions}
            snippets={snippets}
          />
          
          <ColorChoose
            product={product}
            configurator={configurator}
            setDetail={setDetail}
            activeOptions={activeOptions}
            setActiveOptions={setActiveOptions}
            snippets={snippets}
          />
        </div>
        <div className="flex px-6 md:pl-10 md:pr-12 lg:pr-0 flex-col gap-6 min-[744px]:min-w-[50%] pt-10 min-[744px]:pt-0 min-[744px]:pl-10">
          <div className="flex w-full">
            {product?.deliveryTime && (
              <StatusBadge
                status="available"
                deliveryTime={product.deliveryTime.translated.name}
                snippets={snippets}
              />
            )}
          </div>
          <div className="flex flex-col items-start gap-1 min-[744px]:min-w-[50%]">
            <DisplayPrice product={product} snippets={snippets} />
          </div>
          <div className="w-full flex flex-col justify-center items-center">
            <BuyButton
              available={true}
              customizable={layout === "customizable"}
              product={product}
              countries={countries}
              snippets={snippets}
            />
          </div>
        </div>
      </div>
    )
  );
};

export default BuyForm;

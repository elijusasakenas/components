// Import Swiper React components
import { Swiper, SwiperSlide } from "swiper/react";
import React, { useRef, useState } from "react";

import "swiper/css";
import "swiper/css/pagination";

import { Pagination } from "swiper/modules";
import Image from "next/image";

export default function ImageSlider({ media, bottomSpace }) {
  const pagination = {
    clickable: true,
    bulletElement: "button",
    currentClass: "bg-orange-200 w-8",
    renderBullet: function (index, className) {
      return '<button class="w-2 h-2 rounded-[10px] ' + className + '" />';
    },
  };
  
  return (
    <>
      <Swiper
        pagination={pagination}
        modules={[Pagination]}
        className={`imageSwiper flex flex-col gap-3 ${bottomSpace ? "!pb-24 md:!pb-12" : "!pb-6"}`}
      >
        {media.map((item, index) => (
          <SwiperSlide key={index}>
            <Image
              alt={item.media.alt ? item.media.alt : "Product image"}
              title={
                item.media.translated.title
                  ? item.media.translated.title
                  : "Product image"
              }
              src={item.media.url}
              width={item.media.metaData.width}
              height={item.media.metaData.height}
              className="h-64 md:h-[490px] lg:h-[600px] w-auto object-contain mx-auto"
            />
          </SwiperSlide>
        ))}
      </Swiper>
    </>
  );
}

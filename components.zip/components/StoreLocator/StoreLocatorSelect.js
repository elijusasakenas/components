"use client";

import { useEffect, useRef, useState } from "react";
import {
  fetchStoreRocketLocations,
  filterStoresByRadius,
  getGeoDataFromPostalCodeOrCity,
  StoreList,
  fetchSuggestions,
} from "@/components//StoreLocator/StoreRocket";
import {
  FormControl,
  InputLabel,
  MenuItem,
  Select,
  TextField,
} from "@mui/material";
import Link from "next/link";

export default function StoreLocatorSelect({ onSelect, snippets }) {
  const [stores, setStores] = useState([]);
  const [filteredStores, setFilteredStores] = useState([]);
  const [locationInput, setLocationInput] = useState("");
  const [suggestions, setSuggestions] = useState([]);
  const [selectedGeoData, setSelectedGeoData] = useState(null);
  const [radius, setRadius] = useState(10);
  const [showSuggestionList, setShowSuggestionList] = useState(false);
  const [showStoreList, setShowStoreList] = useState(false);
  const containerRef = useRef(null);
  const [selectedSuggestionIndex, setSelectedSuggestionIndex] = useState(-1);

  // Fetch store locations when the component is mounted
  useEffect(() => {
    const fetchStores = async () => {
      const storesData = await fetchStoreRocketLocations();
      setStores(storesData.data);
    };
    fetchStores();
  }, []);

  // Refetch filtered stores when the radius changes
  useEffect(() => {
    const applyStoreFilterInEffect = (geoData) => {
      const filtered = filterStoresByRadius(
        geoData.latitude,
        geoData.longitude,
        stores.filter((store) => store.visible), // Filter stores with visible = true,
        radius // Apply the current radius
      );
      setFilteredStores(filtered);

      setShowStoreList(true);
    };

    if (selectedGeoData) {
      applyStoreFilterInEffect(selectedGeoData);
    }
  }, [radius, selectedGeoData, stores]);

  const handleInputChange = (e) => {
    const query = e.target.value;
    setLocationInput(query);
    fetchSuggestions(query, setSuggestions, setShowSuggestionList);
  };

  const handleRadiusChange = (e) => {
    setRadius(Number(e.target.value)); // Update the radius and trigger filtering
  };

  const onStoreClick = (store) => {
    setShowStoreList(false);
    onSelect(store);
  };

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (
        containerRef.current &&
        !containerRef.current.contains(event.target)
      ) {
        setShowSuggestionList(false);
        setShowStoreList(false);
      }
    };

    const handleKeyDown = (event) => {
      if (event.key === "Escape") {
        setShowSuggestionList(false);
        setShowStoreList(false);
      } else if (event.key === "ArrowDown") {
        setSelectedSuggestionIndex(
          (prevIndex) => (prevIndex + 1) % suggestions.length
        );
      } else if (event.key === "ArrowUp") {
        setSelectedSuggestionIndex(
          (prevIndex) =>
            (prevIndex - 1 + suggestions.length) % suggestions.length
        );
      } else if (event.key === "Enter" && selectedSuggestionIndex >= 0) {
        handleSearch(suggestions[selectedSuggestionIndex]);
      }
    };

    const handleSearch = async (place) => {
      if (!place) return;
      try {
        const geoData = {
          latitude: place.center[1],
          longitude: place.center[0],
          placeName: place.place_name,
        };

        setSelectedGeoData(geoData); // Save selected geolocation

        setLocationInput(geoData.placeName); // Set selected suggestion in the input field
        applyStoreFilter(geoData);
        setSuggestions([]); // Clear suggestions after selection
      } catch (error) {
        console.error("Error fetching geo data:", error);
      }
    };

    const applyStoreFilter = (geoData) => {
      const filtered = filterStoresByRadius(
        geoData.latitude,
        geoData.longitude,
        stores.filter((store) => store.visible), // Filter stores with visible = true,
        radius // Apply the current radius
      );
      setFilteredStores(filtered);

      setShowStoreList(true);
    };

    document.addEventListener("mousedown", handleClickOutside);
    document.addEventListener("keydown", handleKeyDown);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
      document.removeEventListener("keydown", handleKeyDown);
    };
  }, [
    setShowSuggestionList,
    setShowStoreList,
    suggestions,
    selectedSuggestionIndex,
    stores,
    radius,
  ]);

  return (
    <div
      ref={containerRef}
      className="w-full p-4 mt-4 mb-4 overflow-hidden border rounded-lg bg-white shadow  border-primary"
    >
      <p className="body-extra-small-emphasis mb-4">
        {snippets.next.checkout.address.shippingAddress.storeLocator.text}
      </p>
      <div className="flex items-center gap-4 w-full mt-4">
        <div className="flex-grow w-2/3">
          <TextField
            sx={{
              "& .MuiOutlinedInput-input:focus": {
                boxShadow: "none",
              },
            }}
            error={false}
            helperText=""
            label={
              snippets.next.checkout.address.shippingAddress.storeLocator.label
            }
            type="text"
            id="CityPostCode"
            name="city"
            fullWidth
            size="small"
            value={locationInput}
            autoComplete="new-password"
            onChange={handleInputChange}
          />
          {/* Display autocomplete suggestions */}
          {suggestions.length > 0 && showSuggestionList && (
            <ul className="absolute z-10 mt-1 w-full max-h-60 overflow-y-auto border border-gray-300  bg-white shadow-lg">
              {suggestions.map((suggestion, index) => (
                <li
                  key={suggestion.id}
                  className={`p-3 cursor-pointer hover:bg-gray-100 transition-colors duration-200 body-small ${
                    index === selectedSuggestionIndex ? "bg-gray-200" : ""
                  }`}
                  onClick={() => handleSearch(suggestion)}
                >
                  {suggestion.place_name}
                </li>
              ))}
            </ul>
          )}
        </div>
        {/* Radius selection dropdown */}
        <div className="w-1/3">
          <FormControl
            sx={{ m: 0, minWidth: "100%" }}
            size="small"
            className="bg-white"
          >
            <InputLabel id="demo-select-small-label">
              {
                snippets.next.checkout.address.shippingAddress.storeLocator
                  .radius
              }
            </InputLabel>
            <Select
              labelId="radius-label"
              id="radius"
              name="radius"
              value={radius}
              label={
                snippets.next.checkout.address.shippingAddress.storeLocator
                  .radius
              }
              onChange={handleRadiusChange}
            >
              <MenuItem key="radius10" value="10">
                10 km
              </MenuItem>
              <MenuItem key="radius20" value="20">
                20 km
              </MenuItem>
              <MenuItem key="radius50" value="50">
                50 km
              </MenuItem>
              <MenuItem key="radius100" value="100">
                100 km
              </MenuItem>
              <MenuItem key="radius250" value="250">
                250 km
              </MenuItem>
            </Select>
          </FormControl>
        </div>
      </div>
      {/* Store List component with filtered stores */}
      {showStoreList && (
        <div className="absolute z-10 mt-2 w-full">
          {filteredStores.length > 0 ? (
            <StoreList
              filteredStores={filteredStores}
              onStoreClick={onStoreClick}
            />
          ) : (
            <div className="p-4 border border-gray-300 shadow-lg bg-white">
              <p className="body-small text-gray-600">
                {
                  snippets.next.checkout.address.shippingAddress.storeLocator
                    .noDealer
                }
              </p>
            </div>
          )}
        </div>
      )}
      {/* Button to show the store list again */}
      {!showStoreList && filteredStores.length > 0 && (
        <Link
          href={"#"}
          className="mt-4 body-small  text-link"
          onClick={(event) => {
            event.preventDefault();
            setShowStoreList(true);
          }}
        >
          {
            snippets.next.checkout.address.shippingAddress.storeLocator
              .dealerListLink
          }
        </Link>
      )}
    </div>
  );
}

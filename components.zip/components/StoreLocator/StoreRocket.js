const storeRocketToken      = process.env.NEXT_PUBLIC_STOREROCKET_API_TOKEN;
const storeRocketProjectId  = process.env.NEXT_PUBLIC_STOREROCKET_PROJECT_ID;
const mapBoxToken           = process.env.NEXT_PUBLIC_MAPBOX_API_TOKEN;

const storeRocketOptions = {
    method: 'GET',
    headers: {
        'Authorization': `Bearer ${storeRocketToken}`,
        'Accept': 'application/json',
        'Content-Type': 'application/json'
    }, next: { revalidate: 60 }
}

export const fetchStoreRocketLocations = async () => {
    return await fetch(`https://storerocket.io/api/v2/projects/${storeRocketProjectId}/locations?includeFilters=true&includeFields=true&includeHours=true&includeCallsToAction=true&limit=100`, storeRocketOptions
    ).then((response) => {
        return response.json();
    });

};

export const filterStoresByRadius = (userLat, userLon, stores, radius) => {
    return stores.filter((store) => {
        const distance = calculateDistance(
            userLat,
            userLon,
            store.lat,
            store.lng
        );

        return distance <= radius; // Filtert alle Stores im gewünschten Radius
    });
};

function calculateDistance(lat1, lon1, lat2, lon2) {
    const R = 6371; // Radius der Erde in Kilometern
    const dLat = (lat2 - lat1) * (Math.PI / 180);
    const dLon = (lon2 - lon1) * (Math.PI / 180);

    const a =
        Math.sin(dLat / 2) * Math.sin(dLat / 2) +
        Math.cos(lat1 * (Math.PI / 180)) *
        Math.cos(lat2 * (Math.PI / 180)) *
        Math.sin(dLon / 2) * Math.sin(dLon / 2);

    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
     // Entfernung in Kilometern
    return R * c;
}

export  function StoreList ({ filteredStores, onStoreClick }){
    return (
        <div className="flex flex-col gap-2 bg-white">
            {filteredStores.map((store) => (
                <div
                    key={store.id}
                    className="p-4 border border-gray-300 shadow-lg hover:bg-gray-100 cursor-pointer transition-colors duration-200"
                    onClick={() => onStoreClick(store)}
                >
                    <p className="body-small font-semibold mb-2">{store.name}</p>
                    <p className="body-small text-gray-600">{store.address}</p>
                    <div class="flex justify-end">
                        <p className={"button btn-primary btn-small"} >Auswählen</p>
                    </div>
                </div>
            ))}
        </div>
    );
};
export const getGeoDataFromPostalCodeOrCity = async (location) => {
    const url = `https://api.mapbox.com/geocoding/v5/mapbox.places/${encodeURIComponent(location)}.json?access_token=${mapBoxToken}&limit=1`;
    try {
        const response = await fetch(url);
        const data = await response.json();

        if (data.features && data.features.length > 0) {
            const {center, place_name} = data.features[0]; // 'center' enthält [longitude, latitude]
            return {
                longitude: center[0],
                latitude: center[1],
                placeName: place_name
            };
        } else {
            throw new Error("Ort oder PLZ wurde nicht gefunden.");
        }
    } catch (error) {
        console.error("Fehler beim Abrufen der Geodaten:", error);
        return null;
    }
};

export const fetchSuggestions = async (query,setSuggestions,setShowSuggestionList) => {
    if (!query) return;
    const response = await fetch(
        `https://api.mapbox.com/geocoding/v5/mapbox.places/${query}.json?access_token=${mapBoxToken}&autocomplete=true&limit=5&country=DE`
    );
    const data = await response.json();
    setSuggestions(data.features);
    setShowSuggestionList(true);
};

import { setOpen } from '@/redux/StoreRocketModal/StoreRocketModal';
import { useSelector, useDispatch } from 'react-redux';


export default function StoreRocketModal({ closeStoreLocator }) {
    const dispatch = useDispatch();
    const storeRocketModalOpen = useSelector((state) => state.storeRocketModal.open);

    return (
        storeRocketModalOpen &&
        <div className="modal w-[100%] h-screen z-[10000] fixed flex items-center justify-center left-0 top-0 bg-opacity-20 bg-base-50">
            <div className="modal-content fixed w-[100%] h-[100%] md:w-[80%] md:h-[90%] bg-white p-4 justify-center">
                <span className="close float-end relative cursor-pointer" onClick={() => dispatch(setOpen(false))}>&times;</span>
                {/* Laden der StoreRocket-Seite in einem iframe */}
                <iframe
                    src="/store-locator.html"
                    width="100%"
                    height="95%"
                    style={{ border: 'none' }}
                    title="StoreRocket Store Locator"
                />
            </div>
        </div>
    );
}
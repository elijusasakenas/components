import { Dialog, Transition } from "@headlessui/react";
import { XMarkIcon } from "@heroicons/react/24/outline";
import cookie from "js-cookie";
import { Fragment, useEffect, useState } from "react";
import dynamic from 'next/dynamic';
import axiosInstance from "@/shopware/client";

const CenteredCard = dynamic(() => import("@/components/home/centered-card"), {
  ssr: false,
});

const Invader = () => {
  const invaderId = "netzkom-invader";
  const invader_delay = 30;
  const expirationDays = 7;
  const invader_show = "enter";
  const utmSource = "newsletter";

  const [open, setOpen] = useState(false);

  useEffect(() => {
    cookie.set("netzkom-invader-hiding-allowed", true, 7);
    /**
     * init the plugin
     */
    const _newsletterForm = false; //el.querySelector("[data-invader-newsletter-form]");
    const isAllowed = cookie.get("netzkom-invader-hiding-allowed");
    const utm_source = getUrlVars()["utm_source"];
    const hasClosedInvader = cookie.get(`hasClosedNetzkomInvader-${invaderId}`);

    if (_newsletterForm) {
      _newsletterForm
        .querySelector("button")
        .addEventListener("click", _sendAjaxFormSubmit());
    }

    if (isAllowed && !hasClosedInvader && utm_source !== utmSource) {
      start();
    }

    /**
     * start the invader
     */
    function start() {
      if (!hasClosedInvader && utm_source !== utmSource) {
        if (invader_show === "leave") {
          const $body = document.body;
          /**
           * bind the event handler on the html element
           * and unbind it when the modal is there
           * 'cause we don't want to annoy our customers
           *
           */
          if (
            $body.classList.contains("is-ctl-checkout") ||
            $body.classList.contains("is-ctl-auth")
          ) {
            /**
             * no modal within the checkout?
             */
          } else {
            document.addEventListener("mouseleave", function () {
              show();
            });
          }
        } else {
          /**
           * set a timeout function 'cause of the delay
           * from the element configuration
           */
          setTimeout(function () {
            show();
          }, invader_delay * 1000);
        }
      }
    }
  }, []);

  /**
   * show an element
   * @param el
   */
  function show() {
    setOpen(true);
  }

  /**
   * hide an element
   * @param el
   */
  function hide() {
    setOpen(false);
    onCloseInvader();
  }

  /**
   * close the invader
   * @param el
   */
  function onCloseInvader(el) {
    cookie.set(`hasClosedNetzkomInvader-${invaderId}`, true, expirationDays);
  }

  /**
   * helper method to get the url query string
   * @returns {Array}
   */
  function getUrlVars() {
    const vars = [];
    let hash;
    const hashes = window.location.href
      .slice(window.location.href.indexOf("?") + 1)
      .split("&");
    for (let i = 0; i < hashes.length; i++) {
      hash = hashes[i].split("=");
      vars.push(hash[0]);
      vars[hash[0]] = hash[1];
    }
    return vars;
  }

  async function _sendAjaxFormSubmit(event) {
    event.preventDefault();
    const eventFormData = new FormData(event.target);
    const formData = Object.fromEntries(eventFormData);

    await axiosInstance
      .post("/newsletter/subscribe", formData)
      .then(function (res) {
        console.log(res);
        //res.data ? state = true : state = false;
      })
      .catch(function (error) {
        console.log(error);
        setFormMessage(error.message);
      });

    setFormMessage(
      "Vielen Dank für Ihre Anmeldung. Sie erhalten in Kürze eine E-Mail mit einem Bestätigungslink."
    );
  }

  return (
    <Transition.Root show={open} as={Fragment}>
      <Dialog as="div" className="relative z-50" onClose={hide}>
        <Transition.Child
          as={Fragment}
          enter="ease-out duration-300"
          enterFrom="opacity-0"
          enterTo="opacity-100"
          leave="ease-in duration-200"
          leaveFrom="opacity-100"
          leaveTo="opacity-0"
        >
          <div className="fixed inset-0 bg-neutral-500 bg-opacity-75 transition-opacity" />
        </Transition.Child>

        <div
          className={
            "fixed inset-0 z-50 overflow-y-auto"
          }
        >
          <div className="flex min-h-full min-w-full justify-center text-center items-center p-0">
            <Transition.Child
              as={Fragment}
              enter="ease-out duration-300"
              enterFrom="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
              enterTo="opacity-100 translate-y-0 sm:scale-100"
              leave="ease-in duration-200"
              leaveFrom="opacity-100 translate-y-0 sm:scale-100"
              leaveTo="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
            >
              <Dialog.Panel className="relative transform overflow-hidden text-left transition-all w-full max-w-3xl p-2">
                <XMarkIcon
                  className="w-8 h-8 text-white hover:text-orange-500 absolute top-0 right-0 z-40 cursor-pointer mr-4 mt-10 sm:mr-8 md:mr-4 lg:mt-14 lg:mr-12 xl:mr-4"
                  aria-hidden="true"
                  onClick={hide}
                />
                <CenteredCard setOpen={setOpen} />
              </Dialog.Panel>
            </Transition.Child>
          </div>
        </div>
      </Dialog>
    </Transition.Root>
  );
};

export default Invader;

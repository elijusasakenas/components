"use client";

import Header from "@/components/layout/checkout/header";
import Footer from "@/components/layout/footer";
import Notifications from "@/components/Notifications";
import { setSwCart } from "@/redux/cart/cart";
import {
  setMainNavigation,
  setSwFooterNavigation,
} from "@/redux/navigation/navigation";
import { setSnippets } from "@/redux/snippets/snippets";
import { FetchOrCreateSwCart } from "@/shopware/cart";
import { useEffect } from "react";
import { useDispatch } from "react-redux";

export default function LayoutCheckout({
  children,
  mainNavigation,
  footerNavigation,
  snippets,
}) {
  const dispatch = useDispatch();
  const cart = FetchOrCreateSwCart();

  useEffect(() => {
    if (cart !== null) {
      // Set the cart in the redux store
      dispatch(setSwCart(cart));
    }
  }, [cart, dispatch]);

  useEffect(() => {
    // main navigation
    if (mainNavigation !== null) {
      // Set the navigation in the redux store
      dispatch(setMainNavigation(mainNavigation));
    }

    // footer navigation
    if (footerNavigation !== null) {
      // Set the footer navigation in the redux store
      dispatch(setSwFooterNavigation(footerNavigation));
    }

    // snippets
    if (snippets !== null) {
      // Set the snippets in the redux store
      dispatch(setSnippets(snippets));
    }
  });

  return (
    <>
      <Header />
      {children}
      <Footer />
      <Notifications />
    </>
  );
}

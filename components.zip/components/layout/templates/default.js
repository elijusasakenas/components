"use client";

import { init } from "@socialgouv/matomo-next";
import { usePathname } from "next/navigation";
import { useEffect } from "react";
import * as utilityGtag from "utility/gtag";
import { setSwCart } from "@/redux/cart/cart";
import { setMainNavigation, setSwFooterNavigation } from "@/redux/navigation/navigation";
import { setPromotion } from "@/redux/promotion/promotion";
import { setSnippets } from "@/redux/snippets/snippets";
import { FetchOrCreateSwCart } from "@/shopware/cart";
import { GetPromotion } from "@/shopware/promotion";
import { useDispatch } from "react-redux";
import Notifications from "@/components/Notifications";
import OffCanvasCart from "@/components/layout/cart/off-canvas-cart";
import Footer from "@/components/layout/footer";
import Header from "@/components/layout/header";
import ProductMeta from "@/components/meta/product";
import Meta from "@/components/meta/static";
import { getContextToken } from "@/shopware/context";
import StoreRocketModal from "@/components/StoreLocator/StoreRocketModal";

export default function Layout({
  children,
  metaData,
  metaDataProduct,
  mainNavigation,
  footerNavigation,
  snippets,
  languages,
  foreignKey,
}) {
  const pathname = usePathname();
  const dispatch = useDispatch();

  useEffect(() => {
    // context token
    getContextToken();

    // Google Tag Manager
    utilityGtag.pageview(process.env.NEXT_PUBLIC_SITE_URL + pathname);

    return () => {
      // Init Matomo
      if (
        process.env.NEXT_PUBLIC_MATOMO_URL &&
        process.env.NEXT_PUBLIC_MATOMO_SITE_ID
      )
        init({
          url: process.env.NEXT_PUBLIC_MATOMO_URL,
          siteId: process.env.NEXT_PUBLIC_MATOMO_SITE_ID,
        });
    };
  }, [pathname]);

  /**
   * Redux Store
   * Loading cart, navigation, snippets and promotion data from Shopware API
   */

  const cart = FetchOrCreateSwCart();

  useEffect(() => {
    if (cart !== null) {
      // Set the cart in the redux store
      dispatch(setSwCart(cart));
    }
  }, [cart, dispatch]);

  useEffect(() => {

    // main navigation
    if (mainNavigation !== null) {
      // Set the navigation in the redux store
      dispatch(setMainNavigation(mainNavigation));
    }

    // footer navigation
    if (footerNavigation !== null) {
      // Set the footer navigation in the redux store
      dispatch(setSwFooterNavigation(footerNavigation));
    }

    // snippets
    if (snippets !== null) {
      // Set the snippets in the redux store
      dispatch(setSnippets(snippets));
    }
  });

  let promotionData = null;
  if (process.env.NEXT_PUBLIC_HEADER_PROMO_ID)
    promotionData = GetPromotion(process.env.NEXT_PUBLIC_HEADER_PROMO_ID);

  useEffect(() => {
    if (promotionData !== null) {
      // Set the promotion in the redux store
      dispatch(setPromotion(promotionData));
    }
  }, [promotionData, dispatch]);

  return (
    <>
      <Header languages={languages} foreignKey={foreignKey} snippets={snippets} />
      <div>{children}</div>
      <Footer snippets={snippets} />
      {metaData && <Meta item={metaData} />}
      {metaDataProduct && <ProductMeta product={metaDataProduct} />}
      <Notifications />
      <OffCanvasCart snippets={snippets} />
      <StoreRocketModal />
    </>
  );
}

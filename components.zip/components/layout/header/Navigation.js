"use client";

import { Card } from "@/components/layout/header/Card";
import { setMobileMenuOpen } from "@/redux/navigation/navigation";
import {
  Popover,
  PopoverBackdrop,
  PopoverButton,
  PopoverGroup,
  Transition,
  TransitionChild,
} from "@headlessui/react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { Fragment, useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  NavigationLayoutAboutUs,
  NavigationLayoutBlog,
  NavigationLayoutDefault,
  NavigationLayoutShop,
} from "./Navigation/Layouts";

function classNames(...classes) {
  return classes.filter(Boolean).join(" ");
}

/**
 *
 * @returns {JSX.Element}
 * @constructor
 */
export function MainNavigation() {
  const mainNavigationData = useSelector(
    (state) => state.navigation.mainNavigation
  );
  const pathname = usePathname();
  let rootPath = null;

  return (
    <>
      {/* Flyout menus */}
      {mainNavigationData && mainNavigationData.length > 0 && (
        <PopoverGroup className="main-navigation hidden lg:block">
          <div className={"w-full flex items-center justify-start z-50"}>
            {mainNavigationData.map((category) => (
              <div className="w-full h-full text-center" key={category.id}>
                {category.childCount === 0 ? (
                  // category type: link
                  category.type === "link" ? (
                    // link type === external
                    (category.linkType === "external" && (
                      <Link
                        href={`${category.externalLink}`}
                        title={`${category.translated.name}`}
                        target={`${category.linkNewTab ? "_blank" : "_self"}`}
                        className={`navbar navbar-item ${
                          pathname.substring(1) ===
                            category.seoUrls[0].seoPathInfo && "active"
                        }`}
                      >
                        {category.name}
                      </Link>
                    )) ||
                    // link type === category, product, landing_page
                    ((category.linkType === "category" ||
                      category.linkType === "product" ||
                      category.linkType === "landing_page") && (
                      <Link
                        href={`${category.seoUrl}`}
                        title={`${category.translated.name}`}
                        target={`${category.linkNewTab ? "_blank" : "_self"}`}
                        className={`navbar navbar-item ${
                          pathname.substring(1) ===
                            category.seoUrls[0].seoPathInfo && "active"
                        }`}
                      >
                        {category.name}
                      </Link>
                    ))
                  ) : (
                    <Link
                      href={`${category.seoUrl}`}
                      title={`${category.translated.name}`}
                      className={`navbar navbar-item ${
                        pathname.substring(1) ===
                          category.seoUrls[0].seoPathInfo && "active"
                      }`}
                    >
                      {category.name}
                    </Link>
                  )
                ) : (
                  <Popover
                    className={`w-full flex justify-center items-center relative`}
                  >
                    {({ open, close }) => (
                      (rootPath = pathname.substring(1).split("/")[0] + "/"),
                      (
                        <>
                          {(category.name === "Online Shop" || category.name === "The Products") && (
                            <div className="px-2 xl:px-4">
                              <svg
                                xmlns="http://www.w3.org/2000/svg"
                                width="2"
                                height="36"
                                viewBox="0 0 2 36"
                                fill="none"
                              >
                                <path d="M1 0V36" stroke="#394451" />
                              </svg>
                            </div>
                          )}

                          <PopoverButton
                            as="a"
                            href="#"
                            className={classNames(
                              rootPath === category.seoUrls[0].seoPathInfo
                                ? "open"
                                : "",
                              open ? "active" : "",
                              "navbar navbar-item"
                            )}
                          >
                            {category.name}
                          </PopoverButton>

                          {category.translated.customFields
                            .custom_b2c_settings_menu_layout === "default" && (
                            <NavigationLayoutDefault category={category} closeMenu={close} />
                          )}
                          {category.translated.customFields
                            .custom_b2c_settings_menu_layout === "blog" && (
                            <NavigationLayoutBlog category={category} closeMenu={close} />
                          )}
                          {category.translated.customFields
                            .custom_b2c_settings_menu_layout === "about_us" && (
                            <NavigationLayoutAboutUs category={category} closeMenu={close} />
                          )}

                          {category.translated.customFields
                            .custom_b2c_settings_menu_layout === "shop" && (
                            <NavigationLayoutShop
                              category={category}
                              closeMenu={close}
                            />
                          )}
                        </>
                      )
                    )}
                  </Popover>
                )}
              </div>
            ))}
          </div>
        </PopoverGroup>
      )}
    </>
  );
}

export function MainMobileNavigation({ popoverClose }) {
  const [selectedIndex, setSelectedIndex] = useState(null);
  const [defaultIndex, setDefaultIndex] = useState(0);
  const cartOpen = useSelector((state) => state.cart.open);
  const swCart = useSelector((state) => state.cart.swCart);
  const [openMobileSearchBar, setOpenMobileSearchBar] = useState(false);

  const router = useRouter();
  const mainNavigationData = useSelector(
    (state) => state.navigation.mainNavigation
  );
  const mobileMenuOpen = useSelector(
    (state) => state.navigation.mobileMenuOpen
  );
  const dispatch = useDispatch();
  const pathname = usePathname();

  const onClickLink = async (e, href) => {
    e.preventDefault();
    router.push(href);
    dispatch(setMobileMenuOpen(false));
  };

  useEffect(() => {
    const getIndexFromMainNavigation = (pathname) => {
      if (mainNavigationData) {
        for (let i = 0; i < mainNavigationData.length; i++) {
          if (mainNavigationData[i].seoUrls[0].seoPathInfo === pathname) {
            return i;
          }
        }
      }
    };

    if (pathname === "/") {
      setDefaultIndex(0);
    } else {
      const rootPath = pathname.substring(1).split("/")[0] + "/";
      setDefaultIndex(getIndexFromMainNavigation(rootPath));
    }
  }, [selectedIndex, pathname, mainNavigationData]);

  const [isStoreLocatorOpen, setIsStoreLocatorOpen] = useState(false);
  const openStoreLocator = () => {
    setIsStoreLocatorOpen(true);
  };
  const closeStoreLocator = () => {
    setIsStoreLocatorOpen(false);
  };

  return (
    <>
      {/* Mobile menu */}
      {mainNavigationData && mainNavigationData.length > 0 && (
        <Card
          isStoreLocatorOpen={isStoreLocatorOpen}
          openStoreLocator={openStoreLocator}
          closeStoreLocator={closeStoreLocator}
          popoverClose={popoverClose}
        />
      )}
    </>
  );
}

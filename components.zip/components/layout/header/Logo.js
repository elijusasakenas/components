import LogoIcon from "@/components/icons/logo";
import LogoMobile from "@/components/icons/logo-mobile";
import { setLogoMode, setLogoVariant } from "@/redux/header/logo";
import useScreenSize from "@/utility/useScreenSize";
import PropTypes from "prop-types";
import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";

function Logo() {
  const dispatch = useDispatch();
  const screenSize = useScreenSize();
  const enabled = useSelector((state) => state.logo.logoEnabled);
  const mode = useSelector((state) => state.logo.logoMode);
  const variant = useSelector((state) => state.logo.logoVariant);

  useEffect(() => {
    if (enabled) {
      if (screenSize.width > 0 && screenSize.width < 1024) {
        dispatch(setLogoMode("dark"));
        dispatch(setLogoVariant("mobile"));
      } else if (screenSize.width > 0 && screenSize.width >= 1024) {
        dispatch(setLogoMode("light"));
        dispatch(setLogoVariant("desktop"));
      }
    }
  }, [screenSize, dispatch, enabled]);

  return (
    <div id="Logo">
      {variant === "desktop" ? (
        <LogoIcon mode={mode} />
      ) : (
        <LogoMobile mode={mode} />
      )}
    </div>
  );
}

Logo.propTypes = {
  mode: PropTypes.oneOf(["dark", "light"]).isRequired,
  variant: PropTypes.oneOf(["mobile", "desktop"]).isRequired,
};

export default Logo;

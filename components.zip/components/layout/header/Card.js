import { useState, Fragment, useEffect } from "react";
import { usePathname, useRouter } from "next/navigation";
import { setMobileMenuOpen, setMobileSearchOpen } from "@/redux/navigation/navigation";
import {
  Tab,
  TabGroup,
  TabList,
  TabPanel,
  TabPanels,
  Transition,
  TransitionChild,
} from "@headlessui/react";
import Link from "next/link";
import { useDispatch, useSelector } from "react-redux";
import ChevronRightIcon from "../../icons/chevron-right";
import ArrowLeftIcon from "../../icons/arrow-left";
import Image from "next/image";
import StoreRocketModal from "@/components/StoreLocator/StoreRocketModal";

export function Card({
  isStoreLocatorOpen,
  openStoreLocator,
  closeStoreLocator,
  popoverClose
}) {
  const [selectedIndex, setSelectedIndex] = useState(null);
  const [defaultIndex, setDefaultIndex] = useState(0);
  const [click, setClick] = useState(false);

  const router = useRouter();
  const mainNavigationData = useSelector(
    (state) => state.navigation.mainNavigation
  );
  const dispatch = useDispatch();
  const pathname = usePathname();

  const onClickLink = async (e, href) => {
    e.preventDefault();
    router.push(href);
    dispatch(setMobileMenuOpen(false));
    dispatch(setMobileSearchOpen(false));
    popoverClose();
  };

  useEffect(() => {
    const getIndexFromMainNavigation = (pathname) => {
      if (mainNavigationData) {
        for (let i = 0; i < mainNavigationData.length; i++) {
          if (mainNavigationData[i].seoUrls[0].seoPathInfo === pathname) {
            return i;
          }
        }
      }
    };

    if (pathname === "/") {
      setDefaultIndex(0);
    } else {
      const rootPath = pathname.substring(1).split("/")[0] + "/";
      setDefaultIndex(getIndexFromMainNavigation(rootPath));
    }
  }, [selectedIndex, pathname, mainNavigationData]);

  return (
    <>
      {/* Mobile menu */}
      <TabGroup
        as="div"
        className="h-full relative mobile-navigation overflow-hidden"
        defaultIndex={defaultIndex}
        selectedIndex={selectedIndex}
        onChange={setSelectedIndex}
      >
        <TabList as="aside" className="flex flex-col p-6 gap-2 self-start">
          {mainNavigationData.map((category, index) => (
            <div key={category.id}>
              {index === mainNavigationData.length - 1 && (
                <div className="border-t-2 border-base-400 my-6"></div>
              )}
              <Tab as={Fragment}>
                {({ selected }) =>
                  category.childCount === 0 ? (
                    // category type: link
                    category.type === "link" ? (
                      (category.linkType === "external" && (
                        // link type === external
                        <button
                          title={`${category.translated.name}`}
                          target={`${category.linkNewTab ? "_blank" : "_self"}`}
                          onClick={(e) =>
                            onClickLink(
                              e,
                              `${category.externalLink}`
                            )
                          }
                          className={`navbar-item ${selected && "active"}`}
                        >
                          {category.name}
                        </button>
                      )) ||
                      ((category.linkType === "category" ||
                        category.linkType === "product" ||
                        category.linkType === "landing_page") && (
                        // link type === category, product, landing_page
                        <button
                          title={`${category.translated.name}`}
                          target={`${category.linkNewTab ? "_blank" : "_self"}`}
                          onClick={(e) =>
                            onClickLink(
                              e,
                              `${process.env.NEXT_PUBLIC_SITE_URL}${category.seoUrl}`
                            )
                          }
                          className={`navbar-item ${selected && "active"}`}
                        >
                          {category.name}
                        </button>
                      ))
                    ) : (
                      // link type === page
                      <button
                        title={`${category.translated.name}`}
                        onClick={(e) =>
                          onClickLink(
                            e,
                            `${process.env.NEXT_PUBLIC_SITE_URL}${category.seoUrl}`
                          )
                        }
                        className={`navbar-item ${selected && "active"}`}
                      >
                        {category.translated.name}
                      </button>
                    )
                  ) : (
                    <button
                      className={`navbar-item group ${selected && "active"}`}
                      onClick={() => setClick((click) => !click)}
                    >
                      {category.name}
                      <ChevronRightIcon
                        className={`fill-base-50 group-hover:fill-orange-200 ${
                          selected && "fill-white"
                        }`}
                      />
                    </button>
                  )
                }
              </Tab>
            </div>
          ))}
        </TabList>
        <Transition
          show={click}
          enter="transition ease-in-out duration-300 transform"
          enterFrom="translate-x-full"
          enterTo="-translate-x-0"
          leave="-transition ease-out duration-300 transform"
          leaveFrom="translate-x-0"
          leaveTo="-translate-x-full"
        >
          <div className="bg-white h-full w-full absolute inset-0 overflow-y-auto">
            <div className="flex p-6">
              <button
                className=" text-base-50 text-xs overflow-ellipsis normal-case font-exo flex items-center justify-center leading-6 font-normal gap-2 ml-2"
                onClick={() => setClick((click) => !click)}
              >
                <ArrowLeftIcon className="fill-base-50" />
                Zurück zur Übersicht
              </button>
            </div>

            <TabPanels as={Fragment}>
              {mainNavigationData.map((category) => (
                <>
                  {category.name === "Fahrräder" ||
                  category.name === "E-Bikes" ? (
                    <TabPanel key={category.id}>
                      <div className="px-10 navbar menu-item-medium py-3">
                        <h2>Alle Fahrräder</h2>
                      </div>

                      <div className="px-6 pb-8 pt-4 ">
                        {category.children &&
                          category.children.map((child) =>
                            child.type === "link" ? (
                              <div key={child.id}>
                                {(child.linkType === "external" && (
                                  // link type === external
                                  <Link
                                    href={`${child.externalLink}`}
                                    title={`${child.translated.name}`}
                                    target={`${
                                      child.linkNewTab ? "_blank" : "_self"
                                    }`}
                                    className={`font-bold text-base-50 no-underline ${
                                      pathname.substring(1) ===
                                        child.externalLink && "active"
                                    }`}
                                    itemProp="url"
                                    onClick={(e) =>
                                      onClickLink(
                                        e,
                                        `${category.externalLink}`
                                      )
                                    }
                                  >
                                    {child.name}
                                  </Link>
                                )) ||
                                  ((child.linkType === "category" ||
                                    child.linkType === "product" ||
                                    child.linkType === "landing_page") && (
                                    // link type === category, product, landing_page
                                    <Link
                                      href={`${process.env.NEXT_PUBLIC_SITE_URL}${child.seoUrl}`}
                                      title={`${child.translated.name}`}
                                      target={`${
                                        child.linkNewTab ? "_blank" : "_self"
                                      }`}
                                      className={`font-bold text-base-50 no-underline ${
                                        pathname.substring(1) ===
                                          child.seoUrl && "active"
                                      }`}
                                      itemProp="url"
                                      onClick={(e) =>
                                        onClickLink(
                                          e,
                                          `${process.env.NEXT_PUBLIC_SITE_URL}${category.seoUrl}`
                                        )
                                      }
                                    >
                                      {child.name}
                                    </Link>
                                  ))}
                              </div>
                            ) : (
                              <div
                                key={child.name}
                                className="border-t-2 py-6 rounded-sm flex flex-col pb-6 items-start "
                              >
                                <Link
                                  href={`${process.env.NEXT_PUBLIC_SITE_URL}${child.seoUrl}`}
                                  className={`font-bold text-base-50 no-underline navbar-item  ${
                                    pathname.substring(1) ===
                                      child.seoUrls[0].seoPathInfo && "active"
                                  }`}
                                  itemProp="url"
                                  onClick={(e) =>
                                    onClickLink(
                                      e,
                                      `${process.env.NEXT_PUBLIC_SITE_URL}${child.seoUrl}`
                                    )
                                  }
                                >
                                  <span
                                    itemProp="name"
                                    className="navbar menu-item-medium"
                                  >
                                    {child.translated.name}
                                  </span>
                                </Link>
                                {/* Description (OnHold, has to be changed)*/}
                                <div className="flex justify-end text-sm font-exo items-start py-6 leading-6 font-[26px] px-4">
                                  sind für den Einsatz in der Stadt gedacht,
                                  wobei der Schwerpunkt auf Komfort und
                                  Zweckmäßigkeit liegt.
                                </div>

                                <ul
                                  role="list"
                                  aria-labelledby={`${category.id}-${child.id}-heading-mobile`}
                                  className="w-full"
                                >
                                  {child.children &&
                                    child.children.map((child) => (
                                      <li
                                        key={child.id}
                                        className="flex items-center uppercase font-exo tracking-wide w-full"
                                      >
                                        {child.type === "link" ? (
                                          // link type === external
                                          (child.linkType === "external" && (
                                            <Link
                                              href={`${child.externalLink}`}
                                              title={`${child.translated.name}`}
                                              target={`${
                                                child.linkNewTab
                                                  ? "_blank"
                                                  : "_self"
                                              }`}
                                              className={`text-base-50 no-underline ${
                                                pathname.substring(1) ===
                                                  child.externalLink && "active"
                                              }`}
                                              itemProp="url"
                                              onClick={(e) =>
                                                onClickLink(
                                                  e,
                                                  `${child.externalLink}`
                                                )
                                              }
                                            >
                                              {child.name}
                                            </Link>
                                          )) ||
                                          // link type === category, product, landing_page
                                          ((child.linkType === "category" ||
                                            child.linkType === "product" ||
                                            child.linkType ===
                                              "landing_page") && (
                                            <Link
                                              href={`${process.env.NEXT_PUBLIC_SITE_URL}${child.seoUrl}`}
                                              title={`${child.translated.name}`}
                                              target={`${
                                                child.linkNewTab
                                                  ? "_blank"
                                                  : "_self"
                                              }`}
                                              className={`text-base-50 no-underline ${
                                                pathname.substring(1) ===
                                                  child.seoUrl && "active"
                                              }`}
                                              itemProp="url"
                                              onClick={(e) =>
                                                onClickLink(
                                                  e,
                                                  `${process.env.NEXT_PUBLIC_SITE_URL}${child.seoUrl}`
                                                )
                                              }
                                            >
                                              {child.name}
                                            </Link>
                                          ))
                                        ) : (
                                          <Link
                                            href={`${process.env.NEXT_PUBLIC_SITE_URL}${child.seoUrl}`}
                                            itemProp="url"
                                            className={`navbar flyout-item menu-item-large ${
                                              pathname.substring(1) ===
                                                child.seoUrls[0].seoPathInfo &&
                                              "open"
                                            }`}
                                            onClick={(e) =>
                                              onClickLink(
                                                e,
                                                `${process.env.NEXT_PUBLIC_SITE_URL}${child.seoUrl}`
                                              )
                                            }
                                          >
                                            <span itemProp="name">
                                              {child.translated.name}
                                            </span>
                                          </Link>
                                        )}
                                      </li>
                                    ))}
                                </ul>
                              </div>
                            )
                          )}
                      </div>
                    </TabPanel>
                  ) : category.name === "Magazin" ? (
                    <TabPanel key={category.id} className="px-6 pb-8">
                      {category.children &&
                        category.children.map((child) =>
                          child.type === "link" ? (
                            <div key={child.id}>
                              {(child.linkType === "external" && (
                                // link type === external
                                <Link
                                  href={`${child.externalLink}`}
                                  title={`${child.translated.name}`}
                                  target={`${
                                    child.linkNewTab ? "_blank" : "_self"
                                  }`}
                                  className={`font-bold text-base-50 no-underline ${
                                    pathname.substring(1) ===
                                      child.externalLink && "active"
                                  }`}
                                  itemProp="url"
                                  onClick={(e) =>
                                    onClickLink(
                                      e,
                                      `${category.externalLink}`
                                    )
                                  }
                                >
                                  {child.name}
                                </Link>
                              )) ||
                                ((child.linkType === "category" ||
                                  child.linkType === "product" ||
                                  child.linkType === "landing_page") && (
                                  // link type === category, product, landing_page
                                  <Link
                                    href={`${process.env.NEXT_PUBLIC_SITE_URL}${child.seoUrl}`}
                                    title={`${child.translated.name}`}
                                    target={`${
                                      child.linkNewTab ? "_blank" : "_self"
                                    }`}
                                    className={`font-bold text-base-50 no-underline ${
                                      pathname.substring(1) === child.seoUrl &&
                                      "active"
                                    }`}
                                    itemProp="url"
                                    onClick={(e) =>
                                      onClickLink(
                                        e,
                                        `${process.env.NEXT_PUBLIC_SITE_URL}${category.seoUrl}`
                                      )
                                    }
                                  >
                                    {child.name}
                                  </Link>
                                ))}
                            </div>
                          ) : (
                            <div key={child.name} className="py-1 relative">
                              <Link
                                href={`${process.env.NEXT_PUBLIC_SITE_URL}${child.seoUrl}`}
                                className={`font-bold text-base-50 no-underline  ${
                                  pathname.substring(1) ===
                                    child.seoUrls[0].seoPathInfo && "active"
                                }`}
                                itemProp="url"
                                onClick={(e) =>
                                  onClickLink(
                                    e,
                                    `${process.env.NEXT_PUBLIC_SITE_URL}${child.seoUrl}`
                                  )
                                }
                              >
                                <span
                                  itemProp="name"
                                  className="navbar menu-item-medium"
                                >
                                  <div className="flex relative h-[200px]">
                                    <Image
                                      src={"/static/images/blog.png"}
                                      alt={child.name}
                                      layout="fill"
                                      objectFit="cover"
                                    />
                                  </div>
                                  <div
                                    itemProp="name"
                                    className="flex p-4 absolute bottom-1"
                                  >
                                    <div className="font-bold text-lg leading-7 text-white capitalize">
                                      {child.name}
                                    </div>
                                  </div>
                                </span>
                              </Link>
                            </div>
                          )
                        )}
                    </TabPanel>
                  ) : (
                    <TabPanel key={category.id} className="px-6 pb-8">
                      {category.children &&
                        category.children.map((child) =>
                          child.type === "link" ? (
                            <div key={child.id}>
                              {(child.linkType === "external" && (
                                // link type === external
                                <Link
                                  href={`${child.externalLink}`}
                                  title={`${child.translated.name}`}
                                  target={`${
                                    child.linkNewTab ? "_blank" : "_self"
                                  }`}
                                  className={`font-bold text-base-50 no-underline ${
                                    pathname.substring(1) ===
                                      child.externalLink && "active"
                                  }`}
                                  itemProp="url"
                                  onClick={(e) =>
                                    onClickLink(
                                      e,
                                      `${category.externalLink}`
                                    )
                                  }
                                >
                                  {child.name}
                                </Link>
                              )) ||
                                ((child.linkType === "category" ||
                                  child.linkType === "product" ||
                                  child.linkType === "landing_page") && (
                                  // link type === category, product, landing_page
                                  <Link
                                    href={`${process.env.NEXT_PUBLIC_SITE_URL}${child.seoUrl}`}
                                    title={`${child.translated.name}`}
                                    target={`${
                                      child.linkNewTab ? "_blank" : "_self"
                                    }`}
                                    className={`font-bold text-base-50 no-underline ${
                                      pathname.substring(1) === child.seoUrl &&
                                      "active"
                                    }`}
                                    itemProp="url"
                                    onClick={(e) =>
                                      onClickLink(
                                        e,
                                        `${process.env.NEXT_PUBLIC_SITE_URL}${category.seoUrl}`
                                      )
                                    }
                                  >
                                    {child.name}
                                  </Link>
                                ))}
                            </div>
                          ) : (
                            <div
                              key={child.name}
                              className="border-t-2 py-6 rounded-sm"
                            >
                              <Link
                                href={`${process.env.NEXT_PUBLIC_SITE_URL}${child.seoUrl}`}
                                className={`font-bold text-base-50 no-underline  ${
                                  pathname.substring(1) ===
                                    child.seoUrls[0].seoPathInfo && "active"
                                }`}
                                itemProp="url"
                                onClick={(e) =>
                                  onClickLink(
                                    e,
                                    `${process.env.NEXT_PUBLIC_SITE_URL}${child.seoUrl}`
                                  )
                                }
                              >
                                <span
                                  itemProp="name"
                                  className="px-3 text-base-50 font-exo text-xs font-normal leading-6 text-ellipsis"
                                >
                                  {child.translated.name}
                                </span>
                              </Link>

                              <ul
                                role="list"
                                className="mt-4"
                                aria-labelledby={`${category.id}-${child.id}-heading-mobile`}
                              >
                                {child.children &&
                                  child.children.map((child) => (
                                    <li
                                      key={child.id}
                                      className="flex items-center "
                                    >
                                      {child.type === "link" ? (
                                        // link type === external
                                        (child.linkType === "external" && (
                                          <Link
                                            href={`${child.externalLink}`}
                                            title={`${child.translated.name}`}
                                            target={`${
                                              child.linkNewTab
                                                ? "_blank"
                                                : "_self"
                                            }`}
                                            className={`navbar flyout-item menu-item-large ${
                                              pathname.substring(1) ===
                                                child.externalLink && "active"
                                            }`}
                                            itemProp="url"
                                          >
                                            {child.name}
                                          </Link>
                                        )) ||
                                        // link type === category, product, landing_page
                                        ((child.linkType === "category" ||
                                          child.linkType === "product" ||
                                          child.linkType ===
                                            "landing_page") && (
                                          <Link
                                            href={`${process.env.NEXT_PUBLIC_SITE_URL}${child.seoUrl}`}
                                            title={`${child.translated.name}`}
                                            target={`${
                                              child.linkNewTab
                                                ? "_blank"
                                                : "_self"
                                            }`}
                                            className={`text-base-50 no-underline ${
                                              pathname.substring(1) ===
                                                child.seoUrl && "active"
                                            }`}
                                            itemProp="url"
                                            onClick={(e) =>
                                              onClickLink(
                                                e,
                                                `${process.env.NEXT_PUBLIC_SITE_URL}${child.seoUrl}`
                                              )
                                            }
                                          >
                                            {child.name}
                                          </Link>
                                        ))
                                      ) : (
                                        <Link
                                          href={`${process.env.NEXT_PUBLIC_SITE_URL}${child.seoUrl}`}
                                          itemProp="url"
                                          className={`navbar flyout-item menu-item-large ${
                                            pathname.substring(1) ===
                                              child.seoUrls[0].seoPathInfo &&
                                            "open"
                                          }`}
                                          onClick={(e) =>
                                            onClickLink(
                                              e,
                                              `${process.env.NEXT_PUBLIC_SITE_URL}${child.seoUrl}`
                                            )
                                          }
                                        >
                                          <span itemProp="name">
                                            {child.translated.name}
                                          </span>
                                        </Link>
                                      )}
                                    </li>
                                  ))}
                              </ul>
                            </div>
                          )
                        )}
                      {isStoreLocatorOpen && (
                        <StoreRocketModal
                          closeStoreLocator={closeStoreLocator}
                        />
                      )}
                      {category.name === "Über uns" ? (
                        <div className="p-6 bg-base-400 relative flex flex-col">
                          <Image
                            src={"/static/images/experience.png"}
                            alt={"experience"}
                            width={279}
                            height={134}
                            className="w-full"
                          />

                          <div className="flex flex-col justify-end items-start gap-6 mt-6 px-4">
                            <div className="flex-auto">
                              <div className="headline-small mb-2">
                                Experience Center
                              </div>
                              <div className="body-extra-small text-start flex-1">
                                Auf knapp 200 Quadratmetern präsentiert das
                                Experience Center Gundelfingen eine vielfältige
                                Auswahl an hochwertigen Fahrrädern, E-Bikes,
                                Anhängern und Zubehör, alle hergestellt in der
                                Manufaktur.
                              </div>
                            </div>
                          </div>

                          <div className="mt-6">
                            <Link href={"/"} className="btn-primary">
                              <span className="text-base-500 text-center font-exo text-sm font-bold leading-4 tracking-[0.8px] uppercase">
                                Jetzt Termin vereinbaren
                              </span>
                            </Link>
                          </div>
                        </div>
                      ) : (
                        <div className="flex flex-col items-center gap-6 justify-center">
                          <div className="flex p-6 flex-col justify-center items-start gap-4 bg-base-400">
                            <div>
                              <span className="headline-small">
                                Wir beraten dich!
                              </span>
                            </div>
                            <div>
                              <p className="text-[16px] text-exo font-normal leading-[26px] text-start">
                                Unser Team ist Montag - Freitag von 9:00 bis
                                16:00 Uhr für Deine Fragen erreichbar.
                              </p>
                            </div>
                            <div className="flex items-center gap-4">
                              <div>
                                <Image
                                  src={"/static/images/icons/phone-icon.svg"}
                                  height={18}
                                  width={18}
                                  alt="phone-icon"
                                />
                              </div>
                              <div className="text-link-small">
                                <a>0123 / 45 67 89 10</a>
                              </div>
                            </div>
                            <div className="flex items-center gap-4">
                              <div>
                                <Image
                                  src={"/static/images/icons/email-icon.svg"}
                                  height={18}
                                  width={18}
                                  alt="phone-icon"
                                />
                              </div>
                              <div className="text-link-small truncate">
                                <a>bikefitting@tout-terrain.de</a>
                              </div>
                            </div>
                            <div className="flex items-center gap-4">
                              <div>
                                <Image
                                  src={"/static/images/icons/whatsap-icon.svg"}
                                  height={18}
                                  width={18}
                                  alt="phone-icon"
                                />
                              </div>
                              <div className="text-link-small">
                                <a>Textlink</a>
                              </div>
                            </div>
                          </div>
                          <div className="flex items-center gap-4 justify-end w-full pr-8">
                            <Image
                              src={"/static/images/icons/apple-pay.svg"}
                              height={29}
                              width={45}
                              alt="apple-pay"
                            />
                            <Image
                              src={"/static/images/icons/paypal-logo.svg"}
                              height={20}
                              width={80}
                              alt="paypal-pay"
                            />
                            <Image
                              src={"/static/images/icons/visa.svg"}
                              height={20}
                              width={44}
                              alt="visa-pay"
                            />
                            <Image
                              src={"/static/images/icons/mastercard-logo.svg"}
                              height={28}
                              width={20}
                              alt="apple-pay"
                            />
                            <Image
                              src={"/static/images/icons/karma-paymethod.svg"}
                              height={20}
                              width={63}
                              alt="apple-pay"
                            />
                          </div>
                        </div>
                      )}
                    </TabPanel>
                  )}
                </>
              ))}
            </TabPanels>
          </div>
        </Transition>
      </TabGroup>
    </>
  );
}

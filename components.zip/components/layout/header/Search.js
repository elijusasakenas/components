import SearchIcon from "@/components/icons/search";
import ShopperIcon from "@/components/icons/shopper";
import CrossIcon from "@/icons/cross";
import { fetchClient } from "@/utility/fetch-client";
import {
  CloseButton,
  Popover,
  PopoverBackdrop,
  PopoverButton,
  PopoverPanel,
  Transition,
} from "@headlessui/react";
import Image from "next/image";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Fragment, useEffect, useRef, useState } from "react";
import { NumericFormat } from "react-number-format";
import { useSelector } from "react-redux";

const SearchBar = ({ open, setOpen, snippets }) => {
  //const snippets = useSelector((state) => state.snippets.snippets);
  const router = useRouter();
  const [searchResult, setSearchResult] = useState(null);
  const [click, setClick] = useState(false);
  const [search, setSearch] = useState(null);
  const [listItems, setListItems] = useState(null);
  const inputField = useRef();
  const [currentSelectedResult, setCurrentSelectedResult] = useState(0);
  const setFocus = () => {
    inputField.current.focus();
  };

  const handleSearch = async (search) => {
    if (search.length < 3) return;
    setSearch(search);
    const searchResult = await fetchClient({
      path: "search",
      method: "POST",
      body: {
        search: search,
        filter: [
          {
            type: "equals",
            field:
              "customFields.custom_netzkom_configurator_netzkomIsConfiguratorNumber",
            value: null,
          },
        ],
      },
    });

    setSearchResult(searchResult.elements);
  };

  const handleKeyDown = (e) => {
    setListItems(document.querySelector("#search-result").childNodes);

    if (e.key === "ArrowUp") {
      moveFocusUp();
    }

    if (e.key === "ArrowDown") {
      moveFocusDown();
    }

    if (e.key === "Enter") {
      if (currentSelectedResult === 0) {
        location.replace("/search?s=" + search);
        return;
      }
      listItems[currentSelectedResult - 1].firstChild.click();
    }

    if (e.key === "Escape") {
      setSearchResult(null);
      setOpen(false);
    }
  };

  const moveFocusDown = () => {
    let current = currentSelectedResult;
    if (currentSelectedResult >= listItems.length) {
      current = 0;
    }

    listItems.forEach((item) => {
      item.firstChild.classList.remove("bg-neutral-100");
    });
    listItems[current].firstChild.classList.add("bg-neutral-100");
    setCurrentSelectedResult(current + 1);
  };

  const moveFocusUp = () => {
    let current = currentSelectedResult;
    if (current <= 0) {
      current = listItems.length;
    }

    listItems.forEach((item) => {
      item.firstChild.classList.remove("bg-neutral-100");
    });
    listItems[current - 1].firstChild.classList.add("bg-neutral-100");
    setCurrentSelectedResult(current - 1);
  };

  useEffect(() => {
    window.addEventListener("click", function (e) {
      if (e.target.dataset.todo !== "openSearch") {
        setClick(false);
      }
    });
  }, []);

  useEffect(() => {
    if (open) setSearchResult(null);
  }, [open]);

  return (
    <Popover>
      <PopoverButton className="hidden lg:flex items-center gap-6 justify-between w-full py-[6px] px-4 xl:border rounded-lg h-11 border-base-500/50 hover:border-orange-200 group focus-within:outline-0">
        <div className="text-white text-sm leading-[26px] font-normal truncate overflow-hidden hidden xl:block">
          {snippets.next.header.search.button}
        </div>
        <div>
          <SearchIcon
            className="fill-base-500 xl:fill-base-500/50 group-hover:fill-orange-200 w-8 h-8"
            aria-hidden="true"
          />
        </div>
      </PopoverButton>

      <PopoverBackdrop
        className="fixed inset-0 bg-base-50/30"
        aria-hidden="true"
      />

      <Transition
        as={Fragment}
        enter="transition ease-in-out duration-300 transform"
        enterFrom="translate-x-full opacity-0"
        enterTo="translate-x-0 opacity-100"
        leave="-transition ease-in-out duration-300 transform"
        leaveFrom="-translate-x-0  opacity-100"
        leaveTo="translate-x-full opacity-0"
        afterEnter={() => {
          setFocus();
        }}
        beforeLeave={() => {
          setSearchResult(null);
        }}
      >
        <PopoverPanel className="w-full bg-base-50 z-20 h-auto absolute top-0 left-0">
          <div className="max-w-7xl mx-auto flex items-center justify-between pl-4 pr-0">
            <div className="flex-1">
              <div className="relative">
                <input
                  type="text"
                  className={`inline-block px-4 text-base-50 rounded-md border border-base-500 body-small w-full bg-base-500 focus-within:outline-0 focus:outline-0 focus:ring-0 focus:shadow-none focus:border-base-500`}
                  id={"searchInput"}
                  data-todo="openSearch"
                  placeholder={snippets.next.header.search.input}
                  ref={inputField}
                  onKeyDown={handleKeyDown}
                  onClick={() => setClick(true)}
                  onChange={(e) => {
                    if (e.key !== "Enter") {
                      handleSearch(e.target.value);
                    }
                  }}
                  data-autofocus
                />
                <div className="absolute end-2 top-1 pt-1">
                  <SearchIcon
                    className="fill-base-100 h-8 w-8"
                    aria-hidden="true"
                  />
                </div>
              </div>
              <div
                className={`overflow-hidden w-full mt-2 absolute mb-4 max-w-7xl ${
                  searchResult ? "visible" : "hidden"
                }`}
              >
                <div className="bg-base-400 shadow-lg rounded-lg p-2 h-auto max-h-[620px] overflow-x-hidden overflow-y-auto mr-4">
                  <ul
                    role="list"
                    className="grid grid-cols-2 gap-2"
                    id={"search-result"}
                  >
                    {searchResult &&
                      searchResult.map((item) =>
                        item.seoUrls ? (
                          <li key={item.id} className="bg-base-500 rounded-lg">
                            <Link
                              href={`/${item.seoUrls[0].seoPathInfo}`}
                              className="block group"
                              onClick={(e) => {
                                e.preventDefault();
                                router.push(`/${item.seoUrls[0].seoPathInfo}`);
                              }}
                            >
                              <div className="flex items-center p-4">
                                <div className="flex flex-1 gap-10 items-center">
                                  {item.cover ? (
                                    <div className="flex-shrink-0">
                                      <Image
                                        className="w-48 object-contain"
                                        src={
                                          item.cover
                                            ? item.cover.media.thumbnails[0].url
                                            : null
                                        }
                                        width={192}
                                        height={192}
                                        alt=""
                                      />
                                    </div>
                                  ) : (
                                    <div className="flex-shrink-0">
                                      <Image
                                        src="https://fakeimg.pl/192x96/e5e5e5/131313?text=Bild folgt&font=bebas"
                                        alt={item.translated.name}
                                        className="w-48 object-contain"
                                        width={192}
                                        height={192}
                                      />
                                    </div>
                                  )}

                                  <div className="flex-1">
                                    <div>
                                      <span className="font-semibold uppercase text-base-50 group-hover:text-orange-200">
                                        {item.translated.name}
                                      </span>
                                    </div>

                                    <div className="body-small">
                                      <p className="">
                                        <span className="truncate">
                                          {item.calculatedPrice.referencePrice
                                            ? "ab "
                                            : null}
                                        </span>
                                        <NumericFormat
                                          value={item.calculatedPrice.unitPrice}
                                          decimalSeparator=","
                                          decimalScale="2"
                                          fixedDecimalScale="true"
                                          displayType={"text"}
                                          thousandSeparator="."
                                          suffix={" €"}
                                        />
                                      </p>
                                      <div className="body-extra-small">
                                        {item.calculatedPrice.referencePrice ? (
                                          <NumericFormat
                                            value={
                                              item.calculatedPrice
                                                .referencePrice.price
                                            }
                                            decimalSeparator=","
                                            decimalScale="2"
                                            fixedDecimalScale="true"
                                            displayType={"text"}
                                            thousandSeparator="."
                                            prefix={"("}
                                            suffix={
                                              " €* / " +
                                              item.calculatedPrice
                                                .referencePrice.referenceUnit +
                                              " " +
                                              item.calculatedPrice
                                                .referencePrice.unitName +
                                              ")"
                                            }
                                          />
                                        ) : null}
                                        <span>
                                          {snippets.next.header.search.tax}
                                        </span>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </Link>
                          </li>
                        ) : null
                      )}
                  </ul>
                  {searchResult && searchResult.length > 0 ? (
                    <div className="text-center p-4">
                      <a
                        className={
                          "text-link text-link-small !no-underline p-6"
                        }
                        href={"/search?s=" + search}
                      >
                        {snippets.next.header.search.showall}
                      </a>
                    </div>
                  ) : (
                    <div className="flex flex-col justify-start items-center pt-3 pb-8">
                      <ShopperIcon className="w-20 h-20 mx-auto" />
                      <div className="body-small">
                        {snippets.next.header.search.noresult}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
            <div>
              <CloseButton className={`pl-2 pr-2 block group`}>
                <CrossIcon className="transition-colors duration-200 ease-in-out fill-white group-hover:fill-orange-200 h-8 w-8" />
              </CloseButton>
            </div>
          </div>
        </PopoverPanel>
      </Transition>
    </Popover>
  );
};

export default SearchBar;

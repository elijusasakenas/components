import BurgerMenuIcon from "@/components/icons/burgermenu";
import CartIcon from "@/components/icons/cart";
import SearchIcon from "@/components/icons/search";
import { MainMobileNavigation } from "@/components/layout/header/Navigation";
import CrossIcon from "@/icons/cross";
import { setOpen } from "@/redux/cart/cart";
import {
  setMobileMenuOpen,
  setMobileSearchOpen,
} from "@/redux/navigation/navigation";
import {
  Popover,
  PopoverButton,
  PopoverGroup,
  PopoverPanel,
  Transition,
} from "@headlessui/react";
import { Fragment } from "react";
import { useDispatch, useSelector } from "react-redux";
import MobileSearchBar from "./MobileSearch";
import { motion } from "framer-motion";
import { LanguageSelector } from "./lang/LanguageSelector";
import Link from "next/link";

const MobileNavigation = ({ swCart, languages, foreignKey }) => {
  const dispatch = useDispatch();
  const mobileMenuOpen = useSelector(
    (state) => state.navigation.mobileMenuOpen
  );
  const mobileSearchOpen = useSelector(
    (state) => state.navigation.mobileSearchOpen
  );

  const variants = {
    active: { width: "100%", borderRadius: "0", marginBottom: "0" },
    inactive: { width: "auto", borderRadius: "8px", marginBottom: "24px" },
  };

  return (
    <nav className="fixed w-full z-30 bottom-0 flex items-center justify-center lg:hidden">
      <motion.div
        variants={variants}
        animate={mobileMenuOpen || mobileSearchOpen ? "active" : "inactive"}
        className="bg-base-50 rounded-lg px-2 py-2 mb-6"
      >
        <PopoverGroup
          className={`flex items-center gap-4 ${
            mobileMenuOpen || mobileSearchOpen
              ? "justify-end"
              : "justify-center"
          }`}
        >
          <Popover
            className={`p-2 flex ${mobileSearchOpen ? "hidden" : "visible"}`}
          >
            {({ open, close }) => (
              <>
                <PopoverButton
                  as="div"
                  onClick={() => dispatch(setMobileMenuOpen(!mobileMenuOpen))}
                >
                  {open ? (
                    <>
                      <span className="sr-only">Close menu</span>
                      <CrossIcon
                        className="fill-white hover:fill-primary h-7 w-7"
                        aria-hidden="true"
                      />
                    </>
                  ) : (
                    <>
                      <span className="sr-only">Open menu</span>
                      <BurgerMenuIcon
                        className="fill-white hover:fill-primary h-7 w-7"
                        aria-hidden="true"
                      />
                    </>
                  )}
                </PopoverButton>
                <Transition
                  as={Fragment}
                  enter="transition ease-in-out duration-300 transform"
                  enterFrom="translate-y-full opacity-0 scale-0"
                  enterTo="-translate-y-0 opacity-1 scale-100"
                  leave="transition ease-in-out duration-300 transform"
                  leaveFrom="-translate-y-0 opacity-1 scale-100"
                  leaveTo="translate-y-full opacity-0 scale-0"
                  beforeLeave={() => dispatch(setMobileMenuOpen(false))}
                >
                  <PopoverPanel
                    //anchor={{ to: "bottom", gap: "-45px" }}
                    className="bg-base-500 w-screen fixed top-0 left-0 bottom-14"
                  >
                    <MainMobileNavigation popoverClose={close} />

                    <div className="absolute z-50 -bottom-12 w-64 mb-1 flex items-center justify-between bg-base-50">
                      <div className="ml-4">
                        <LanguageSelector
                          mobile
                          languages={languages}
                          foreignKey={foreignKey}
                          popoverClose={close}
                        />
                      </div>

                      <div className="">
                        <Link
                          className="btn-primary btn-small !px-3 !py-2 !text-sm !leading-4 !flex"
                          target="_blank"
                          href={"https://b2b.tout-terrain.de"}
                        >
                          B2B SHOP
                        </Link>
                      </div>
                    </div>
                  </PopoverPanel>
                </Transition>
              </>
            )}
          </Popover>

          <Popover
            className={`p-2 flex ${mobileMenuOpen ? "hidden" : "visible"}`}
          >
            {({ open, close }) => (
              <>
                <PopoverButton
                  as="div"
                  onClick={() =>
                    dispatch(setMobileSearchOpen(!mobileSearchOpen))
                  }
                >
                  {open ? (
                    <>
                      <span className="sr-only">Close search</span>
                      <CrossIcon
                        className="fill-white hover:fill-primary h-7 w-7"
                        aria-hidden="true"
                      />
                    </>
                  ) : (
                    <>
                      <span className="sr-only">Open search</span>
                      <SearchIcon
                        className="fill-white hover:fill-primary h-7 w-7"
                        aria-hidden="true"
                      />
                    </>
                  )}
                </PopoverButton>
                <Transition
                  as={Fragment}
                  enter="transition ease-in-out duration-300 transform"
                  enterFrom="translate-y-full opacity-0 scale-0"
                  enterTo="-translate-y-0 opacity-1 scale-100"
                  leave="transition ease-in-out duration-300 transform"
                  leaveFrom="-translate-y-0 opacity-1 scale-100"
                  leaveTo="translate-y-full opacity-0 scale-0"
                  beforeLeave={() => dispatch(setMobileSearchOpen(false))}
                >
                  <PopoverPanel
                    //anchor={{ to: "bottom", gap: "0" }}
                    className="w-screen fixed top-0 left-0 bottom-14"
                  >
                    <MobileSearchBar popoverClose={close} />
                  </PopoverPanel>
                </Transition>
              </>
            )}
          </Popover>

          <div
            className={`p-2 relative flex ${
              mobileMenuOpen || mobileSearchOpen ? "hidden" : "visible"
            }`}
          >
            <button onClick={() => dispatch(setOpen(true))}>
              <CartIcon className=" fill-base-500 h-7 w-7" />
              {swCart && swCart.lineItems?.length > 0 && (
                <div className="flex items-center justify-center text-sm leading-6 font-medium text-base-500 bg-orange rounded-full min-w-6 h-6 absolute -top-1 right-0">
                  {swCart ? swCart.lineItems.length : 0}
                </div>
              )}
            </button>
          </div>
        </PopoverGroup>
      </motion.div>
    </nav>
  );
};

export default MobileNavigation;

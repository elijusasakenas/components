import cookie from "js-cookie";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import {
  Listbox,
  ListboxButton,
  ListboxOption,
  ListboxOptions,
} from "@headlessui/react";
import { CheckIcon } from "@heroicons/react/20/solid";
import { usePathname } from "next/navigation";

import LoadingScreen from "@/components/LoadingScreen";
import ChevronDownIcon from "@/components/icons/chevron-down";
import { setLanguageCookie } from "@/shopware/context";
import { fetchClient } from "@/utility/fetch-client";

const LANGUAGE_SELECTOR_ID = "language-selector";

export const LanguageSelector = ({ mobile = false, languages, foreignKey, popoverClose }) => {
  const router = useRouter();
  const [isOpen, setIsOpen] = useState(false);
  const [selectedLanguage, setSelectedLanguage] = useState(null);
  const pathname = usePathname();
  const [isLoading, setIsLoading] = useState(false);

  const handleLanguageChange = async (language) => {
    setIsLoading(true);
    setSelectedLanguage(language);
    setLanguageCookie(language.id);

    if (foreignKey) {
      const seoUrl = await fetchClient({
        path: "seo-url",
        method: "POST",
        body: {
          fields: ["seoPathInfo"],
          filter: [
            {
              type: "equals",
              field: "foreignKey",
              value: foreignKey,
            },
          ],
        },
        languageId: language.id,
      });

      if (seoUrl?.total > 0) {
        const seoPathInfo = seoUrl.elements[0].seoPathInfo;
        const isDefaultLanguage = language.id === process.env.NEXT_PUBLIC_DEFAULT_LANGUAGE;
        const newPath = isDefaultLanguage ? `/${seoPathInfo}` : `/en/${seoPathInfo}`;

        if (seoPathInfo === "start" || seoPathInfo === "start-en") {
          if (isDefaultLanguage) {
            router.push(`${process.env.NEXT_PUBLIC_SITE_URL}`);
          } else {
            router.push(`${process.env.NEXT_PUBLIC_SITE_URL}/en`);
          }
        } else {
          router.push(`${process.env.NEXT_PUBLIC_SITE_URL}${newPath}`);
        }
      } else {
        const isDefaultLanguage = language.id === process.env.NEXT_PUBLIC_DEFAULT_LANGUAGE;

        if (isDefaultLanguage) {
          router.push(`${process.env.NEXT_PUBLIC_SITE_URL}`);
        } else {
          router.push(`${process.env.NEXT_PUBLIC_SITE_URL}/en`);
        }
      }
    }

    mobile && popoverClose();
    setIsLoading(false);
  };

  useEffect(() => {
    if (languages && languages.length > 0) {
      const selectedLanguage =
        languages.find((language) => language.id === cookie.get("language")) ||
        languages.find(
          (language) => language.id === process.env.NEXT_PUBLIC_DEFAULT_LANGUAGE
        );

      setSelectedLanguage(selectedLanguage);
    }
  }, [languages]);

  return (
    languages &&
    selectedLanguage && (
      <>
        {isLoading && (
          <div className="fixed inset-0 w-full h-full z-50 ">
            <LoadingScreen />
          </div>
        )}
        <Listbox value={selectedLanguage} onChange={handleLanguageChange}>
          <ListboxButton className="text-base-500 text-sm flex justify-center items-center">
            {selectedLanguage.name === "English" ? "EN" : "DE"}
            <ChevronDownIcon className="fill-white group-hover:fill-orange-200" />
          </ListboxButton>

          <ListboxOptions
            anchor={{ to: "bottom end", gap: "10px" }}
            className={`w-auto bg-base-500 rounded-lg shadow-lg z-30 p-1 text-sm`}
          >
            {languages.map(
              (language) =>
                selectedLanguage.id !== language.id && (
                  <ListboxOption
                    key={language.translationCode.code}
                    value={language}
                    disabled={selectedLanguage.id === language.id}
                    className="px-4 py-2 flex items-center justify-start gap-4 data-[selected]:text-orange-200 data-[disabled]:bg-base-500 text-base-50 hover:bg-primary hover:text-base-500 rounded-lg text-sm cursor-pointer"
                  >
                    <FlagIcon countryCode={language.translationCode.code} />
                    <span className="truncate">{language.name}</span>
                  </ListboxOption>
                )
            )}
          </ListboxOptions>
        </Listbox>

        <div className="relative hidden">
          <div>
            <button
              onClick={() => setIsOpen(!isOpen)}
              type="button"
              className="flex items-center justify-center group"
              id={LANGUAGE_SELECTOR_ID}
              aria-haspopup="true"
              aria-expanded={isOpen}
              title={selectedLanguage.name}
            >
              <div className="flex text-sm text-white hover:text-orange-200">
                {selectedLanguage.name === "English" ? "EN" : "DE"}
                <ChevronDownIcon className="fill-white group-hover:fill-orange-200" />
              </div>
            </button>
          </div>
          {isOpen && (
            <div
              className={`origin-top-left lg:origin-bottom-right lg:mt-3 absolute left-0 lg:right-0 lg:left-auto w-72 rounded-lg shadow-lg bg-base-500 text-base-50 p-1 ${
                mobile ? "bottom-0" : ""
              }`}
              role="menu"
              aria-orientation="vertical"
              aria-labelledby="language-selector"
            >
              <div className="flex flex-col" role="none">
                {languages.map((language) => {
                  return (
                    <button
                      key={language.translationCode.code}
                      onClick={() => handleLanguageChange(language)}
                      className={`${
                        selectedLanguage.translationCode.code ===
                        language.translationCode.code
                          ? "bg-base-400"
                          : ""
                      } px-4 py-2 flex items-center justify-start gap-4 text-base-50 hover:bg-primary rounded-lg text-sm`}
                      role="menuitem"
                    >
                      <FlagIcon countryCode={language.translationCode.code} />
                      <span className="truncate">{language.name}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </>
    )
  );
};

function FlagIcon({ countryCode = "" }) {
  return <div className={`fi fis fiCircle inline-block fi-${countryCode}`} />;
}

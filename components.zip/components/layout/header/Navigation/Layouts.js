import ChevronRightIcon from "@/icons/chevron-right";
import CrossIcon from "@/icons/cross";
import { setOpen } from "@/redux/StoreRocketModal/StoreRocketModal";
import { PopoverPanel } from "@headlessui/react";
import Image from "next/image";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useDispatch } from "react-redux";

const NavigationLayoutDefault = ({ category, closeMenu }) => {
  const router = useRouter();
  const pathname = usePathname();

  const onClickLink = async (e, href) => {
    e.preventDefault();
    router.push(href);
    closeMenu();
  };

  return (
    <PopoverPanel
      transition
      anchor={{ to: "bottom", gap: "18px" }}
      className="w-full z-20 relative bg-white pt-12 !overflow-x-hidden !overflow-y-auto transition duration-200 ease-in-out data-[closed]:opacity-0 data-[enter]:data-[closed]:translate-y-full data-[leave]:data-[closed]:translate-y-full"
    >
      <nav
        className={
          "grid grid-cols-4 justify-center items-stretch gap-4 self-stretch px-12 xl:px-0 mx-auto max-w-7xl"
        }
        itemScope="itemscope"
        itemType="http://schema.org/SiteNavigationElement"
      >
        {category.children &&
          category.children.map((child) => (
            <div
              key={child.id}
              className="pr-4 border-r-[1px] border-base-400 last:border-r-0"
            >
              <div id={`${child.name}-heading`}>
                <Link
                  href={`${process.env.NEXT_PUBLIC_SITE_URL}${child.seoUrl}`}
                  onClick={(e) =>
                    onClickLink(
                      e,
                      process.env.NEXT_PUBLIC_SITE_URL + child.seoUrl
                    )
                  }
                  title={child.translated.name}
                >
                  <span itemProp="url" className="sr-only">
                    {process.env.NEXT_PUBLIC_SITE_URL}
                    {child.seoUrl}
                  </span>
                  {child.media?.url && (
                    <Image
                      src={child.media?.url}
                      alt={child.translated.name}
                      width={child.media.metaData.width}
                      height={child.media.metaData.height}
                      className="w-full h-28 object-cover xl:h-40"
                    />
                  )}
                </Link>
              </div>
              <div itemProp="name" className="">
                <Link
                  href={`${process.env.NEXT_PUBLIC_SITE_URL}${child.seoUrl}`}
                  onClick={(e) =>
                    onClickLink(
                      e,
                      process.env.NEXT_PUBLIC_SITE_URL + child.seoUrl
                    )
                  }
                  className="text-link flex items-center justify-start text-base-50 text-[18px] leading-5 font-bold uppercase mt-6 mb-3 px-4 group"
                >
                  {child.translated.name}
                  <ChevronRightIcon className="fill-base-50 group-hover:fill-orange-200" />
                </Link>
                {/* DESCRIPTION (ONHOLD) */}
                <div className="px-4 body !text-xs line-clamp-4	">
                  {child.translated.description}
                </div>
              </div>
              {child.children && child.children.length > 0 && (
                <ul
                  role="list"
                  aria-labelledby={`${child.name}-heading`}
                  className="mt-6 flex flex-col uppercase gap-3"
                >
                  {child.children.map((child) => (
                    <li key={child.id} className={`flex`}>
                      <Link
                        href={`${process.env.NEXT_PUBLIC_SITE_URL}${
                          child.seoUrl ? child.seoUrl : ""
                        }`}
                        onClick={(e) => {
                          onClickLink(
                            e,
                            process.env.NEXT_PUBLIC_SITE_URL + child.seoUrl
                          );
                        }}
                        className={classNames(
                          pathname.substring(1) === child.seoUrl ? "open" : "",
                          "navbar flyout-item"
                        )}
                        title={child.name}
                      >
                        {child.name}
                      </Link>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          ))}
      </nav>

      <div className="w-full h-12 flex justify-center border-b-8 border-orange-200 mt-10 xl:mt-16">
        <div className="bg-orange-200 w-12 hover:border-orange-100 hover:bg-primary">
          <button
            className="flex items-center justify-center p-0 w-full h-full"
            onClick={() => closeMenu()}
          >
            <CrossIcon className=" fill-white"></CrossIcon>
          </button>
        </div>
      </div>
    </PopoverPanel>
  );
};

const NavigationLayoutBlog = ({ category, closeMenu }) => {
  const router = useRouter();

  const onClickLink = async (e, href) => {
    e.preventDefault();
    router.push(href);
    closeMenu();
  };

  return (
    <PopoverPanel
      transition
      anchor={{ to: "bottom", gap: "18px" }}
      className="w-full z-20 transition duration-200 ease-in-out data-[closed]:opacity-0 data-[enter]:data-[closed]:translate-y-full data-[leave]:data-[closed]:translate-y-full"
    >
      <div className={`flex bg-white flex-col items-center gap-16`}>
        <div className="mx-auto max-w-7xl relative text-white h-full flex pt-10 flex-col items-start gap-10 ">
          <nav
            className={"flex items-start gap-4 "}
            itemScope="itemscope"
            itemType="http://schema.org/SiteNavigationElement"
          >
            {category.children &&
              category.children.map((child) => (
                <div key={child.id} className="group">
                  <div
                    id={`${child.name}-heading`}
                    className="flex flex-col justify-end items-start gap-6"
                  >
                    <Link
                      href={`${process.env.NEXT_PUBLIC_SITE_URL}${child.seoUrl}`}
                      onClick={(e) =>
                        onClickLink(
                          e,
                          process.env.NEXT_PUBLIC_SITE_URL + child.seoUrl
                        )
                      }
                      className={`relative w-[240px] h-[410px] lg:w-[300px] lg:h-[470px] xl:w-[400px] xl:h-[600px]`}
                      title={child.name}
                    >
                      <span itemProp="url" className="sr-only">
                        {process.env.NEXT_PUBLIC_SITE_URL}
                        {child.seoUrl}
                      </span>
                      <div className="relative w-full h-full flex">
                        <Image
                          src={"/static/images/blog.png"}
                          alt={child.name}
                          layout="fill"
                          objectFit="cover"
                        />
                      </div>
                      <div
                        itemProp="name"
                        className="flex px-6 py-10 absolute bottom-1"
                      >
                        <div className="flex uppercase font-bold text-xl leading-10 font-exo gap-3 items-center">
                          {child.name}
                          <ChevronRightIcon className="fill-white" />
                        </div>
                      </div>
                    </Link>
                  </div>
                </div>
              ))}
          </nav>
        </div>
        <div className="w-full h-12 flex justify-center border-b-8 border-orange-200">
          <div className="bg-orange-200 w-12 hover:border-orange-100 hover:bg-primary">
            <button
              className="flex items-center justify-center p-0 w-full h-full"
              onClick={() => closeMenu()}
            >
              <CrossIcon className="fill-white"></CrossIcon>
            </button>
          </div>
        </div>
      </div>
    </PopoverPanel>
  );
};

const NavigationLayoutAboutUs = ({ category, closeMenu }) => {
  const router = useRouter();
  const pathname = usePathname();

  const onClickLink = async (e, href, close) => {
    e.preventDefault();
    router.push(href);
    closeMenu();
  };

  return (
    <PopoverPanel
      transition
      anchor={{ to: "bottom", gap: "18px" }}
      className="w-full z-20 relative bg-white !overflow-x-hidden !overflow-y-auto transition duration-200 ease-in-out data-[closed]:opacity-0 data-[enter]:data-[closed]:translate-y-full data-[leave]:data-[closed]:translate-y-full"
    >
      <div className="flex justify-start items-stretch gap-4 self-stretch pl-12 xl:px-0 mx-auto max-w-7xl">
        <nav
          className={
            "grid grid-cols-2 justify-center items-stretch gap-4 self-stretch pt-12"
          }
          itemScope="itemscope"
          itemType="http://schema.org/SiteNavigationElement"
        >
          {category.children &&
            category.children.map((child) => (
              <div
                key={child.id}
                className="flex flex-col items-start self-stretch min-h-[298px] min-w-[300px]"
              >
                <div
                  id={`${child.name}-heading`}
                  className="flex flex-col items-start self-stretch"
                >
                  <Link
                    href={`${process.env.NEXT_PUBLIC_SITE_URL}${child.seoUrl}`}
                    onClick={(e) =>
                      onClickLink(
                        e,
                        process.env.NEXT_PUBLIC_SITE_URL + child.seoUrl
                      )
                    }
                    className={`text-base-50 `}
                    title={child.name}
                  >
                    <span itemProp="url" className="sr-only">
                      {process.env.NEXT_PUBLIC_SITE_URL}
                      {child.seoUrl}
                    </span>
                  </Link>
                </div>
                <div
                  itemProp="name"
                  className="flex pb-4 flex-col items-start p-4"
                >
                  <div className="text-ellipsis whitespace-nowrap font-exo text-xs leading-6">
                    {child.name}
                  </div>
                </div>
                {child.children && child.children.length > 0 && (
                  <ul
                    role="list"
                    aria-labelledby={`${child.name}-heading`}
                    className=" flex-col uppercase gap-3 items-start"
                  >
                    {child.children.map((child) => (
                      <li
                        key={child.id}
                        className={`flex items-start gap-2 self-stretch`}
                      >
                        {child.name === "Händler finden" ? (
                          <Link
                            href="#"
                            onClick={openStoreLocator}
                            className={classNames(
                              pathname.substring(1).split("/")[2] === child.name
                                ? "open"
                                : "",
                              "navbar flyout-item"
                            )}
                          >
                            Händlersuche
                          </Link>
                        ) : child.linkType === "external" ? (
                          <Link
                            href={child.externalLink}
                            target={child.linkNewTab ? "_blank" : "_self"}
                            className="navbar flyout-item"
                          >
                            {child.translated.name}
                          </Link>
                        ) : (
                          <Link
                            href={`${process.env.NEXT_PUBLIC_SITE_URL}${
                              child.seoUrl ? child.seoUrl : ""
                            }`}
                            onClick={(e) => {
                              onClickLink(
                                e,
                                process.env.NEXT_PUBLIC_SITE_URL + child.seoUrl
                              );
                            }}
                            className={classNames(
                              pathname.substring(1).split("/")[2] ===
                                child.name ||
                                pathname.substring(1).split("/")[2] ===
                                  "Fahrräder"
                                ? "open"
                                : "",
                              "navbar flyout-item"
                            )}
                            title={child.translated.name}
                          >
                            {child.translated.name}
                          </Link>
                        )}
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            ))}
        </nav>

        {category.translated.customFields
          .custom_b2c_settings_menu_about_us_active && (
          <div className="flex justify-center items-center px-8 pt-12 pb-8 gap-8 bg-base-400 relative flex-1">
            {category.customFields?.custom_b2c_settings_menu_about_us_image && (
              <div className="w-80 h-60">
                <Image
                  src={
                    category.customFields
                      .custom_b2c_settings_menu_about_us_image
                  }
                  alt={"experience"}
                  width={320}
                  height={240}
                  className="w-full h-full object-cover"
                />
              </div>
            )}

            <div className="flex flex-col justify-start items-start flex-1">
              <div className="headline-small mb-4">
                {
                  category.translated.customFields
                    .custom_b2c_settings_menu_about_us_title
                }
              </div>

              <div className="mb-6 body-small">
                {
                  category.translated.customFields
                    .custom_b2c_settings_menu_about_us_text
                }
              </div>

              {category.translated.customFields
                .custom_b2c_settings_menu_about_us_button && (
                <div>
                  <Link
                    href={
                      category.translated.customFields
                        .custom_b2c_settings_menu_about_us_button_link
                    }
                    target={
                      category.translated.customFields
                        .custom_b2c_settings_menu_about_us_button_target
                        ? "_blank"
                        : "_self"
                    }
                    className="btn-primary"
                  >
                    <span className="text-base-500 text-center font-exo text-sm font-bold leading-4 tracking-[0.8px] uppercase">
                      {
                        category.translated.customFields
                          .custom_b2c_settings_menu_about_us_button_text
                      }
                    </span>
                  </Link>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
      <div className="w-full h-12 flex justify-center border-b-8 border-orange-200 z-20 mt-16">
        <div className="bg-orange-200 w-12 hover:border-orange-100 hover:bg-primary">
          <button
            className="flex items-center justify-center p-0 w-full h-full "
            onClick={() => closeMenu()}
          >
            <CrossIcon className="fill-white" />
          </button>
        </div>
      </div>
    </PopoverPanel>
  );
};

const NavigationLayoutShop = ({ category, closeMenu }) => {
  const router = useRouter();
  const pathname = usePathname();
  const dispatch = useDispatch();

  const onClickLink = async (e, href) => {
    e.preventDefault();
    router.push(href);
    closeMenu();
  };

  return (
    <PopoverPanel
      transition
      anchor={{ to: "bottom", gap: "18px" }}
      className="w-full z-20 relative bg-white !overflow-x-hidden !overflow-y-auto transition duration-200 ease-in-out data-[closed]:opacity-0 data-[enter]:data-[closed]:translate-y-full data-[leave]:data-[closed]:translate-y-full"
    >
      <div className="flex justify-start items-stretch gap-4 pl-12 xl:px-0 mx-auto max-w-7xl">
        <div className="basis-3/4">
          <nav
            className={"flex justify-start items-start gap-20 pt-12 h-full"}
            itemScope="itemscope"
            itemType="http://schema.org/SiteNavigationElement"
          >
            {category.children &&
              category.children.map((child) => (
                <div
                  key={child.id}
                  className="h-full flex flex-col items-start pr-20 border-r-[1px] border-base-400 last:border-r-0"
                >
                  <div
                    id={`${child.name}-heading`}
                    className="flex flex-col items-start self-stretch"
                  >
                    <Link
                      href={`${process.env.NEXT_PUBLIC_SITE_URL}${child.seoUrl}`}
                      onClick={(e) =>
                        onClickLink(
                          e,
                          process.env.NEXT_PUBLIC_SITE_URL + child.seoUrl
                        )
                      }
                      className={`text-base-50 `}
                      title={child.name}
                    >
                      <span itemProp="url" className="sr-only">
                        {process.env.NEXT_PUBLIC_SITE_URL}
                        {child.seoUrl}
                      </span>
                    </Link>
                  </div>
                  <div
                    itemProp="name"
                    className="flex pb-4 flex-col items-start p-4"
                  >
                    <div className="text-ellipsis whitespace-nowrap font-exo text-xs leading-6">
                      {child.name}
                    </div>
                  </div>
                  {child.children && child.children.length > 0 && (
                    <ul
                      role="list"
                      aria-labelledby={`${child.name}-heading`}
                      className=" flex-col uppercase gap-3 items-start"
                    >
                      {child.children.map((child) => (
                        <li
                          key={child.id}
                          className={`flex items-start gap-2 self-stretch`}
                        >
                          {child.translated.customFields
                            .custom_b2c_settings_menu_store_rocket ? (
                            <Link
                              href="#"
                              onClick={() => {
                                dispatch(setOpen(true));
                                closeMenu();
                              }}
                              className={classNames(
                                pathname.substring(1).split("/")[2] ===
                                  child.name
                                  ? "open"
                                  : "",
                                "navbar flyout-item"
                              )}
                            >
                              {child.translated.name}
                            </Link>
                          ) : child.linkType === "external" ? (
                            <Link
                              href={child.externalLink}
                              target={child.linkNewTab ? "_blank" : "_self"}
                              className="navbar flyout-item"
                            >
                              {child.translated.name}
                            </Link>
                          ) : (
                            <Link
                              href={`${process.env.NEXT_PUBLIC_SITE_URL}${
                                child.seoUrl ? child.seoUrl : ""
                              }`}
                              onClick={(e) => {
                                onClickLink(
                                  e,
                                  process.env.NEXT_PUBLIC_SITE_URL +
                                    child.seoUrl
                                );
                              }}
                              className={classNames(
                                pathname.substring(1).split("/")[2] ===
                                  child.name ||
                                  pathname.substring(1).split("/")[2] ===
                                    "Fahrräder"
                                  ? "open"
                                  : "",
                                "navbar flyout-item"
                              )}
                              title={child.translated.name}
                            >
                              {child.translated.name}
                            </Link>
                          )}
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              ))}
          </nav>
        </div>

        <div className="flex flex-col items-center gap-6 justify-center flex-1 mt-12">
          <div className="flex py-10 px-12 flex-col justify-center items-start gap-4 bg-base-400">
            <div className="headline-small">
              {
                category.translated.customFields
                  .custom_b2c_settings_menu_shop_title
              }
            </div>

            <div className="body-small">
              {
                category.translated.customFields
                  .custom_b2c_settings_menu_shop_text
              }
            </div>

            {category.translated.customFields
              .custom_b2c_settings_menu_shop_tel && (
              <div className="flex items-center gap-4">
                <div>
                  <Image
                    src={"/static/images/icons/phone-icon.svg"}
                    height={18}
                    width={18}
                    alt="phone-icon"
                  />
                </div>
                <div>
                  <Link
                    href={`tel:${category.translated.customFields.custom_b2c_settings_menu_shop_tel
                      .replace(/\s/g, "")
                      .replace("-", "")}`}
                    title={
                      category.translated.customFields
                        .custom_b2c_settings_menu_shop_tel
                    }
                    className="text-link-small"
                    target="_blank"
                  >
                    {
                      category.translated.customFields
                        .custom_b2c_settings_menu_shop_tel
                    }
                  </Link>
                </div>
              </div>
            )}

            {category.translated.customFields
              .custom_b2c_settings_menu_shop_mail && (
              <div className="flex items-center gap-4">
                <div>
                  <Image
                    src={"/static/images/icons/email-icon.svg"}
                    height={18}
                    width={18}
                    alt="phone-icon"
                  />
                </div>
                <div className="text-link-small truncate">
                  <Link
                    href={`mailto:${category.translated.customFields.custom_b2c_settings_menu_shop_mail}`}
                    title={
                      category.translated.customFields
                        .custom_b2c_settings_menu_shop_mail
                    }
                    className="text-link-small"
                    target="_blank"
                  >
                    {
                      category.translated.customFields
                        .custom_b2c_settings_menu_shop_mail
                    }
                  </Link>
                </div>
              </div>
            )}

            {category.translated.customFields
              .custom_b2c_settings_menu_shop_whatsapp && (
              <div className="flex items-center gap-4">
                <div>
                  <Image
                    src={"/static/images/icons/whatsap-icon.svg"}
                    height={18}
                    width={18}
                    alt="phone-icon"
                    className="max-w-none"
                  />
                </div>
                <div className="text-link-small">
                  <Link
                    href={
                      category.translated.customFields
                        .custom_b2c_settings_menu_shop_whatsapp
                    }
                    title={
                      category.translated.customFields
                        .custom_b2c_settings_menu_shop_whatsapp
                    }
                    className="text-link-small"
                    target="_blank"
                  >
                    {
                      category.translated.customFields
                        .custom_b2c_settings_menu_shop_whatsapp
                    }
                  </Link>
                </div>
              </div>
            )}
          </div>

          <div className="flex items-center gap-4 justify-center w-full">
            <Image
              src={"/static/images/icons/apple-pay.svg"}
              height={29}
              width={45}
              alt="apple-pay"
            />
            <Image
              src={"/static/images/icons/paypal-logo.svg"}
              height={20}
              width={80}
              alt="paypal-pay"
            />
            <Image
              src={"/static/images/icons/visa.svg"}
              height={20}
              width={44}
              alt="visa-pay"
            />
            <Image
              src={"/static/images/icons/mastercard-logo.svg"}
              height={28}
              width={20}
              alt="apple-pay"
            />
            <Image
              src={"/static/images/icons/karma-paymethod.svg"}
              height={20}
              width={63}
              alt="apple-pay"
            />
          </div>
        </div>
      </div>
      <div className="w-full h-12 flex justify-center border-b-8 border-orange-200 z-20 mt-16">
        <div className="bg-orange-200 w-12 hover:border-orange-100 hover:bg-primary">
          <button
            className="flex items-center justify-center p-0 w-full h-full "
            onClick={() => closeMenu()}
          >
            <CrossIcon className="fill-white" />
          </button>
        </div>
      </div>
    </PopoverPanel>
  );
};

export {
  NavigationLayoutAboutUs,
  NavigationLayoutBlog,
  NavigationLayoutDefault,
  NavigationLayoutShop
};

function classNames(...classes) {
  return classes.filter(Boolean).join(" ");
}

import SearchIcon from "@/components/icons/search";
import ShopperIcon from "@/components/icons/shopper";
import { setMobileSearchOpen } from "@/redux/navigation/navigation";
import Image from "next/image";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useRef, useState } from "react";
import { NumericFormat } from "react-number-format";
import { useDispatch, useSelector } from "react-redux";
import { fetchClient } from "@/utility/fetch-client";

const MobileSearchBar = ({ popoverClose }) => {
  const dispatch = useDispatch();
  const snippets = useSelector((state) => state.snippets.snippets);
  const router = useRouter();
  const [searchResult, setSearchResult] = useState(null);
  const [search, setSearch] = useState(null);
  const [listItems, setListItems] = useState(null);
  const inputField = useRef();
  const [currentSelectedResult, setCurrentSelectedResult] = useState(0);
  const setFocus = () => {
    inputField.current.focus();
  };

  const mobileSearchOpen = useSelector(
    (state) => state.navigation.mobileSearchOpen
  );

  const handleSearch = async (search) => {
    if (search.length < 3) return;
    setSearch(search);
    const searchResult = await fetchClient({
      path: "search",
      method: 'POST',
      body: {
        search: search,
        filter: [
          {
            type: "equals",
            field: "customFields.custom_netzkom_configurator_netzkomIsConfiguratorNumber",
            value: null
          },
        ],
      }
    });

    setSearchResult(searchResult.elements);
  };

  const handleKeyDown = (e) => {
    setListItems(document.querySelector("#search-result").childNodes);

    if (e.key === "ArrowUp") {
      moveFocusUp();
    }

    if (e.key === "ArrowDown") {
      moveFocusDown();
    }

    if (e.key === "Enter") {
      if (currentSelectedResult === 0) {
        location.replace("/search?s=" + search);
        return;
      }
      listItems[currentSelectedResult - 1].firstChild.click();
    }

    if (e.key === "Escape") {
      setSearchResult(null);
      setOpen(false);
    }
  };

  const moveFocusDown = () => {
    let current = currentSelectedResult;
    if (currentSelectedResult >= listItems.length) {
      current = 0;
    }

    listItems.forEach((item) => {
      item.firstChild.classList.remove("bg-neutral-100");
    });
    listItems[current].firstChild.classList.add("bg-neutral-100");
    setCurrentSelectedResult(current + 1);
  };

  const moveFocusUp = () => {
    let current = currentSelectedResult;
    if (current <= 0) {
      current = listItems.length;
    }

    listItems.forEach((item) => {
      item.firstChild.classList.remove("bg-neutral-100");
    });
    listItems[current - 1].firstChild.classList.add("bg-neutral-100");
    setCurrentSelectedResult(current - 1);
  };

  useEffect(() => {
    if (mobileSearchOpen) {
      setTimeout(() => {
        setFocus();
      }, 300);
    }
  }, [mobileSearchOpen]);

  return (
    <>
      <div className={`h-full relative bg-base-400`}>
        <div
          className={
            searchResult ? "bg-base-400 h-full p-4 overflow-y-auto" : ""
          }
        >
          <ul role="list" className="grid gap-2" id={"search-result"}>
            {searchResult
              ? searchResult.map((item) =>
                  item.seoUrls ? (
                    <li key={item.id} className="bg-base-500 rounded-lg">
                      <Link
                        href={`/${item.seoUrls[0].seoPathInfo}`}
                        className="block group"
                        onClick={(e) => {
                          e.preventDefault();
                          dispatch(setMobileSearchOpen(false));
                          popoverClose();
                          router.push(`/${item.seoUrls[0].seoPathInfo}`);
                        }}
                      >
                        <div className="flex items-center p-4">
                          <div className="flex flex-1 gap-6 items-center">
                            {item.cover ? (
                              <div className="flex-shrink-0">
                                <Image
                                  className="w-24 object-contain"
                                  src={
                                    item.cover
                                      ? item.cover.media.thumbnails[0].url
                                      : null
                                  }
                                  width={96}
                                  height={96}
                                  alt=""
                                />
                              </div>
                            ) : (
                              <div className="flex-shrink-0">
                                <Image
                                  src="https://fakeimg.pl/192x96/e5e5e5/131313?text=Bild folgt&font=bebas"
                                  alt={item.translated.name}
                                  className="w-24 object-contain"
                                  width={96}
                                  height={96}
                                />
                              </div>
                            )}

                            <div className="flex-1">
                              <div>
                                <span className="font-semibold uppercase text-base-50 group-hover:text-orange-200">
                                  {item.translated.name}
                                </span>
                              </div>

                              <div className="body-small">
                                <p className="">
                                  <span className="truncate">
                                    {item.calculatedPrice.referencePrice
                                      ? "ab "
                                      : null}
                                  </span>
                                  <NumericFormat
                                    value={item.calculatedPrice.unitPrice}
                                    decimalSeparator=","
                                    decimalScale="2"
                                    fixedDecimalScale="true"
                                    displayType={"text"}
                                    thousandSeparator="."
                                    suffix={" €"}
                                  />
                                </p>
                                <div className="body-extra-small">
                                  {item.calculatedPrice.referencePrice ? (
                                    <NumericFormat
                                      value={
                                        item.calculatedPrice.referencePrice
                                          .price
                                      }
                                      decimalSeparator=","
                                      decimalScale="2"
                                      fixedDecimalScale="true"
                                      displayType={"text"}
                                      thousandSeparator="."
                                      prefix={"("}
                                      suffix={
                                        " €* / " +
                                        item.calculatedPrice.referencePrice
                                          .referenceUnit +
                                        " " +
                                        item.calculatedPrice.referencePrice
                                          .unitName +
                                        ")"
                                      }
                                    />
                                  ) : null}
                                  <span>inkl. MwSt. zzgl. Versandkosten</span>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </Link>
                    </li>
                  ) : null
                )
              : null}
          </ul>
          {searchResult && searchResult.length > 0 ? (
            <div className="text-center p-4">
              <a
                className={"text-link text-link-small !no-underline p-6"}
                href={"/search?s=" + search}
              >
                {snippets?.next.search.header.showall}
              </a>
            </div>
          ) : (
            <div className="flex flex-col justify-start items-center pt-3 pb-8">
              <ShopperIcon className="w-20 h-20 mx-auto" />
              <div className="body-small text-center">
                {snippets?.next.search.header.noresult}
              </div>
            </div>
          )}
        </div>
      </div>

      <div className="absolute -bottom-12 left-0 pl-4 w-10/12">
        <input
          type="text"
          className={`inline-block px-4 text-base-50 rounded-md border border-base-500 body-small w-full bg-base-500 focus-within:outline-0 focus:outline-0 focus:ring-0 focus:shadow-none focus:border-base-500`}
          id={"searchInput"}
          data-todo="openSearch"
          placeholder={snippets?.next.search.header.label}
          ref={inputField}
          onKeyDown={handleKeyDown}
          onChange={(e) => {
            if (e.key !== "Enter") {
              handleSearch(e.target.value);
            }
          }}
          data-autofocus
        />
        <div className="absolute end-2 top-1 pt-1">
          <SearchIcon className="fill-base-100 h-8 w-8" aria-hidden="true" />
        </div>
      </div>
    </>
  );
};

export default MobileSearchBar;

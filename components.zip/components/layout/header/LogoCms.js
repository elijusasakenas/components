import LogoIcon from "@/components/icons/logo";
import LogoMobile from "@/components/icons/logo-mobile";
import { setLogoMode } from "@/redux/header/logo";
import { setLogoCmsMode, setLogoCmsVariant } from "@/redux/header/logoCms";
import useScreenSize from "@/utility/useScreenSize";
import PropTypes from "prop-types";
import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";

function LogoCms() {
  const dispatch = useDispatch();
  const screenSize = useScreenSize();
  const enabledCms = useSelector((state) => state.logoCms.logoCmsEnabled);
  const modeCms = useSelector((state) => state.logoCms.logoCmsMode);
  const variantCms = useSelector((state) => state.logoCms.logoCmsVariant);

  useEffect(() => {
    if (enabledCms) {
      if (screenSize.width > 0 && screenSize.width < 1024) {
        //dispatch(setLogoCmsMode("light"));
        dispatch(setLogoCmsVariant("mobile"));
      } else if (screenSize.width > 0 && screenSize.width >= 1024) {
        dispatch(setLogoMode("light"));
        dispatch(setLogoCmsMode("light"));
        dispatch(setLogoCmsVariant("desktop"));
      }
    }
  }, [screenSize, dispatch, enabledCms, modeCms, variantCms]);

  return (
    <div id="LogoCms">
      {variantCms === "desktop" ? (
        <LogoIcon mode={modeCms} />
      ) : (
        <LogoMobile mode={modeCms} />
      )}
    </div>
  );
}

LogoCms.propTypes = {
  mode: PropTypes.oneOf(["dark", "light"]).isRequired,
  variant: PropTypes.oneOf(["mobile", "desktop"]).isRequired,
};

export default LogoCms;

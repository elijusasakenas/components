import Link from "next/link";
import { useState } from "react";

import ApplePayIcon from "@/icons/applepay";
import FaceBookIcon from "@/icons/fb";
import InstaIcon from "@/icons/insta";
import KlarnaIcon from "@/icons/klarna";
import LogoIcon from "@/icons/logo";
import MailIcon from "@/icons/mail";
import MasterCardIcon from "@/icons/mastercard";
import PayPalIcon from "@/icons/paypal";
import PhoneIcon from "@/icons/phone";
import VisaIcon from "@/icons/visa";
import WhatsAppIcon from "@/icons/wa";
import YouTubeIcon from "@/icons/yt";
import axiosInstance from "@/shopware/client";
import { TextField } from "@mui/material";
import { useSelector } from "react-redux";

export default function Footer({ showNewsletter = true, snippets }) {
  const [newsletterMessage, setNewsletterMessage] = useState("");
  const footerNavigation = useSelector(
    (state) => state.navigation.swFooterNavigation
  );

  async function handleNewsletterSubmit(event) {
    event.preventDefault();
    const eventFormData = new FormData(event.target);
    const formData = Object.fromEntries(eventFormData);

    await axiosInstance
      .post("/newsletter/subscribe", formData)
      .then(function (res) {
        console.log(res);
      })
      .catch(function (error) {
        console.log(error);
        setNewsletterMessage(error.message);
      });

    setNewsletterMessage(
      snippets.next.checkout.success.newsletterSuccessMessage
    );
  }

  return (
    snippets && (
      <footer className="bg-base-50 ">
        <div className="mx-auto px-6 md:px-12 xl:px-0 pt-10 max-w-7xl">
          <div className="border-b border-gray-7/20 pb-10">
            <div className="-mx-4 flex flex-wrap items-center">
              <div className="w-full px-4 lg:w-1/2">
                <div className="w-full lg:max-w-[512px]">
                  <p className="B1emphasis text-base-500 mb-10 lg:mb-0">
                    {snippets?.next.footer.newsletterHeadline}
                  </p>
                </div>
              </div>
              <div className="w-full px-4 lg:w-1/2">
                <div className="w-full">
                  {newsletterMessage ? (
                    <div className={"w-full max-w-md lg:col-span-5 lg:pt-2"}>
                      <p className={"body-small text-base-500"}>
                        {newsletterMessage}
                      </p>
                    </div>
                  ) : (
                    <>
                      <form
                        className="flex flex-col md:flex-row justify-start items-stretch w-full"
                        onSubmit={handleNewsletterSubmit}
                      >
                        <input
                          type={"hidden"}
                          name={"option"}
                          value={"subscribe"}
                        />
                        <input
                          type={"hidden"}
                          name={"storefrontUrl"}
                          value={process.env.NEXT_PUBLIC_SW_APP_URL}
                        />
                        <div className="relative mb-3 md:pr-5 flex-1">
                          <TextField
                            sx={{
                              "& .MuiOutlinedInput-input:focus": {
                                boxShadow: "none",
                              },
                              "& .MuiOutlinedInput-input": {
                                boxShadow: "none",
                                border: "1px solid #ffffff",
                                backgroundColor: "#ffffff",
                              },
                              "& .MuiOutlinedInput-notchedOutline": {
                                border: "0 !important",
                              },
                            }}
                            error={false}
                            required={true}
                            helperText=""
                            placeholder={
                              snippets?.next.footer.newsletterInputLabel
                            }
                            type="email"
                            id="email"
                            name="email"
                            fullWidth
                            size="small"
                          />
                        </div>
                        <div>
                          <button
                            type="submit"
                            className="mb-3 btn-primary w-full"
                          >
                            {snippets?.next.footer.newsletterButtonLabel}
                          </button>
                        </div>
                      </form>
                      <div className={"body-extra-small text-base-300"}>
                        {snippets?.next.footer.newsletterPolicyHint}{" "}
                        <Link
                          className="text-link"
                          href={snippets?.next.footer.newsletterPolicyLinkUrl}
                        >
                          {snippets?.next.footer.newsletterPolicyLinkText}
                        </Link>
                      </div>
                    </>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="mx-auto px-6 md:px-12 xl:px-0 py-10 pb-0 max-w-7xl">
          <div className="-mx-4 flex flex-wrap">
            <div className="w-full px-4 lg:w-6/12">
              <div className="mb-10 w-full  md:max-w-[270px]">
                <div className="mb-6 inline-block max-w-[160px]">
                  <LogoIcon />
                </div>
                <p className="mb-7 body-extra-small text-base-300">
                  {snippets?.next.footer.companyText}
                </p>
                <div className="-mx-3 flex items-center">
                  <Link
                    title="Facebook"
                    href={snippets?.next.social.fb}
                    target="_blank"
                    className="px-3 text-base-500 text-link"
                  >
                    <FaceBookIcon className="lg:h-6" />
                  </Link>
                  <Link
                    title="Instagram"
                    href={snippets?.next.social.insta}
                    target="_blank"
                    className="px-3 text-base-500 text-link"
                  >
                    <InstaIcon className={"lg:h-6"} />
                  </Link>
                  <Link
                    title="YouTube"
                    href={snippets?.next.social.yt}
                    target="_blank"
                    className="px-3 text-base-500 text-link"
                  >
                    <YouTubeIcon className={"lg:h-6"} />
                  </Link>
                </div>
              </div>
            </div>
            {footerNavigation &&
              footerNavigation.length > 0 &&
              footerNavigation.map((nav) => (
                <LinkGroup header={nav.translated.name} key={nav.id}>
                  {nav.children.map((child) =>
                    child.type === "page" ? (
                      <NavLink
                        link={
                          process.env.NEXT_PUBLIC_SITE_URL +
                          "/" +
                          child?.seoUrls[0]?.seoPathInfo
                        }
                        label={child.translated.name}
                        key={child.id}
                      />
                    ) : (
                      <Link
                        href={child?.seoUrl ? child?.seoUrl : "/"}
                        target={
                          child.linkType === "external" ? "_blank" : "_self"
                        }
                        key={child.id}
                        className="text-link text-base-500 body-extra-small"
                      >
                        {child.translated.name}
                      </Link>
                    )
                  )}
                </LinkGroup>
              ))}
            <div className="w-full px-4 md:w-4/12 lg:w-2/12">
              <div className="mb-10 w-full">
                <p className="mb-4 B3emphasis text-base-500">
                  {snippets?.next.footer.contactHeadline}
                </p>
                <p className={"body-extra-small text-base-300 mb-4"}>
                  {" "}
                  {snippets?.next.footer.contactText}
                </p>
                <ul className="flex flex-col justify-start items-start gap-2">
                  <li className="flex">
                    <Link
                      href={`tel:${snippets?.next.footer.phoneNumber
                        .replace(/\s/g, "")
                        .replace("-", "")}`}
                      target="_blank"
                      className="body-extra-small text-link text-base-500 inline-flex items-center justify-start gap-3 group"
                    >
                      <PhoneIcon
                        className={
                          "fill-base-500 group-hover:fill-orange-200 w-4 h-4"
                        }
                      />
                      {snippets?.next.footer.phoneNumber}
                    </Link>
                  </li>
                  <li className="flex">
                    <Link
                      href={"mailto:" + snippets?.next.footer.emialAddress}
                      target="_blank"
                      className="body-extra-small text-link text-base-500 inline-flex items-center justify-start gap-3 group"
                    >
                      <MailIcon
                        className={
                          "fill-base-500 group-hover:fill-orange-200 w-4 h-4"
                        }
                      />
                      {snippets?.next.footer.emialAddress}
                    </Link>
                  </li>
                  <li className="flex">
                    <Link
                      href={
                        "https://wa.me/" +
                        snippets?.next.footer.WhatsAppLinkNumber +
                        "?text=" +
                        snippets?.next.footer.WhatsAppLinkText
                      }
                      target="_blank"
                      className="body-extra-small text-link text-base-500 inline-flex items-center justify-start gap-3 group"
                    >
                      <WhatsAppIcon
                        className={
                          "fill-base-500 group-hover:fill-orange-200 w-4 h-4"
                        }
                      />
                      {snippets?.next.footer.WhatsAppLabel}
                    </Link>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>

        <div className="pt-4 bg-base-500 mx-auto px-6 py-4 pb-24 lg:pb-4 md:px-12 xl:px-0">
          <div className="mx-auto max-w-7xl ">
            <div className="flex flex-wrap  items-center">
              <div className="w-4/12 xs:w-full md:w-1/2">
                <div className="my-1 flex justify-start">
                  <p className="body-extra-small text-base-50">
                    &copy; {new Date().getFullYear()} Tout-Terrain
                  </p>
                </div>
              </div>
              <div className="w-8/12 xs:w-full md:w-1/2">
                <div className="flex flex-wrap justify-start md:justify-end mt-4 md:mt-0 ">
                  <div className={"flex gap-4"}>
                    <ApplePayIcon />
                    <PayPalIcon />
                    <VisaIcon />
                    <MasterCardIcon />
                    <KlarnaIcon />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </footer>
    )
  );
}

const LinkGroup = ({ children, header }) => {
  return (
    <div className="w-full md:w-4/12 lg:w-2/12 px-4">
      <div className="mb-10 w-full">
        <p className="body-small-emphasis text-base-500 mb-6"> {header} </p>
        <ul className="flex flex-col justify-start items-start gap-4 md:gap-2">
          {children}
        </ul>
      </div>
    </div>
  );
};

const NavLink = ({ label, link }) => {
  return (
    <li className={"body-extra-small"}>
      <Link href={link} className="text-link text-base-500">
        {label}
      </Link>
    </li>
  );
};
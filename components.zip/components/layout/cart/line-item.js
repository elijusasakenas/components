"use client";

import { setSwCart } from "@/redux/cart/cart";
import { DeleteLineItem } from "@/shopware/cart";
import { fetchClient } from "@/utility/fetch-client";
import {
  Field,
  Label,
  Listbox,
  ListboxButton,
  ListboxOption,
  ListboxOptions,
  Transition,
} from "@headlessui/react";
import {
  CheckIcon,
  ChevronDownIcon,
  TrashIcon,
} from "@heroicons/react/20/solid";
import { Snippet } from "next/font/google";
import Image from "next/image";
import Link from "next/link";
import { Fragment, useEffect, useState } from "react";
import { NumericFormat } from "react-number-format";

const shimmer = (w, h) => `
<svg width="${w}" height="${h}" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
  <defs>
    <linearGradient id="g">
      <stop stop-color="#EFF0F2" offset="20%" />
      <stop stop-color="#DFE1E5" offset="50%" />
      <stop stop-color="#EFF0F2" offset="70%" />
    </linearGradient>
  </defs>
  <rect width="${w}" height="${h}" fill="#EFF0F2" />
  <rect id="r" width="${w}" height="${h}" fill="url(#g)" />
  <animate xlink:href="#r" attributeName="x" from="-${w}" to="${w}" dur="1s" repeatCount="indefinite"  />
</svg>`;

const toBase64 = (str) =>
  typeof window === "undefined"
    ? Buffer.from(str).toString("base64")
    : window.btoa(str);

export default function LineItem({ product, dispatch, snippets }) {
  const [thumbnail, setThumbnail] = useState(null);
  const [deleteLineItem, setDeleteLineItem] = useState(false);
  const quantities = [
    { id: 1, name: "1" },
    { id: 2, name: "2" },
    { id: 3, name: "3" },
    { id: 4, name: "4" },
    { id: 5, name: "5" },
    { id: 6, name: "6" },
    { id: 7, name: "7" },
    { id: 8, name: "8" },
    { id: 9, name: "9" },
    { id: 10, name: "10" },
  ];
  const [selectedQuantity, setSelectedQuantity] = useState(
    quantities[product.quantity - 1]
  );
  const handleDeleteClick = () => {
    setDeleteLineItem(true);
  };

  async function UpdateLineItem(event) {
    setSelectedQuantity(event);
    const data = await fetchClient({
      path: "checkout/cart/line-item",
      body: {
        items: [
          {
            id: product.id,
            referencedId: product.referencedId,
            quantity: event.id,
          },
        ],
      },
      method: "PATCH",
    });

    if (data) dispatch(setSwCart(data));
  }

  useEffect(() => {
    if (product.cover != null) {
      const thumbnail =
        product.cover.thumbnails[1].width > 300
          ? product.cover.thumbnails[1]
          : product.cover.thumbnails[2];
      setThumbnail(thumbnail);
    }
  }, [product]);
  return (
    <li key={product.id} className="flex p-4 bg-base-500 rounded-lg">
      {product.type === "product" && (
        <div className="flex-none pt-1">
          <Link href={`/product/${product.referencedId}`}>
            {thumbnail ? (
              <Image
                src={thumbnail.url}
                alt={
                  product.cover.translated.alt
                    ? product.cover.translated.alt
                    : product.label
                }
                width={thumbnail.width}
                height={thumbnail.height}
                className="h-auto w-12 md:w-24 object-contain object-top"
                placeholder={`data:image/svg+xml;base64,${toBase64(
                  shimmer(700, 475)
                )}`}
              />
            ) : (
              <Image
                src="https://fakeimg.pl/192x96/e5e5e5/131313?text=Bild folgt&font=bebas"
                alt={product.label}
                className="h-auto w-12 md:w-24 object-contain object-top"
                width={192}
                height={192}
              />
            )}
          </Link>
        </div>
      )}
      <div className={"flex-auto"}>
        <div className="pl-4 pr-2">
          {product.type === "product" ? (
            <Link href={`/product/${product.referencedId}`} className="text-link font-bold text-base">
              {product.label}
            </Link>
          ) : (
            <span>{product.label}</span>
          )}
        </div>
        <div className="text-xs pl-4">
          {product.type === "product" &&
            product.deliveryInformation?.deliveryTime && (
              <p className="flex space-x-2  body-extra-small text-base-50 pt-0">
                <span>
                  {snippets.next.offCanvasCart.item.deliveryShippingTime} {product.deliveryInformation.deliveryTime.name}
                </span>
              </p>
            )}
          {product.type === "product" && product.price?.unitPrice > 0 && (
            <a
              href="#"
              title={snippets.next.offCanvasCart.item.delete}
              aria-label="delete"
              className={"inline-flex group mt-2"}
              onClick={handleDeleteClick}
            >
              {deleteLineItem && (
                <DeleteLineItem
                  id={product.id}
                  setDeleteLineItem={setDeleteLineItem}
                />
              )}
              {!deleteLineItem && (
                <div className="flex justify-center items-center space-x-1">
                  <div>
                    <TrashIcon
                      className="h-4 w-4 flex-shrink-0 text-base-300 group-hover:text-orange-400"
                      aria-hidden="true"
                    />
                  </div>
                  <div className={"text-base-200 leading-4 group-hover:text-orange-400"}>
                    {snippets.next.offCanvasCart.item.delete}
                  </div>
                </div>
              )}
            </a>
          )}
        </div>
      </div>

      <div className={"flex-auto w-36 flex flex-col justify-between"}>
        <p className="text-base-50 p-0 text-right text-sm whitespace-nowrap">
          <NumericFormat
            value={product.price?.unitPrice}
            decimalSeparator=","
            decimalScale="2"
            fixedDecimalScale="true"
            displayType={"text"}
            thousandSeparator="."
            suffix={" €*"}
          />
        </p>
        {product.type === "product" && product.price?.unitPrice > 0 && (
          <Field
            className={
              "text-base-200 p-0 text-right text-sm font-medium flex justify-end flex-row align-middle items-baseline"
            }
          >
            <Label className={"mr-1 text-xs md:text-sm"}>{snippets.next.offCanvasCart.item.quantity}</Label>
            <Listbox
              value={selectedQuantity}
              onChange={(event) => UpdateLineItem(event)}
            >
              <ListboxButton
                className={
                  "relative w-12 cursor-default rounded-lg bg-white py-1 pl-1 pr-4 text-center focus:outline-none  focus-visible:ring-white/75 focus-visible:ring-offset-2 focus-visible:ring-offset-orange-300 sm:text-sm"
                }
              >
                <span className="block truncate text-base-50">
                  {selectedQuantity.name}
                </span>
                <span className="pointer-events-none absolute inset-y-0 right-0 flex items-center">
                  <ChevronDownIcon
                    className="h-5 w-5 text-neutral-400"
                    aria-hidden="true"
                  />
                </span>
              </ListboxButton>
              <Transition
                as={Fragment}
                leave="transition ease-in duration-100"
                leaveFrom="opacity-100"
                leaveTo="opacity-0"
              >
                <ListboxOptions className="select absolute max-h-60 md:max-h-[400px] w-12 overflow-auto rounded-md bg-white text-center shadow-lg ring-1 ring-black/5 focus:outline-none sm:text-sm z-10">
                  {quantities.map((quantity, quantityIdx) => (
                    <ListboxOption
                      key={quantityIdx}
                      className={({ active }) =>
                        `relative cursor-default select-none py-2 pr-2 ${
                          active ? "bg-orange text-white" : "text-neutral-900"
                        }`
                      }
                      value={quantity}
                    >
                      {({ selectedQuantity }) => (
                        <>
                          <span
                            className={`block truncate ${
                              selectedQuantity ? "font-medium" : "font-normal"
                            }`}
                          >
                            {quantity.name}
                          </span>
                          {selectedQuantity ? (
                            <span className="absolute inset-y-0  flex items-center text-amber-600">
                              <CheckIcon
                                className="h-5 w-5"
                                aria-hidden="true"
                              />
                            </span>
                          ) : null}
                        </>
                      )}
                    </ListboxOption>
                  ))}
                </ListboxOptions>
              </Transition>
            </Listbox>
          </Field>
        )}
      </div>
    </li>
  );
}

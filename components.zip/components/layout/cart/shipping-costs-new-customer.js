import Image from "next/image";
import {useSelector} from "react-redux";

export default function ShippingCostsNewCustomer({isNewCustomer,id}) {

    const snippets = useSelector((state) => state.snippets.snippets);
    const swCart = useSelector((state) => state.cart.swCart);
    if(snippets?.checkout?.promotion?.newCustomer.headline === undefined) return null;

    if(swCart.deliveries[0].shippingCosts.totalPrice <= 0) return null;

    return (
            <div className={`mt-5 flex flex-col pt-2.5 bg-white rounded-xl border border-solid border-[color:var(--Base-Base-500,#D6D6D6)] max-md:max-w-full relative ${isNewCustomer}`} id={id}>
                <Image
                    className="object-cover absolute top-[-25px] right-[15px] z-10"
                    src="/static/images/gift.svg"
                    width={56}
                    height={56}
                    alt={"Neukundenrabatt"}/>
                <div className="flex overflow-hidden relative flex-col px-6 pt-1.5 pb-4 w-full fill-blue-800 min-h-[154px] max-md:px-5 max-md:max-w-full rounded-xl bg-gradient-blue-white">
                    <Image
                        className="object-contain absolute top-0 left-0 size-full mt-[25px] rounded-xl "
                        src="/static/images/waves.svg"
                        width={600}
                        height={129}
                     alt={"Neukundenrabatt"}/>
                        <div className="relative text-sm font-semibold text-orange-400 max-md:max-w-full">
                            {snippets.checkout.promotion.newCustomer.headline}
                        </div>
                    <div className="relative mt-8 font-semibold leading-5 text-sm text-orange-500 max-md:max-w-full" dangerouslySetInnerHTML={{ __html: snippets.checkout.promotion.newCustomer.subline }}></div>
                        <div className="flex relative gap-5 justify-between px-2 py-1 mt-2 w-full whitespace-nowrap bg-white rounded-md max-md:flex-wrap max-md:max-w-full text-sm">
                            <div className="text-neutral-900 leading-[143%]">Versandkosten</div>
                            <div className="flex gap-2 justify-between text-right">
                                <div className="grow leading-[143%] text-teal-950 line-through">{snippets.checkout.promotion.newCustomer.listPrice} €*</div>
                                <div className="grow my-auto font-semibold tracking-normal text-orange-400 leading-[100%]">
                                    {snippets.checkout.promotion.newCustomer.price} €*
                                </div>
                            </div>
                        </div>
                        <div className="relative mt-2 text-xs leading-4 text-white max-md:max-w-full">
                            {snippets.checkout.promotion.newCustomer.hint}
                        </div>
                </div>
            </div>
    );
}

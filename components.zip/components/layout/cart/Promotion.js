import { setSwCart } from "@/redux/cart/cart";
import { fetchClient } from "@/utility/fetch-client";
import { BarsArrowUpIcon } from "@heroicons/react/20/solid";
import { useRef, useState } from "react";
import { useDispatch } from "react-redux";

const AddCodeToCart = async (code) => {
  const res = await fetchClient({
    path: "checkout/cart/line-item",
    method: "POST",
    body: {
      items: [
        {
          referencedId: code,
          type: "promotion",
        },
      ],
    },
  });
  return res;
};

const Promotion = ({ snippets }) => {
  const dispatch = useDispatch();
  const [promotionResult, setPromotionResult] = useState();
  const promotionCodeRef = useRef();

  const handlePromoEnter = (event) => {
    if (event.key === "Enter") {
      event.preventDefault();
      handlePromotion();
    }
  };

  const handlePromotion = () => {
    const promotionCode = promotionCodeRef.current.value;
    if (promotionCode) {
      const res = AddCodeToCart(promotionCode);
      res.then((data) => {
        HandleResponse(data);
        dispatch(setSwCart(data));
      });
    } else {
      setPromotionResult();
    }
  };

  const HandleResponse = (data) => {
    if (data.errors.length === 0) {
      setPromotionResult({
        message: snippets.next.offCanvasCart.promotion.codeExists,
        success: true,
      });
      promotionCodeRef.current.value = "";
      setTimeout(() => {
        setPromotionResult(null);
      }, 5000);
    } else {
      let message = "";
      let success = false;

      Object.keys(data.errors).forEach((i) => {
        if (data.errors[i].messageKey === "promotion-discount-added") {
          message = snippets.next.offCanvasCart.promotion.added.replace(/{code}/g, data.errors[i].parameters.name);
          success = true;
          promotionCodeRef.current.value = "";
          setTimeout(() => {
            setPromotionResult(null);
          }, 5000);
        }
        if (data.errors[i].messageKey === "promotion-not-found") {
          message = snippets.next.offCanvasCart.promotion.notFound.replace(/{code}/g, data.errors[i].promotionCode);
        }
      });
      setPromotionResult({ message: message, success: success });
    }
  };

  return (
    <section className={"bg-base-500 -mx-4 md:-mx-6 px-4 md:px-6 pt-4"}>
      <div className="flex rounded-md shadow-sm">
        <div className="relative flex flex-grow items-stretch focus-within:z-10">
          <input
            ref={promotionCodeRef}
            type="text"
            name="promotionCode"
            id="promotionCode"
            onKeyDown={handlePromoEnter}
            className="block w-full p-3 rounded-l-lg border-base-300 border-r-0 bg-base-400 shadow-none focus:ring-0 focus:outline-0 focus:border-orange-200"
            placeholder={snippets.next.offCanvasCart.promotion.inputPlaceholder}
          />
        </div>
        <button
          onClick={handlePromotion}
          type="button"
          className="btn-secondary btn-small !flex-row gap-2 !rounded-l-none !border-base-300"
        >
          <BarsArrowUpIcon className="h-6 w-6" aria-hidden="true" />
          {snippets.next.offCanvasCart.promotion.submitButton}
        </button>
      </div>

      {promotionResult &&
        (promotionResult.success ? (
          <div className="mt-1 body-small p-4 bg-base-500 rounded-lg border-[1px] border-base-400 flex items-start justify-start gap-3">
            <div>
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="25"
                height="24"
                viewBox="0 0 25 24"
                fill="none"
              >
                <path
                  d="M22.5 12C22.5 17.5242 17.9839 22 12.5 22C6.97581 22 2.5 17.5242 2.5 12C2.5 6.51613 6.97581 2 12.5 2C17.9839 2 22.5 6.51613 22.5 12ZM11.3306 17.3226L18.75 9.90323C18.9919 9.66129 18.9919 9.21774 18.75 8.97581L17.8226 8.08871C17.5806 7.80645 17.1774 7.80645 16.9355 8.08871L10.8871 14.1371L8.02419 11.3145C7.78226 11.0323 7.37903 11.0323 7.1371 11.3145L6.20968 12.2016C5.96774 12.4435 5.96774 12.8871 6.20968 13.129L10.4032 17.3226C10.6452 17.5645 11.0887 17.5645 11.3306 17.3226Z"
                  fill="#14B8A6"
                />
              </svg>
            </div>
            <div
              dangerouslySetInnerHTML={{ __html: promotionResult.message }}
            />
          </div>
        ) : (
          <div className="mt-1 body-small p-4 bg-base-500 rounded-lg border-[1px] border-base-400 flex items-start justify-start gap-3">
            <div>
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="25"
                height="24"
                viewBox="0 0 25 24"
                fill="none"
              >
                <path
                  d="M22.8789 18.754C23.5117 19.879 22.7031 21.2501 21.4024 21.2501H4.56252C3.26174 21.2501 2.45314 19.8438 3.08596 18.754L11.5235 4.0938C12.1563 2.9688 13.8086 3.00396 14.4414 4.0938L22.8789 18.754ZM13 15.6954C12.086 15.6954 11.3828 16.4336 11.3828 17.3126C11.3828 18.2266 12.086 18.9297 13 18.9297C13.8789 18.9297 14.6172 18.2266 14.6172 17.3126C14.6172 16.4336 13.8789 15.6954 13 15.6954ZM11.4531 9.89458L11.6992 14.6758C11.7344 14.9219 11.9102 15.0626 12.1211 15.0626H13.8438C14.0547 15.0626 14.2305 14.9219 14.2656 14.6758L14.5117 9.89458C14.5469 9.64849 14.336 9.43755 14.0899 9.43755H11.875C11.6289 9.43755 11.418 9.64849 11.4531 9.89458Z"
                  fill="#EF4444"
                />
              </svg>
            </div>
            <div
              dangerouslySetInnerHTML={{ __html: promotionResult.message }}
            />
          </div>
        ))}
    </section>
  );
};

export default Promotion;

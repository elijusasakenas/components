"use client";

import {
  Dialog,
  DialogPanel,
  DialogTitle,
  Transition,
  TransitionChild,
} from "@headlessui/react";
import { XMarkIcon } from "@heroicons/react/24/outline";
import { IconButton } from "@mui/material";
import { useRouter } from "next/navigation";
import { Fragment } from "react";
import { NumericFormat } from "react-number-format";
import { useDispatch, useSelector } from "react-redux";

import LineItem from "@/components/layout/cart/line-item";
import ShippingCostsNewCustomer from "@/components/layout/cart/shipping-costs-new-customer";
import { setOpen } from "@/redux/cart/cart";
import * as gtag from "@/utility/gtag";
import Link from "next/link";
import Promotion from "./Promotion";

export default function OffCanvasCart({ snippets }) {
  const router = useRouter();
  const dispatch = useDispatch();

  const cartOpen = useSelector((state) => state.cart.open);
  const swCart = useSelector((state) => state.cart.swCart);

  const handleCheckout = async (event) => {
    event.preventDefault();
    dispatch(setOpen(!cartOpen));

    let lineItems = [];

    swCart.lineItems.map((item) => {
      lineItems.push({
        id: item.payload.productNumber,
        name: item.label,
        brand: process.env.NEXT_PUBLIC_SITE_NAME,
        price: item.price.unitPrice,
        quantity: item.quantity,
      });
    });
    gtag.dataLayer({ ecommerce: null });
    gtag.dataLayer({
      event: "checkout",
      ecommerce: {
        checkout: {
          products: lineItems,
        },
      },
    });

    router.push("/checkout");
  };

  const toggleCart = () => {
    dispatch(setOpen(!cartOpen));
  };

  return (
    swCart && (
      <Transition show={cartOpen} as={Fragment}>
        <Dialog as="div" className="relative z-30" onClose={toggleCart}>
          <div className="fixed inset-0 bg-base-50/80" />

          <div
            className={
              "pointer-events-none fixed inset-y-0 right-0 flex max-w-full"
            }
          >
            <TransitionChild
              as={Fragment}
              enter="transform transition ease-in-out duration-500"
              enterFrom="translate-x-full"
              enterTo="translate-x-0"
              leave="transform transition ease-in-out duration-150"
              leaveFrom="translate-x-0"
              leaveTo="translate-x-full"
            >
              <DialogPanel className="pointer-events-auto w-screen max-w-xl">
                <div className="flex h-full flex-col overflow-y-scroll bg-base-400 pt-6 shadow-xl">
                  <div className="px-4 sm:px-6">
                    <div className="flex items-start justify-between text-base-50 headline-small">
                      <DialogTitle className={"p-0 mt-2"}>
                        {snippets.next.offCanvasCart.title} ({swCart.lineItems?.length})
                      </DialogTitle>
                      <div className="">
                        <IconButton
                          aria-label="increase"
                          className="-m-2 ml-2 inline-flex p-2 text-base-300 hover:text-base-50 h-12 w-12"
                          onClick={() => dispatch(setOpen(false))}
                        >
                          <XMarkIcon className="h-8 w-8" aria-hidden="true" />
                        </IconButton>
                      </div>
                    </div>
                  </div>
                  <div className="relative mt-2 flex-1 px-4 sm:px-6">
                    <div className="">
                      <div className="mx-auto max-w-3xl lg:max-w-7xl">
                        {swCart.lineItems?.length > 0 ? (
                          <form
                            action={"#"}
                            onSubmit={handleCheckout}
                            method="POST"
                            className="mt-4"
                          >
                            <section
                              aria-labelledby="cart-heading"
                              className="pb-4"
                            >
                              <p id="cart-heading" className="sr-only">
                                Ihr Warenkorb
                              </p>
                              <ul role="list" className="grid gap-2">
                                {swCart.lineItems.map((product) => (
                                  <LineItem
                                    key={product.id}
                                    product={product}
                                    dispatch={dispatch}
                                    snippets={snippets}
                                  />
                                ))}
                              </ul>
                            </section>

                            <Promotion snippets={snippets} />

                            {/* Order summary */}
                            <section
                              aria-labelledby="summary-heading"
                              className="bg-base-500 px-4 py-4 -mx-4 md:-mx-6 md:px-6"
                            >
                              <dl className="space-y-2">
                                <div className="flex items-center justify-between">
                                  <dt className="text-sm text-neutral-600">
                                    {snippets.next.offCanvasCart.subtotal}
                                  </dt>
                                  <dd className="text-sm font-medium text-neutral-900">
                                    <NumericFormat
                                      value={swCart.price.positionPrice}
                                      decimalSeparator=","
                                      decimalScale="2"
                                      fixedDecimalScale="true"
                                      displayType={"text"}
                                      thousandSeparator="."
                                      suffix={" €*"}
                                    />
                                  </dd>
                                </div>
                                <div className="flex items-center justify-between pt-2">
                                  <dt className="flex items-center text-sm text-neutral-600">
                                    <span>{snippets.next.offCanvasCart.shippingCosts}</span>
                                  </dt>
                                  <dd className="text-sm font-medium text-neutral-900">
                                    <NumericFormat
                                      value={
                                        swCart.deliveries[0].shippingCosts
                                          .unitPrice
                                      }
                                      decimalSeparator=","
                                      decimalScale="2"
                                      fixedDecimalScale="true"
                                      displayType={"text"}
                                      thousandSeparator="."
                                      suffix={" €*"}
                                    />
                                  </dd>
                                </div>

                                <div className="flex items-center justify-between border-t border-b border-gray-200 py-4">
                                  <dt className="text-base font-bold text-neutral-900">
                                    {snippets.next.offCanvasCart.total}
                                  </dt>
                                  <dd className="text-base font-bold text-neutral-900">
                                    <NumericFormat
                                      value={swCart.price.totalPrice}
                                      decimalSeparator=","
                                      decimalScale="2"
                                      fixedDecimalScale="true"
                                      displayType={"text"}
                                      thousandSeparator="."
                                      suffix={" €*"}
                                    />
                                  </dd>
                                </div>
                              </dl>

                              <ShippingCostsNewCustomer />

                              <div className="mt-6 text-center">
                                <button
                                  type="submit"
                                  className="w-full mt-2 md:mt-0 btn-primary"
                                >
                                  {snippets.next.offCanvasCart.toCheckoutButton}
                                  <span aria-hidden="true"> &rarr;</span>
                                </button>
                                <Link
                                  href={"#"}
                                  className="w-full mt-2 btn-secondary"
                                  onClick={() => dispatch(setOpen(false))}
                                >
                                  {snippets.next.offCanvasCart.continueShoppingButton}
                                </Link>
                              </div>
                              <div className="mt-2 text-center text-sm text-base-50">
                                <p className={"body-extra-small text-base-300"}>
                                  {snippets.next.offCanvasCart.tax}
                                </p>
                              </div>
                            </section>
                          </form>
                        ) : (
                          <p className="text-sm">{snippets.next.offCanvasCart.empty}</p>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </DialogPanel>
            </TransitionChild>
          </div>
        </Dialog>
      </Transition>
    )
  );
}

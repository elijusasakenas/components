import Image from "next/image";
import { MinusCircleIcon, PlusCircleIcon, TicketIcon, TrashIcon } from "@heroicons/react/20/solid";
import { IconButton } from "@mui/material";
import { useState } from "react";
import { NumericFormat } from "react-number-format";
import { DeleteLineItem, IncreaseDecreaseQuantity } from "@/shopware/cart";

export default function LineItem({ product }) {
  const [deleteLineItem, setDeleteLineItem] = useState(false);
  const [updateLineItem, setUpdateLineItem] = useState("none");

  const handleDeleteClick = () => {
    setDeleteLineItem(true);
  };

  const handleIncreaseDecreaseQuantityClick = (direction) => {
    setUpdateLineItem(direction);
  };

  return (
    <li key={product.id} className="flex px-4 py-6 sm:px-6">
      <div className="flex-shrink-0">
        {product.type === "product" && (
          <Image
            width={80}
            height={80}
            src={product.cover.url}
            alt={product.cover.translated.title}
            className="w-20 rounded-md"
          />
        )}
        {product.type === "promotion" && (
          <TicketIcon className="w-20 rounded-md text-neutral-100" />
        )}
      </div>
      <div className="ml-6 flex flex-1 flex-col">
        <div className="flex">
          <div className="min-w-0 flex-1">
            <div>
              <a
                href={"/product/" + product.id}
                className="font-semibold hover:text-orange-500"
              >
                {product.label}{" "}
                {product.type === "promotion" && (
                  <span className={"block mt-2"}>
                    <NumericFormat
                      value={product.price.totalPrice}
                      decimalSeparator=","
                      decimalScale="2"
                      fixedDecimalScale="true"
                      displayType={"text"}
                      thousandSeparator="."
                      suffix={" €*"}
                    />{" "}
                    {product.price.referencePrice
                      ? " | " && (
                          <NumericFormat
                            value={product.price.referencePrice.price}
                            decimalSeparator=","
                            decimalScale="2"
                            fixedDecimalScale="true"
                            displayType={"text"}
                            thousandSeparator="."
                            prefix={" ("}
                            suffix={
                              " €* / " +
                              product.price.referencePrice.referenceUnit +
                              " " +
                              product.price.referencePrice.unitName +
                              ")"
                            }
                          />
                        )
                      : null}{" "}
                  </span>
                )}
              </a>
            </div>
            {product.price.referencePrice ? (
              <p className={"text-neutral-500 text-xs"}>
                Inhalt: {product.price.referencePrice.purchaseUnit}{" "}
                {product.price.referencePrice.unitName}
              </p>
            ) : null}
          </div>

          <div className="ml-4 flow-root flex-shrink-0">
            <IconButton
              aria-label="delete"
              className="-m-2 inline-flex p-2 text-neutral-400 hover:text-neutral-500"
              onClick={handleDeleteClick}
            >
              <span className="sr-only">löschen</span>
              {deleteLineItem && (
                <DeleteLineItem
                  id={product.id}
                  setDeleteLineItem={setDeleteLineItem}
                />
              )}
              {!deleteLineItem && (
                <TrashIcon className="h-5 w-5" aria-hidden="true" />
              )}
            </IconButton>
          </div>
        </div>
        {product.type === "product" && (
          <div className="flex flex-1 items-end justify-between pt-2">
            <p className="text-sm font-medium text-neutral-900">
              <span className={"block mb-2"}>Gesamtpreis:</span>
              <NumericFormat
                value={product.price.totalPrice}
                decimalSeparator=","
                decimalScale="2"
                fixedDecimalScale="true"
                displayType={"text"}
                thousandSeparator="."
                suffix={" €*"}
              />{" "}
              {product.price.referencePrice
                ? " | " && (
                    <NumericFormat
                      value={product.price.referencePrice.price}
                      decimalSeparator=","
                      decimalScale="2"
                      fixedDecimalScale="true"
                      displayType={"text"}
                      thousandSeparator="."
                      prefix={" ("}
                      suffix={
                        " €* / " +
                        product.price.referencePrice.referenceUnit +
                        " " +
                        product.price.referencePrice.unitName +
                        ")"
                      }
                    />
                  )
                : null}
            </p>
            <div className="text-sm font-medium text-neutral-900">
              <div className="custom-number-input">
                Menge:
                <div className="flex flex-row h-10 w-full rounded-lg relative bg-transparent pt-3 pr-4">
                  {product.quantity >= 2 ? (
                    <IconButton
                      aria-label="decrease"
                      className="-m-2 mr-2 inline-flex p-2 text-neutral-400 hover:text-neutral-500 h-5 w-5"
                      onClick={() =>
                        handleIncreaseDecreaseQuantityClick("decrease")
                      }
                    >
                      {updateLineItem === "decrease" && (
                        <IncreaseDecreaseQuantity
                          lineItem={{
                            id: product.id,
                            referencedId: product.referencedId,
                            quantity: product.quantity - 1,
                          }}
                          setUpdateLineItem={setUpdateLineItem}
                        />
                      )}
                      {updateLineItem === "none" && (
                        <MinusCircleIcon
                          className="h-5 w-5 flex-shrink-0 text-neutral-300"
                          aria-hidden="true"
                        />
                      )}
                    </IconButton>
                  ) : (
                    <IconButton
                      aria-label="delete"
                      className="-m-2 mr-2 inline-flex p-2 text-neutral-400 cursor-default h-5 w-5"
                    >
                      <MinusCircleIcon
                        className="h-5 w-5 flex-shrink-0 text-neutral-100"
                        aria-hidden="true"
                      />
                    </IconButton>
                  )}

                  <span className={"text-sm text-neutral-500 ml-4 mr-4"}>
                    {product.quantity}
                  </span>

                  <IconButton
                    aria-label="increase"
                    className="-m-2 ml-2 inline-flex p-2 text-neutral-400 hover:text-neutral-500 h-5 w-5"
                    onClick={() =>
                      handleIncreaseDecreaseQuantityClick("increase")
                    }
                  >
                    {updateLineItem === "increase" && (
                      <IncreaseDecreaseQuantity
                        lineItem={{
                          id: product.id,
                          referencedId: product.referencedId,
                          quantity: product.quantity + 1,
                        }}
                        setUpdateLineItem={setUpdateLineItem}
                      />
                    )}
                    {updateLineItem === "none" && (
                      <PlusCircleIcon
                        className="h-5 w-5 flex-shrink-0 text-neutral-300"
                        aria-hidden="true"
                      />
                    )}
                  </IconButton>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </li>
  );
}

import Link from "next/link";
import LogoIcon from "@/components/icons/logo";

export default function Header() {
  return (
    <header className="bg-base-50">
      <div className="max-w-7xl mx-auto py-6 px-6 md:px-12 xl:px-0 flex justify-center items-center">
        <Link href="/" title="Tout Terrain">
          <span className="sr-only">Tout Terrain</span>
          <LogoIcon mode="light" />
        </Link>
      </div>
    </header>
  );
}

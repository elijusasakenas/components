
import React from "react";
import Image from "next/image";
import Link from "next/link";
import ItemsCarousel from "react-items-carousel";
import ProductBox from "@/components/product/box";
import { setListing } from "@/redux/category/listing";
import { useDispatch } from "react-redux";
import { setPropertiesFilter } from "@/redux/category/filters";
import ProductList from "../listing/ProductList";

    

export default function CreateBlock(category, block, b) {
    let result = null;
    const dispatch = useDispatch();
    const categoryId = category.id;

    if (block.type === "text") {
        result = TextBlock(block, "text" + b);
    }
    if (block.type === "image-cover") {
        result = ImageCoverBlock(block, "image-cover" + b);
    }
    if (block.type === "text-two-column") {
        result = TextTwoColumnBlock(block, "text-two-column" + b);
    }
    if (block.type === "image-slider") {
        result = ImageSliderBlock(block, "image-slider" + b);
    }
    if (block.type === "image-text") {
        result = ImageTextBlock(block, "image-text" + b);
    }
    if (block.type === "category-navigation") {
        result = CategoryNavigationBlock(block, "default" + b);
    }
    if (block.type === "cogi-layout-06") {
        result = cogiLayout06(block, "cogi-layout-06" + b);
    }
    
    if (block.type === "product-listing") { 
        
        if (category.listing) {
            dispatch(setListing(category.listing.elements));
            dispatch(
              setPropertiesFilter(category.listing.aggregations.properties.entities)
            );
          }
      
          let showSorting = null;
          let filters = null;
      
          block.slots.map((slot) => {
            showSorting = slot.config.showSorting?.value;
            filters = slot.config.filters?.value;
          });
      
          result = (
            <ProductList
              key={category.id}
              category={category}
              availableSortings={category.listing.availableSortings}
              showSorting={showSorting}
              filters={filters}
            />
          );
    }

    return result;
};

const toBase64 = (str) =>
    typeof window === "undefined"
        ? Buffer.from(str).toString("base64")
        : window.btoa(str);

const shimmer = (w, h) => `
<svg width="${w}" height="${h}" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
  <defs>
    <linearGradient id="g">
      <stop stop-color="#EFF0F2" offset="20%" />
      <stop stop-color="#DFE1E5" offset="50%" />
      <stop stop-color="#EFF0F2" offset="70%" />
    </linearGradient>
  </defs>
  <rect width="${w}" height="${h}" fill="#EFF0F2" />
  <rect id="r" width="${w}" height="${h}" fill="url(#g)" />
  <animate xlink:href="#r" attributeName="x" from="-${w}" to="${w}" dur="1s" repeatCount="indefinite"  />
</svg>`;


const TextBlock = (block, b) => {
    return (
        <div key={b} className={`cms-block ${block.cssClass ? block.cssClass : ''}`}>
            {block.slots.map((slot, index) => (
                <TextSlot slot={slot} key={index} />
            ))}
        </div>
    );
};

const TextSlot = (slot, key) => {
    return (
        <div
            key={key}
            className="cms-slot mb-6 md:mb-0"
            dangerouslySetInnerHTML={{
                __html: slot.slot.translated.config.content?.value,
            }}
        ></div>
    );
};

const ImageCoverBlock = (block, b) => {
    return (
        <div key={b} className={`cms-block ${block.cssClass ? block.cssClass : ''}`}>
            {block.slots.map((slot, index) => (
                <ImageCoverSlot slot={slot} key={index} />
            ))}
        </div>
    );
};

const ImageCoverSlot = ({ slot }) => {
    return (
        <div key={slot.id} className="cms-slot mb-12">
            <Image
                src={slot.data.media.url || ""}
                alt={slot.data.media.alt || ""}
                title={slot.data.media.title || ""}
                width={slot.data.media.metaData.width}
                height={slot.data.media.metaData.height}
                className="w-full"
                placeholder={`data:image/svg+xml;base64,${toBase64(shimmer(700, 475))}`}
            />
        </div>
    );
};

const TextTwoColumnBlock = (block, b) => {
    return (
        <div
            key={b}
            className={
                `cms-block md:grid md:grid-flow-row md:grid-cols-3 gap-12 ${block.cssClass ? block.cssClass : ''} `
            }
        >
            {block.slots.map((slot, index) => (
                <TextTwoColumnSlot slot={slot} key={index} />
            ))}
        </div>
    );
};

const TextTwoColumnSlot = ({ slot }) => {
    return (
        <div
            className={`cms-slot ${slot.slot === "left" ? "col-span-2" : "col-span-1"
                }`}
            dangerouslySetInnerHTML={{ __html: slot.translated.config.content.value }}
        ></div>
    );
};

const ImageSliderBlock = (block, b) => {
    return (
        <div key={b} className={`cms-block ${block.cssClass ? block.cssClass : ''}`}>
            {block.slots.map((slot, index) => (
                <ImageSliderSlot slot={slot} key={index} />
            ))}
        </div>
    );
};

const ImageSliderSlot = ({ slot }) => {
    const [activeItemIndex, setActiveItemIndex] = useState(0);

    const sliderItems = slot.data.sliderItems;

    return (
        sliderItems && sliderItems.length > 0 &&
        <div className="mb-12">
            <ItemsCarousel
                requestToChangeActive={setActiveItemIndex}
                activeItemIndex={activeItemIndex}
                numberOfCards={1}
                leftChevron={<button className="button-secondary">{'<'}</button>}
                rightChevron={<button className="button-secondary">{'>'}</button>}
                infiniteLoop
            >
                {sliderItems.map((item, index) => (
                    <div key={index}>
                        {item.url ? (
                            <Link href={item.url} target={item.newTab ? '_blank' : '_self'} className="w-full border-0">
                                <Image
                                    src={item.media.url}
                                    className="w-full"
                                    width={item.media.metaData?.width ? item.media.metaData.width : 1145}
                                    height={item.media.metaData?.height ? item.media.metaData.height : 455}
                                    alt={item.media.alt ? item.media.alt : ""}
                                    placeholder={`data:image/svg+xml;base64,${toBase64(shimmer(700, 475))}`}
                                />
                            </Link>
                        ) : (
                            <Image
                                src={item.media.url}
                                className="w-full"
                                width={item.media.metaData?.width ? item.media.metaData.width : 1145}
                                height={item.media.metaData?.height ? item.media.metaData.height : 455}
                                alt={item.media.alt ? item.media.alt : ""}
                                title={item.media.title}
                                placeholder={`data:image/svg+xml;base64,${toBase64(shimmer(700, 475))}`}
                            />
                        )}
                    </div>
                ))}
            </ItemsCarousel>

        </div>
    )
};

const ImageTextBlock = (block, b) => {
    return (
        <div
            key={b}
            className={
                `cms-block md:grid md:grid-flow-row md:grid-cols-3 gap-12 mb-10 ${block.cssClass ? block.cssClass : ''}`
            }
        >
            {block.slots.map((slot, index) => (
                <ImageTextSlot slot={slot} key={index} />
            ))}
        </div>
    );
};

const ImageTextSlot = ({ slot }) => {
    if (slot.data?.media) {
        return (
            <div key={slot.id} className="cms-slot group">
                <Image
                    src={slot.data.media.url}
                    alt={slot.data.media?.alt ? slot.data.media?.alt : ""}
                    title={slot.data.media.title}
                    width={
                        slot.data.media.metaData ? slot.data.media.metaData.width : "160"
                    }
                    height={
                        slot.data.media.metaData ? slot.data.media.metaData.height : "160"
                    }
                    className="w-96 h-auto mx-auto group-hover:scale-105 transition-transform duration-300 ease-in-out"
                    placeholder={`data:image/svg+xml;base64,${toBase64(
                        shimmer(700, 475)
                    )}`}
                />
            </div>
        );
    }
    if (slot.translated.config.content) {
        return (
            <div
                key={slot.id}
                className="cms-slot col-span-2"
                dangerouslySetInnerHTML={{
                    __html: slot.data?.content,
                }}
            ></div>
        );
    }
};

const CategoryNavigationBlock = (block, b) => {
    return (
        <div key={b} className={`cms-block ${block.cssClass ? block.cssClass : ''}`}>
            <div className="w-full bg-yellow-50 px-8 py-8 h2">
                CategoryNavigation (coming soon...)
            </div>
        </div>
    );
};

const cogiLayout06 = (block, b) => {
    return (
        <div key={b} className={`cms-block grid grid-flow-row md:grid-cols-2 xl:grid-cols-4 gap-6 ${block.cssClass ? block.cssClass : ''}`}>
            {block.slots.map((slot, index) => (
                <CogiLayout06Slots slot={slot} key={index} />
            ))}
        </div>
    );
}

const CogiLayout06Slots = ({ slot }) => {
    if (slot.type === 'cogi-text-on-image' && slot.data.image) {
        return <CogiTextOnImage slot={slot} />
    }

    if (slot.type === 'text') {
        return <TextSlot slot={slot} />
    }

    if (slot.type === 'product-box') {
        return <ProductBox product={slot.data.product} />
    }
};

const CogiTextOnImage = ({ slot }) => {
    const imageLink = slot.fieldConfig.find((field) => field.name === 'url').value;

    return (
        <div key={slot.id} className={`cms-slot ${slot.cssClass ? slot.cssClass : ''}`}>
            {imageLink ? (
                <Link href={imageLink} className="border-0 w-full">
                    <Image
                        src={slot.data.image.media.url || ""}
                        alt={slot.data.image.media.alt || ""}
                        width={slot.data.image.media.metaData.width}
                        height={slot.data.image.media.metaData.height}
                        className="w-full"
                        placeholder={`data:image/svg+xml;base64,${toBase64(shimmer(700, 475))}`}
                    />
                </Link>
            ) : (
                <Image
                    src={slot.data.image.media.url || ""}
                    alt={slot.data.image.media.alt || ""}
                    width={slot.data.image.media.metaData.width}
                    height={slot.data.image.media.metaData.height}
                    className="w-full"
                    placeholder={`data:image/svg+xml;base64,${toBase64(shimmer(700, 475))}`}
                />
            )}
        </div>
    );
};
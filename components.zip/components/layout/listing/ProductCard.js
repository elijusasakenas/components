import { NumericFormat } from "react-number-format";
import Link from "next/link";
import ProductBoxImage from "@/components/product/product_box_image";
import { motion } from "framer-motion";

export default function ProductCard({ product, image, title, price, index }) {
  return (
    <>
      <motion.div
        initial={{ opacity: 0, transform: "translateY(-24px)" }}
        whileInView={{ opacity: 1, transform: "translateY(0px)" }}
        viewport={{ once: true }}
        

        className="flex flex-col items-center self-stretch bg-white rounded-lg"
      >
        <div
          className={
            "group flex flex-col justify-between gap-8 p-6 md:py-14 md:px-6 self-stretch flex-1"
          }
          key={product.id}
          title={product.translated.name}
        >
          <div className="flex flex-col gap-8">
            <div className="flex w-full justify-center items-center relative self-stretch">
              <Link
                href={`/${product.seoUrls[0].seoPathInfo}`}
                className="w-full"
              >
                <ProductBoxImage product={image} />
              </Link>
            </div>
            <div className="flex px-2 flex-col justify-center items-start gap-8">
              <div>
                <Link
                  href={`/${product.seoUrls[0].seoPathInfo}`}
                  className="headline-small leading-7 hover:text-orange-200 transition-colors"
                >
                  {title}
                </Link>
              </div>
              {(product.customFields["custom_product_shopware_bullet-1"] ||
                product.customFields["custom_product_shopware_bullet-2"] ||
                product.customFields["custom_product_shopware_bullet-3"] ||
                product.customFields["custom_product_shopware_bullet-4"]) && (
                <div className="flex flex-col justify-center items-start gap-4 leading-9 self-stretch body-small">
                  {product.customFields["custom_product_shopware_bullet-1"] && (
                    <div className="border-b-[1px] border-base-400 pb-4">
                      {product.customFields["custom_product_shopware_bullet-1"]}
                    </div>
                  )}

                  {product.customFields["custom_product_shopware_bullet-2"] && (
                    <div className="border-b-[1px] border-base-400 pb-4">
                      {product.customFields["custom_product_shopware_bullet-2"]}
                    </div>
                  )}

                  {product.customFields["custom_product_shopware_bullet-3"] && (
                    <div className="border-b-[1px] border-base-400 pb-4">
                      {product.customFields["custom_product_shopware_bullet-3"]}
                    </div>
                  )}

                  {product.customFields["custom_product_shopware_bullet-4"] && (
                    <div className="border-b-[1px] border-base-400 pb-4">
                      {product.customFields["custom_product_shopware_bullet-4"]}
                    </div>
                  )}
                </div>
              )}
              <div>
                
                <div className="body-emphasis">
                  <NumericFormat
                    value={price}
                    decimalSeparator=","
                    decimalScale="2"
                    fixedDecimalScale="true"
                    displayType={"text"}
                    thousandSeparator="."
                    suffix={" €*"}
                  />
                </div>
                <div className="body-emphasis">
                  {product.calculatedPrice.referencePrice
                    ? "Inhalt: " +
                      product.calculatedPrice.referencePrice.purchaseUnit +
                      " " +
                      product.calculatedPrice.referencePrice.unitName
                    : null}
                  {product.calculatedPrice.referencePrice ? (
                    <NumericFormat
                      value={product.calculatedPrice.referencePrice.price}
                      decimalSeparator=","
                      decimalScale="2"
                      fixedDecimalScale="true"
                      displayType={"text"}
                      thousandSeparator="."
                      prefix={" ("}
                      suffix={
                        " €* / " +
                        product.calculatedPrice.referencePrice.referenceUnit +
                        " " +
                        product.calculatedPrice.referencePrice.unitName +
                        ")"
                      }
                    />
                  ) : null}
                </div>
              </div>
            </div>
          </div>
          <div>
            <Link
              className="btn-primary w-full md:w-auto"
              href={`/${product.seoUrls[0].seoPathInfo}`}
            >
              Wählen
            </Link>
          </div>
        </div>
      </motion.div>
    </>
  );
}

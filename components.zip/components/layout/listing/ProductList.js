"use client";

import { useEffect, useState, useMemo } from "react";
import * as gtag from "@/utility/gtag";
import { useSelector } from "react-redux";
import ProductCard from "./ProductCard";
import FilterBar from "./FilterBar";

/**
 * ProductGrid is a React component that displays a grid of products.
 * It uses the Redux state to get the list of products and the manufacturer filter.
 * It also dispatches actions to update the manufacturer filter in the Redux store.
 *
 * @param {Object} categoryId - The ID of the category to display products for.
 * @param {Array} filters - The filters to be applied on the product listing.
 * @returns {JSX.Element} The rendered product grid.
 */
const ProductList = ({ category, availableSortings, showSorting, filters}) => {
  // State to track if the event has been fired.
  const [eventIsFired, setEventFired] = useState(false);
  const product = useSelector((state) => state.listing.listing);

  const categoryId = category.id;

  const categoryItems = useMemo(() => {
    return product.map((item) => ({
      item_id: item.productNumber,
      item_name: item.translated.name,
      item_brand: process.env.NEXT_PUBLIC_BRAND_NAME,
      price: item.calculatedPrice.unitPrice,
      quantity: 1
    }));
  }, [product]);


  useEffect(() => {
    if (eventIsFired === false) {
      const dataLayer = {
        event: "view_item_list",
        ecommerce: {
          item_list_id: categoryId,
          item_list_name: category.translated.name,
          items: categoryItems
        }
      };

      gtag.dataLayer(dataLayer);
      setEventFired(true);
    }
  }, [eventIsFired, categoryId, categoryItems, category.translated.name]);

  const slotConfig = category.translated.slotConfig;
  let propertyWhitelistValue = null;

  for (const key in slotConfig) {
    if (slotConfig[key].propertyWhitelist) {
      propertyWhitelistValue = slotConfig[key].propertyWhitelist.value;
      break;
    }
  }

  return (
    <div className={"listing pt-4"} key={categoryId} >
      {filters ? <FilterBar categoryId={categoryId} data={filters} propertyWhitelistValue={propertyWhitelistValue} /> : null}
      <div className="grid grid-flow-row lg:grid-cols-2 xl:grid-cols-3 gap-6 px-6 md:px-12 xl:px-0 py-6 md:pb-14 xl:pb-24">
        {product.map((product,index) =>
          product.seoUrls ? (
            <ProductCard
              product={product}
              key={product.id}
              title={product.translated.name}
              image={product}
              price={product.calculatedPrice.unitPrice}
              index={index}
            />
          ) : null
        )}
      </div>
    </div>
  );
};

export default ProductList;

import { useState } from "react";
import OffcanvasFilter from "./Filter";

export default function FilterBar({
  categoryId,
  data,
  propertyWhitelistValue,
}) {
  const [checkFilters, setCheckFilters] = useState({
    priceFilter: false,
    propertiesFilter: false,
    ratingFilter: false,
    shippingFilter: false,
    manufacturerFilter: false,
  });
  const [selectedProperties, setSelectedProperties] = useState([]);
  const [filterOpen, setFilterOpen] = useState(false);
  const checkboxSelectedCount = selectedProperties.filter(
    (property) => property.isCheckboxSelected
  ).length;

  return (
    <div>
      <div
        className={
          "flex flex-col pt-6 xl:pt-10 px-6 md:px-12 xl:px-0 justify-between gap-0"
        }
      >
        <div className={"flex flex-row justify-between gap-8 w-full"}>
          <button
            className={`btn-secondary w-full md:w-auto`}
            onClick={() => setFilterOpen(true)}
          >
            Filter{" "}
            {checkboxSelectedCount > 0 ? `(${checkboxSelectedCount})` : ""}
          </button>
        </div>
        <div className="flex justify-end">
          <OffcanvasFilter
            filterOpen={filterOpen}
            setFilterOpen={setFilterOpen}
            data={data}
            checkFilters={checkFilters}
            setCheckFilters={setCheckFilters}
            categoryId={categoryId}
            selectedProperties={selectedProperties}
            setSelectedProperties={setSelectedProperties}
            propertyWhitelistValue={propertyWhitelistValue}
          />
        </div>
      </div>
    </div>
  );
}

"use client";

import PropertyFilter from "@/components/listing/filters/property-filter";
import {
  Dialog,
  DialogBackdrop,
  DialogPanel,
  Transition,
  TransitionChild
} from "@headlessui/react";
import { XMarkIcon } from "@heroicons/react/24/outline";
import { Fragment } from "react";
import { useSelector } from "react-redux";

export default function OffcanvasFilter({
  filterOpen,
  setFilterOpen,
  data,
  checkFilters,
  setCheckFilters,
  categoryId,
  selectedProperties,
  setSelectedProperties,
  setFilteredPropertiesLength,
  propertyWhitelistValue,
}) {
  const resetFilters = () => {
    setCheckFilters({
      priceFilter: false,
      propertiesFilter: false,
      ratingFilter: false,
      shippingFilter: false,
      manufacturerFilter: false,
    });
  };

  const products = useSelector((state) => state.listing.listing);
  const snippets = useSelector((state) => state.snippets.snippets);
  
  return (
    <Transition show={filterOpen} as={Fragment}>
      <Dialog as="div" className="relative z-30" onClose={setFilterOpen}>
        <DialogBackdrop className="fixed inset-0 bg-black bg-opacity-50" />
        <div className="fixed inset-0 overflow-hidden">
          <div className="absolute inset-0 overflow-hidden">
            <div
              className={
                "pointer-events-none fixed inset-y-0 right-0 flex max-w-full "
              }
            >
              <TransitionChild
                as={Fragment}
                enter="transform transition ease-in-out duration-500 sm:duration-700"
                enterFrom="translate-x-full"
                enterTo="translate-x-0"
                leave="transform transition ease-in-out duration-500 sm:duration-700"
                leaveFrom="translate-x-0"
                leaveTo="translate-x-full"
              >
                <DialogPanel className="pointer-events-auto w-screen max-w-96">
                  <div className="flex h-full flex-col bg-base-400 pt-6 shadow-xl border-t-8 border-orange-200 overflow-y-auto">
                    <div className="flex justify-end px-6">
                      <button
                        aria-label="increase"
                        className="inline-flex p-2 text-white bg-base-200 rounded-full"
                        onClick={() => setFilterOpen(false)}
                      >
                        <XMarkIcon className="h-6 w-6 " aria-hidden="true" />
                      </button>
                    </div>
                    <div className="flex flex-col p-6 items-start gap-2">
                      <PropertyFilter
                        key={"property-filter"}
                        categoryId={categoryId}
                        offCanvas={true}
                        selectedProperties={selectedProperties}
                        setSelectedProperties={setSelectedProperties}
                        propertyWhitelistValue={propertyWhitelistValue}
                        setFilteredPropertiesLength={
                          setFilteredPropertiesLength
                        }
                      />
                    </div>
                    <div className="flex pb-10 px-6 pt-6 flex-col items-start gap-4 w-full">
                      <div className="flex pt-[11px] pb-[9px] justify-center items-center gap-2 w-full">
                        <button
                          className=" w-full text-base-50 uppercase text-sm md:text-[18px] font-bold leading-5 tracking-[0.9px]"
                          onClick={resetFilters}
                        >
                          {selectedProperties.length > 0
                            ? ` Alle Filter entfernen (${selectedProperties.length})`
                            : ""}
                        </button>
                      </div>
                    </div>
                  </div>
                </DialogPanel>
              </TransitionChild>
            </div>
          </div>
        </div>
      </Dialog>
    </Transition>
  );
}

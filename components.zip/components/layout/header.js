import CartIcon from "@/components/icons/cart";
import Logo from "@/components/layout/header/Logo";
import MobileNavigation from "@/components/layout/header/MobileNavigation";
import { MainNavigation } from "@/components/layout/header/Navigation";
import SearchBar from "@/components/layout/header/Search";
import { LanguageSelector } from "@/components/layout/header/lang/LanguageSelector";
import Promo from "@/components/layout/header/promo";
import { setOpen } from "@/redux/cart/cart";
import useScreenSize from "@/utility/useScreenSize";
import { useMotionValueEvent, useScroll } from "framer-motion";
import Link from "next/link";
import { useEffect, useRef, useState } from "react";
import { useDispatch, useSelector } from "react-redux";

export default function Header({ languages, foreignKey, snippets }) {
  const [searchOpen, setSearchOpen] = useState(false);
  const [showPromo, setShowPromo] = useState(true);
  const cartOpen = useSelector((state) => state.cart.open);
  const swCart = useSelector((state) => state.cart.swCart);
  const logoEnabled = useSelector((state) => state.logo.logoEnabled);
  const dispatch = useDispatch();
  const { scrollY } = useScroll();
  const lastYRef = useRef(0);
  const screenSize = useScreenSize();

  useEffect(() => {
    window.addEventListener("click", function (e) {
      if (e.target.dataset.todo !== "openSearch") {
        setSearchOpen(false);
      }
    });

    if (screenSize.width > 0 && screenSize.width < 1024 && !logoEnabled) {
      //setIsHidden(true);
    }
  }, [screenSize, logoEnabled]);

  useMotionValueEvent(scrollY, "change", (y) => {
    if (screenSize.width > 0 && screenSize.width >= 1024) {
      const difference = y - lastYRef.current;
      if (Math.abs(difference) > 50) {
        //setIsHidden(difference > 0);
        //setShowPromo(!isHidden);

        lastYRef.current = y;
      }
    }
  });

  return (
    <>
      <Promo open={showPromo} />
      <header className={`w-full bg-base-500 lg:bg-base-50`}>
        <div
          className={`px-12 xl:px-0 relative w-full flex justify-center items-center max-w-7xl mx-auto lg:justify-between z-30 ${
            !logoEnabled ? "hidden lg:flex" : "flex"
          } ${logoEnabled ? "pt-6" : "lg:pt-6"}`}
        >
          <div className="flex items-center lg:ml-4 overflow-hidden">
            {/* Logo */}
            <Link href="/">
              <span className="sr-only">
                {process.env.NEXT_PUBLIC_BRAND_NAME}
              </span>
              <Logo />
            </Link>
          </div>

          <div className="flex items-center gap-6 max-lg:hidden overflow-visible relative">
            {/* B2B SHOP */}
            <Link
              className="btn-primary btn-small !px-3 !py-2 !text-sm !leading-4"
              target="_blank"
              href={snippets.next.header.b2b.link}
            >
              {snippets.next.header.b2b.text}
            </Link>

            <div className="flex items-center justify-start">
              {/* langSwitcher */}
              <div className="hidden lg:block">
                <div className="flow-root">
                  <LanguageSelector
                    languages={languages}
                    foreignKey={foreignKey}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>

      <nav
        className={`w-full bg-base-500 overflow-visible lg:bg-base-50 lg:block lg:sticky lg:top-0 z-20 ${
          logoEnabled ? "pt-4 pb-4" : "lg:pt-4 lg:pb-4"
        }`}
      >
        <div
          className={`px-12 xl:px-0 hidden lg:block w-full mx-auto max-w-7xl relative`}
        >
          <div className="flex items-center justify-between">
            <div className="flex align-middle justify-between">
              <div className={`relative`}>
                <MainNavigation />
              </div>
            </div>

            <div className="xl:min-w-80 flex items-center justify-end xl:gap-x-6">
              <SearchBar open={searchOpen} setOpen={setSearchOpen} snippets={snippets} />

              <div className="flow-root pl-6 pr-2 border-l-2 border-base-200">
                <Link
                  href="#"
                  className="group relative"
                  onClick={(e) => {
                    e.preventDefault();
                    dispatch(setOpen(!cartOpen));
                  }}
                  scroll={false}
                >
                  <CartIcon className="mr-1 fill-base-500 hover:fill-orange-200 h-8 w-8" />
                  {swCart && swCart.lineItems?.length > 0 && (
                    <div className="flex items-center justify-center text-sm leading-6 font-medium text-base-500 bg-orange rounded-full min-w-6 h-6 absolute -top-3 -right-1">
                      {swCart ? swCart.lineItems.length : 0}
                    </div>
                  )}
                </Link>
              </div>
            </div>
          </div>
        </div>
      </nav>

      {/*
      <MobileSearchBar
        open={openMobileSearchBar}
        setOpen={setOpenMobileSearchBar}
      />
    */}

      <MobileNavigation swCart={swCart} languages={languages} foreignKey={foreignKey} />
    </>
  );
}

import dynamic from 'next/dynamic';

const ProductGrid = dynamic(() => import("@/components/listing/grid"), {
  ssr: false,
});

const Layout = dynamic(() => import("@/components/layout/templates/default"), {
  ssr: false,
});

export default function Content({ type }) {
  return (
    type === "category" ? <Category /> : null
  );
}

const Category = ({ category }) => {
  return (
    category && (
      <Layout metaData={category}>
        <div className="content mt-8 mb-2">
          <div className="mx-auto max-w-7xl pt-0 md:pt-8 px-4 sm:px-6 lg:px-8 xl:px-0">
            <h1>{category.translated ? category.translated.name : null}</h1>
            {category.translated.description && (
              <p className="mt-4 max-w-xl text-sm text-neutral-700">
                {/* strip html from description */}
                {category.translated.description
                  ? category.translated.description.replace(/(<([^>]+)>)/gi, "")
                  : null}
              </p>
            )}
          </div>

          {/* Product grid */}
          <section
            aria-labelledby="products-heading"
            className="mx-auto max-w-7xl px-4 pt-12 pb-16 sm:px-6 sm:pt-16 lg:px-8 xl:px-0"
          >
            <ProductGrid
              categoryId={category.id}
              categoryName={category.translated.name}
            />
          </section>
        </div>
      </Layout>
    )
  );
}


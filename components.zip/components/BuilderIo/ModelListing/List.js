import ListItem from "@/components/BuilderIo/ModelListing/ListItem";
import { motion } from "framer-motion";
import "swiper/css";
import "swiper/css/navigation";
import { Navigation } from "swiper/modules";
import { Swiper, SwiperSlide } from "swiper/react";
import "./styles.scss";

const List = ({ items }) => {
  return (
    items &&
    items.length > 0 && (
      <div className="mb-14 lg:mb-24 pl-6 md:pl-12 xl:pl-0">
        <Swiper
          slidesPerView={"auto"}
          navigation={true}
          modules={[Navigation]}
          className="model-listing-slider"
        >
          {items.map((item, index) => (
            <SwiperSlide key={index}>
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.7, delay: 0.2 }}
                className="h-full"
              >
                <ListItem
                  title={item.title}
                  image={item.image}
                  price={item.price}
                  features={item.features?.value?.data?.list}
                  linkText={item.linkText}
                  linkUrl={item.linkUrl}
                  linkText2={item.linkText2}
                  linkUrl2={item.linkUrl2}
                />
              </motion.div>
            </SwiperSlide>
          ))}
        </Swiper>
      </div>
    )
  );
};

export default List;

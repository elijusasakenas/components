import Title from "@/components/BuilderIo/ModelListing/Title";
import ListItem from "@/components/BuilderIo/ModelListing/WithImage/ListItem";

const WithImage = ({ title, family }) => {
  const items = family?.value?.data?.models;

  return (
    <div className="max-w-8xl mx-auto w-full relative">
      <Title content={title} />

      {items &&
        items.map((item, index) => (
          <ListItem
            key={index}
            title={item.title}
            type={item.type}
            image={item.image}
            features={item.features?.value?.data?.list}
            linkText={item.linkText}
            linkUrl={item.linkUrl}
            sideImage={item.sideImage}
            sideImagePosition={item.sideImagePosition}
          />
        ))}
    </div>
  );
};

export default WithImage;

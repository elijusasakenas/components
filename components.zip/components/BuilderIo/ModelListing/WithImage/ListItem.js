import Link from "next/link";
import { motion } from "framer-motion";
import BuilderImage from "@/components/BuilderImage";

const ListItem = ({
  image,
  title,
  type,
  features,
  linkText,
  linkUrl,
  sideImage,
  sideImagePosition,
}) => {
  return (
    <div className="lg:grid grid-cols-2 justify-center items-start lg:mb-20 lg:px-12 xl:px-24">
      {sideImage && sideImagePosition === "left" && (
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{
            duration: 0.7,
          }}
          className="hidden lg:block sticky top-40"
        >
          <BuilderImage
            src={sideImage}
            width={620}
            height={970}
            alt="Feature Bg Image"
            className="w-full lg:h-[528px] xl:h-[850px] object-cover"
          />
        </motion.div>
      )}

      <motion.div
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{
          duration: 0.7,
          delay: sideImagePosition === "left" ? 0.25 : 0,
        }}
        className={`overflow-hidden px-6 md:px-14 xl:px-16 py-12 md:py-14`}
      >
        {image && (
          <div>
            <BuilderImage
              src={image}
              width={816}
              height={462}
              alt="Feature Bg Image"
              className="w-full object-cover max-w-[342px] md:max-w-[744px] lg:max-w-[500px]"
            />
          </div>
        )}

        <div className="px-2 mt-10 md:mt-16 z-10 flex flex-col gap-2">
          <div className="headline-large">{title}</div>
          {type && <div className="headline-small mt-2">{type}</div>}
        </div>

        {features && (
          <div className="px-2 mt-6 flex flex-col gap-6 body-small">
            {features.map((feature, index) => (
              <div dangerouslySetInnerHTML={{ __html: feature.label }} key={index} />
            ))}
          </div>
        )}

        {linkText && linkUrl && (
          <div className="px-2 mt-6">
            <Link href={linkUrl} className="btn-primary w-full md:w-auto">
              {linkText}
            </Link>
          </div>
        )}
      </motion.div>

      {sideImage && sideImagePosition === "right" && (
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{
            duration: 0.7,
            delay: 0.25,
          }}
          className="hidden lg:block sticky top-40"
        >
          <BuilderImage
            src={sideImage}
            width={620}
            height={970}
            alt="Feature Bg Image"
            className="w-full lg:h-[528px] xl:h-[850px] object-cover"
          />
        </motion.div>
      )}
    </div>
  );
};

export default ListItem;

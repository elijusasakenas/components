import { Builder } from "@builder.io/react";
import WithImage from "@/components/BuilderIo/ModelListing/WithImage/WithImage";

Builder.registerComponent(WithImage, {
  name: "ModelListingWithImage",
  friendlyName: "ModelListing - Family with image",
  screenshot:
    "https://cdn.builder.io/api/v1/image/assets%2F90182f3615654f8c9be2b012f26cc6c0%2F0156d56cc6834c2786ef9e9148b3edc0",
  
  inputs: [
    {
      name: "title",
      friendlyName: "Title",
      type: "string",
      defaultValue: "Headline",
    },
    {
      name: "family",
      friendlyName: "Families",
      type: "reference",
      model: "families",
      options: {
        enrich: true,
      },
    },
  ],
});

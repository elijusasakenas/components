import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import ListItem from './ListItem';
import '@testing-library/jest-dom';

describe('ListItem Component', () => {
  const defaultProps = {
    title: 'Test Product',
    image: 'https://placehold.co/300x525/131313/FFF@2x.png',
    price: 1234.56,
    features: [{ value: 'Feature 1' }, { value: 'Feature 2' }],
    linkText: 'Primary Link',
    linkUrl: '/primary-link',
    linkText2: 'Secondary Link',
    linkUrl2: '/secondary-link',
  };

  it('renders the title', () => {
    render(<ListItem {...defaultProps} />);
    expect(screen.getByText('Test Product')).toBeInTheDocument();
  });

  it('renders the image', () => {
    render(<ListItem {...defaultProps} />);
    const image = screen.getByAltText('Feature Bg Image');
    expect(image).toBeInTheDocument();
    expect(image).toHaveAttribute('src', expect.stringContaining('https://placehold.co/300x525/131313/FFF@2x.png'));
  });

  it('renders the price', () => {
    render(<ListItem {...defaultProps} />);
    expect(screen.getByText('Preis ab 1.234,56 €')).toBeInTheDocument();
  });

  it('renders the features', () => {
    render(<ListItem {...defaultProps} />);
    expect(screen.getByText('Feature 1')).toBeInTheDocument();
    expect(screen.getByText('Feature 2')).toBeInTheDocument();
  });

  it('renders the primary link', () => {
    render(<ListItem {...defaultProps} />);
    const primaryLink = screen.getByText('Primary Link');
    expect(primaryLink).toBeInTheDocument();
    expect(primaryLink.closest('a')).toHaveAttribute('href', '/primary-link');
  });

  it('renders the secondary link and opens modal on click', () => {
    render(<ListItem {...defaultProps} />);
    const secondaryLink = screen.getByText('Secondary Link');
    expect(secondaryLink).toBeInTheDocument();
    expect(secondaryLink.closest('a')).toHaveAttribute('href', '/secondary-link');

    fireEvent.click(secondaryLink);
    expect(screen.getByRole('dialog')).toBeInTheDocument();
  });
});
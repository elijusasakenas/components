import Title from "@/components/BuilderIo/ModelListing/Title";
import List from "@/components/BuilderIo/ModelListing/List";

const ModelListing = ({ title, linkToAll, linkToAllUrl, family, model }) => {
  const items = family?.value?.data?.models;
  const models = model?.value?.data?.models;

  return (
    <div className="max-w-7xl mx-auto w-full relative">
      <Title content={title} link={linkToAll} linkToAllUrl={linkToAllUrl} />
      {items && <List items={items} />}
      {models && <List items={models} />}
    </div>
  );
};

export default ModelListing;

import { Builder } from "@builder.io/react";
import ModelListing from "@/components/BuilderIo/ModelListing/ModelListing";

Builder.registerComponent(ModelListing, {
  name: "ModelListing",
  friendlyName: "Model Listing",
  description: "Listing | Models - Category / Family",
  docsLink: "https://www.builder.io/c/docs/developers",
  screenshot:
    "https://cdn.builder.io/api/v1/image/assets%2F90182f3615654f8c9be2b012f26cc6c0%2F4c58f64de6324a229c7046161d1b0a99",
  
  inputs: [
    {
      name: "title",
      friendlyName: "Title",
      type: "string",
      defaultValue: "Headline",
    },
    {
      name: "linkToAll",
      friendlyName: "Link Text",
      type: "string",
      defaultValue: "Alle Modelle entdecken",
    },
    {
      name: "linkToAllUrl",
      friendlyName: "Link URL",
      type: "string",
    },
    {
      name: "family",
      friendlyName: "Families",
      type: "reference",
      model: "families",
      options: {
        enrich: true,
      },
    },
    {
      name: "model",
      friendlyName: "Models",
      type: "reference",
      model: "modelle",
      options: {
        enrich: true,
      },
    },
  ],
});

import { motion } from "framer-motion";
import Link from "next/link";

const Title = ({ content, link, linkToAllUrl }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.7 }}
      className="px-6 md:px-12 pt-14 xl:pt-24 pb-8 md:pb-16 flex flex-col gap-2 xl:text-center xl:max-w-[800px] xl:mx-auto"
    >
      <div className="headline-large">{content}</div>
      {(link && linkToAllUrl) && <Link href={linkToAllUrl} className="font-bold uppercase text-[18px] hover:text-orange-200">{link}</Link>}
    </motion.div>
  );
};

export default Title;

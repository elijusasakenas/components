import { NumericFormat } from "react-number-format";
import Link from "next/link";
import Modal from "@/components/BuilderIo/ModelListing/Modal";
import { useState } from "react";
import BuilderImage from "@/components/BuilderImage";

/**
 * ListItem component displays a product item with an image, title, price, colors, features, and links.
 *
 * @param {Object} props - The properties for the ListItem component.
 * @param {string} props.title - The title of the product.
 * @param {string} props.image - The URL of the product image.
 * @param {number} props.price - The price of the product.
 * @param {Array<Object>} props.features - An array of feature objects, each containing a value.
 * @param {string} props.linkText - The text for the primary link.
 * @param {string} props.linkUrl - The URL for the primary link.
 * @param {string} [props.linkText2] - The text for the secondary link (optional).
 * @param {string} [props.linkUrl2] - The URL for the secondary link (optional).
 *
 * @returns {JSX.Element} The rendered ListItem component.
 */
const ListItem = ({
  title,
  image,
  price,
  features,
  linkText,
  linkUrl,
  linkText2,
  linkUrl2,
}) => {
  const [modalOpen, setModalOpen] = useState(false);

  return (
    <>
      <div
        className={`relative overflow-hidden h-full flex flex-col items-start justify-between pb-14`}
      >
        <div>
          <BuilderImage
            src={image}
            width={250}
            height={142}
            alt="Feature Bg Image"
            className="w-full object-cover"
          />

          <div className="px-4 mt-8 z-10 flex flex-col gap-2">
            <div className="headline-small">{title}</div>
            <NumericFormat
              value={price}
              decimalSeparator=","
              decimalScale="2"
              fixedDecimalScale="true"
              displayType={"text"}
              thousandSeparator="."
              suffix={" €"}
              prefix="Preis ab "
              className="body-small-emphasis"
            />
          </div>

          {features && (
            <div className="px-4 mt-6 flex flex-col gap-6 body-small">
              {features.map((feature, index) => (
                <div key={index}>{feature.value}</div>
              ))}
            </div>
          )}
        </div>

        {(linkText || linkText2) && (
          <div>
            {linkText && linkUrl && (
              <div className="px-4 mt-10">
                <Link href={linkUrl} className="btn-primary w-full">
                  {linkText}
                </Link>
              </div>
            )}

            {linkText2 && linkUrl2 && (
              <div className="px-4 mt-2">
                <Link
                  href={linkUrl2}
                  className="btn-secondary w-full"
                  target="_blank"
                  onClick={(event) => {
                    event.preventDefault();
                    setModalOpen(true);
                  }}
                >
                  {linkText2}
                </Link>
              </div>
            )}
          </div>
        )}
      </div>
      <Modal open={modalOpen} setOpen={setModalOpen} url={linkUrl2} />
    </>
  );
};

export default ListItem;

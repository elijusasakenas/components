import { Builder } from "@builder.io/react";
import ContentImageCardLarge from "@/components/BuilderIo/Content/ImageCardLarge/ImageCardLarge";

// Register ContentImageCardLarge component
Builder.registerComponent(ContentImageCardLarge, {
  name: "ContentImageCardLarge",
  friendlyName: "Content Image Card Large",
  description: "Content | Image Card Large",
  screenshot:
    "https://cdn.builder.io/api/v1/image/assets%2F90182f3615654f8c9be2b012f26cc6c0%2Fe6e14b7fa38240519b0e74c226f2ec35",
  
  inputs: [
    {
      name: "bgImageDesktop",
      friendlyName: "Background Image Desktop",
      type: "file",
    },
    {
      name: "bgImageTablet",
      friendlyName: "Background Image Tablet",
      type: "file",
    },
    {
      name: "bgImageMobile",
      friendlyName: "Background Image Mobile",
      type: "file",
    },
    {
      name: "bgImagePosition",
      friendlyName: "Background Image Position",
      type: "select",
      defaultValue: "object-center",
      enum: [
        { label: "Center", value: "object-center" },
        { label: "Top", value: "object-top" },
        { label: "Bottom", value: "object-bottom" },
        { label: "Left", value: "object-left" },
        { label: "Left Bottom", value: "object-left-bottom" },
        { label: "Left Top", value: "object-left-top" },
        { label: "Right", value: "object-right" },
        { label: "Right Bottom", value: "object-right-bottom" },
        { label: "Right Top", value: "object-right-top" },
      ],
    },
    {
      name: "text",
      friendlyName: "Text",
      type: "string",
    },
  ],
});

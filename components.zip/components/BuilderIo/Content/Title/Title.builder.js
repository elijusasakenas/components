import { Builder } from "@builder.io/react";
import ContentTitle from "@/components/BuilderIo/Content/Title/Title";

// Register ContentTitle component
Builder.registerComponent(ContentTitle, {
  name: "ContentTitle",
  friendlyName: "Content Title",
  screenshot:
    "https://cdn.builder.io/api/v1/image/assets%2F90182f3615654f8c9be2b012f26cc6c0%2Fa33fcee3a6c94179a6891d8979fc3c77",
  
  inputs: [
    {
      name: "title",
      friendlyName: "Title",
      type: "string",
    },
  ],
});

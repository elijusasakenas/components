import { motion } from "framer-motion";

function ContentTitle(props) {
  return (
    <motion.div
      initial={{ opacity: 0, translateY: 30 }}
      whileInView={{ opacity: 1, translateY: 0 }}
      transition={{ duration: 0.7 }}
      className="content max-w-7xl mx-auto w-full px-6 md:px-12 xl:px-0 relative flex flex-col self-stretch bg-white"
    >
      <div className="pt-14 pb-8 w-full headline-large text-base-50 xl:text-center">
        {props.title}
      </div>
    </motion.div>
  );
}

export default ContentTitle;

import { Builder } from "@builder.io/react";
import ContentImageCard from "@/components/BuilderIo/Content/ImageCard/ImageCard";

Builder.registerComponent(ContentImageCard, {
  name: "ContentImageCard",
  friendlyName: "Content Image Card",
  description: "Content | Image Card",
  screenshot:
    "https://cdn.builder.io/api/v1/image/assets%2F90182f3615654f8c9be2b012f26cc6c0%2Fb2f6b41cd53a40698798476fa824078e",
  
  inputs: [
    {
      name: "item1",
      friendlyName: "Card 1",
      type: "object",
      subFields: [
        {
          name: "bgImageDesktop",
          friendlyName: "Background Image Desktop",
          type: "file",
        },
        {
          name: "bgImageTablet",
          friendlyName: "Background Image Tablet",
          type: "file",
        },
        {
          name: "bgImageMobile",
          friendlyName: "Background Image Mobile",
          type: "file",
        },
        {
          name: "bgImagePosition",
          friendlyName: "Background Image Position",
          type: "select",
          defaultValue: "object-center",
          enum: [
            { label: "Center", value: "object-center" },
            { label: "Top", value: "object-top" },
            { label: "Bottom", value: "object-bottom" },
            { label: "Left", value: "object-left" },
            { label: "Left Bottom", value: "object-left-bottom" },
            { label: "Left Top", value: "object-left-top" },
            { label: "Right", value: "object-right" },
            { label: "Right Bottom", value: "object-right-bottom" },
            { label: "Right Top", value: "object-right-top" },
          ],
        },
        {
          name: "text",
          friendlyName: "Text",
          type: "string",
        },
      ],
    },
    {
      name: "item2",
      friendlyName: "Card 2",
      type: "object",
      subFields: [
        {
          name: "bgImageDesktop",
          friendlyName: "Background Image Desktop",
          type: "file",
        },
        {
          name: "bgImageTablet",
          friendlyName: "Background Image Tablet",
          type: "file",
        },
        {
          name: "bgImageMobile",
          friendlyName: "Background Image Mobile",
          type: "file",
        },
        {
          name: "bgImagePosition",
          friendlyName: "Background Image Position",
          type: "select",
          defaultValue: "object-center",
          enum: [
            { label: "Center", value: "object-center" },
            { label: "Top", value: "object-top" },
            { label: "Bottom", value: "object-bottom" },
            { label: "Left", value: "object-left" },
            { label: "Left Bottom", value: "object-left-bottom" },
            { label: "Left Top", value: "object-left-top" },
            { label: "Right", value: "object-right" },
            { label: "Right Bottom", value: "object-right-bottom" },
            { label: "Right Top", value: "object-right-top" },
          ],
        },
        {
          name: "text",
          friendlyName: "Text",
          type: "string",
        },
      ],
    },
  ],
});

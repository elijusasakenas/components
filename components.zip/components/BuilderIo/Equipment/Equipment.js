import Title from "@/components/BuilderIo/Equipment/Title";
import List from "@/components/BuilderIo/Equipment/List";

const Equipment = ({ title, equipment1, equipment2, equipment3 }) => {
  return (
    <div className="max-w-7xl mx-auto w-full relative">
      <Title content={title} />
      <List equipment1={equipment1} equipment2={equipment2} equipment3={equipment3} />
    </div>
  );
};

export default Equipment;

import { Builder } from "@builder.io/react";
import Equipment from "@/components/BuilderIo/Equipment/Equipment";

Builder.registerComponent(Equipment, {
  name: "Equipment",
  friendlyName: "Equipment",
  screenshot:
    "https://cdn.builder.io/api/v1/image/assets%2F90182f3615654f8c9be2b012f26cc6c0%2F3d44609baae1433b97a39ebb4c87fd36",
  
  inputs: [
    {
      name: "title",
      friendlyName: "Title",
      type: "string",
      defaultValue: "Headline",
    },
    {
      name: "equipment1",
      friendlyName: "Equipment 1",
      type: "object",
      defaultValue: {
        image: "https://placehold.co/480x310/131313/FFF@2x.png",
        title: "Ac odio eu nibh lorem bibendum donec. Tincidunt",
      },
      subFields: [
        {
          name: "image",
          friendlyName: "Bild",
          type: "file",
        },
        {
          name: "title",
          friendlyName: "Title",
          type: "string",
        },
      ],
    },
    {
      name: "equipment2",
      friendlyName: "Equipment 2",
      type: "object",
      defaultValue: {
        image: "https://placehold.co/122x122/131313/FFF@2x.png",
        title: "Ac odio eu nibh lorem bibendum donec. Tincidunt",
      },
      subFields: [
        {
          name: "image",
          friendlyName: "Bild",
          type: "file",
        },
        {
          name: "title",
          friendlyName: "Title",
          type: "string",
        },
      ],
    },
    {
      name: "equipment3",
      friendlyName: "Equipment 3",
      type: "object",
      defaultValue: {
        image: "https://placehold.co/122x122/131313/FFF@2x.png",
        title: "Ac odio eu nibh lorem bibendum donec. Tincidunt",
      },
      subFields: [
        {
          name: "image",
          friendlyName: "Bild",
          type: "file",
        },
        {
          name: "title",
          friendlyName: "Title",
          type: "string",
        },
      ],
    },
  ],
});

import BuilderImage from "@/components/BuilderImage";

const List = ({ equipment1, equipment2, equipment3 }) => {
  return (
    <div>
      <div>
        <BuilderImage
          src={equipment1.image}
          width={480}
          height={308}
          alt="Equipment 1"
          className="w-full object-cover"
        />
      </div>
      <div>
        <div>
          <BuilderImage
            src={equipment2.image}
            width={122}
            height={122}
            alt="Equipment 1"
            className="w-full object-cover"
          />
        </div>

        <div>
          <BuilderImage
            src={equipment3.image}
            width={122}
            height={122}
            alt="Equipment 1"
            className="w-full object-cover"
          />
        </div>
      </div>
    </div>
  );
};

export default List;

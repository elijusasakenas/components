import { Builder } from "@builder.io/react";
import MediaText from "@/components/BuilderIo/Family/MediaText/MediaText";

// Register MediaText component
Builder.registerComponent(MediaText, {
  name: "MediaText",
  friendlyName: "Media Text",
  screenshot:
    "https://cdn.builder.io/api/v1/image/assets%2F90182f3615654f8c9be2b012f26cc6c0%2F93e45535cbc44864a16d3dade815adcf",
  
  inputs: [
    {
      name: "bgColor",
      friendlyName: "Background Color",
      type: "select",
      defaultValue: "white",
      enum: [
        { label: "Weiß", value: "white" },
        { label: "Hellgrau", value: "lightGrey" },
        { label: "Grau Blau", value: "greyBlue" },
        { label: "Blau", value: "blue" },
        { label: "Grün", value: "green" },
        { label: "Orange", value: "orange" },
        { label: "Dunkel", value: "dark" },
      ],
    },
    {
      name: "title",
      friendlyName: "Title",
      type: "string",
      defaultValue: "Title",
    },
    {
      name: "text",
      friendlyName: "Text",
      type: "string",
      defaultValue: "Lorem ipsum dolor sit amet.",
    },
    {
      name: "media",
      friendlyName: "Media",
      type: "object",
      defaultValue: {
        imageDesktop: "https://placehold.co/2880x1780.png",
        imageTablet: "https://placehold.co/1488x2266.png",
        imageMobile: "https://placehold.co/780x1688.png",
        imagePosition: "object-top",
        type: "image",
      },
      subFields: [
        {
          name: "imageDesktop",
          friendlyName: "Image Desktop",
          type: "file",
        },
        {
          name: "imageTablet",
          friendlyName: "Image Tablet",
          type: "file",
        },
        {
          name: "imageMobile",
          friendlyName: "Image Mobile",
          type: "file",
        },
        {
          name: "imagePosition",
          friendlyName: "Image Position",
          type: "select",
          enum: [
            { label: "Oben", value: "object-top" },
            { label: "Mitte", value: "object-center" },
            { label: "Unten", value: "object-bottom" },
          ],
        },
        {
          name: "video",
          friendlyName: "Video",
          type: "file",
        },
        {
          name: "type",
          friendlyName: "Type",
          type: "text",
          enum: [
            { label: "Video", value: "video" },
            { label: "Bild", value: "image" },
          ],
        },
      ],
    },
    {
      name: "mediaContent",
      friendlyName: "Media Content",
      type: "object",
      subFields: [
        {
          name: "headline",
          friendlyName: "Headline",
          type: "string",
        },
        {
          name: "text",
          friendlyName: "Text",
          type: "richText",
        },
        {
          name: "button",
          friendlyName: "Button anzeigen",
          type: "boolean",
        },
        {
          name: "buttonText",
          friendlyName: "Button Text",
          type: "string",
          defaultValue: "Button Text",
        },
        {
          name: "buttonLink",
          friendlyName: "Button Link",
          type: "string",
          defaultValue: "#",
        },
      ],
    },
  ],
});

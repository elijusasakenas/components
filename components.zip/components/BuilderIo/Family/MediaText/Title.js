import { motion, useScroll, useTransform } from "framer-motion";
import { useEffect, useRef, useState } from "react";

const Title = ({ title, text, containerRef }) => {
  const ref = useRef(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start start", "end start"],
  });

  const opacity = useTransform(scrollYProgress, [0, 1], [1, 0]);
  const translateY = useTransform(scrollYProgress, [0, 0.7], [0, -200]);

  const [height, setHeight] = useState(null);

  useEffect(() => {
    if (containerRef.current) {
      const media = containerRef.current.querySelector("#media");
      const scrollHeight =
        containerRef.current.offsetHeight - media.offsetHeight;
      setHeight(scrollHeight);
    }
  }, [containerRef]);

  const scrollToNextSection = () => {
    const media = containerRef.current.querySelector("#media");
    media.scrollIntoView({ behavior: "smooth", block: "center" });

  };

  return (
    <div ref={ref}>
      <motion.div
        style={{ opacity: opacity, translateY: translateY }}
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7 }}
        className="pt-16 md:pt-32 lg:pt-40 px-6 text-center"
      >
        {title && <div className="display">{title}</div>}
        {text && <div className="body mb-6 mt-4 md:mt-6">{text}</div>}

        <button onClick={scrollToNextSection} className="mb-10">
          <div className="arrow">
            <span></span>
            <span></span>
          </div>
        </button>
      </motion.div>
    </div>
  );
};

export default Title;

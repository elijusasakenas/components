import useScreenSize from "@/utility/useScreenSize";
import { motion, useScroll, useTransform } from "framer-motion";
import { useRef } from "react";
import BuilderImage from "@/components/BuilderImage";

const Media = ({ data, content }) => {
  const screenSize = useScreenSize();
  const ref = useRef(null);

  let offset = "start 270px";
  if (screenSize.width >= 768) {
    offset = "start 370px";
  }
  if (screenSize.width >= 1440) {
    offset = "start 420px";
  }
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: [offset, "end start"],
  });

  let paddingValue = 24;
  let translateYContentValue = 200;
  if (screenSize.width >= 768) {
    paddingValue = 48;
    translateYContentValue = 250;
  }
  if (screenSize.width >= 1440) {
    paddingValue = 90;
    translateYContentValue = 300;
  }

  const translateY = useTransform(scrollYProgress, [0, 0.1], [0, -100]);
  const padding = useTransform(scrollYProgress, [0, 0.1], [paddingValue, 0]);
  const opacity = useTransform(scrollYProgress, [0, 0.1], [0, 1]);
  const translateYContent = useTransform(
    scrollYProgress,
    [0, 0.1],
    [translateYContentValue, 0]
  );
  const rounded = useTransform(scrollYProgress, [0, 0.1], [8, 0]);

  return (
    <div ref={ref} id="media">
      <motion.div
        style={{
          padding: padding,
          //translateY: translateY,
          //marginBottom: translateY,
        }}
        className={`media mx-auto w-full h-screen lg-h-auto relative !py-0 overflow-hidden max-h-[890px]`}
      >
        {data.type === "video" ? (
          data.video && (
            <motion.div
              style={{ borderRadius: rounded }}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.6 }}
              className="rounded-lg overflow-hidden h-full"
            >
              <video
                src={data.video}
                autoPlay
                loop
                muted
                playsInline
                style={{ borderRadius: rounded }}
                className="w-full h-full overflow-hidden object-cover"
              ></video>
            </motion.div>
          )
        ) : (
          <>
            <motion.div
              style={{ borderRadius: rounded }}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.6 }}
              className="rounded-lg overflow-hidden h-full"
            >
              <BuilderImage
                src={data.imageMobile}
                width={390}
                height={844}
                alt="media"
                className={`w-full h-full object-cover sm:hidden ${data.imagePosition}`}
                priority
              />

              <BuilderImage
                src={data.imageTablet}
                width={768}
                height={844}
                alt="media"
                className={`w-full h-full object-cover hidden sm:block lg:hidden ${data.imagePosition}`}
                priority
              />

              <BuilderImage
                src={data.imageDesktop}
                width={1260}
                height={844}
                alt="media"
                className={`w-full h-full object-cover hidden lg:block ${data.imagePosition}`}
                priority
              />
            </motion.div>
          </>
        )}

        {content && (
          <motion.div
            className="w-auto absolute inset-x-0 bottom-0 px-6 md:px-16 pt-12 pb-40 lg:pb-24 text-white bg-content overflow-hidden max-h-screen"
            style={{
              opacity: opacity,
              translateY: translateYContent,
              margin: padding,
              borderBottomLeftRadius: rounded,
              borderBottomRightRadius: rounded,
            }}
          >
            <div className="mx-auto lg:max-w-[830px]">
              <div className="headline-medium mb-4 line-clamp-2">
                {content.headline}
              </div>
              <div
                className="body"
                dangerouslySetInnerHTML={{ __html: content.text }}
              />

              {content?.button && (
                <button href={content.buttonLink} className="btn-primary mt-6">
                  {content.buttonText}
                </button>
              )}
            </div>
          </motion.div>
        )}
      </motion.div>
    </div>
  );
};

export default Media;

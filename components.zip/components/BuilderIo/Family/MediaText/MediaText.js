import Title from "@/components/BuilderIo/Family/MediaText/Title";
import Media from "@/components/BuilderIo/Family/MediaText/Media";
import LogoBuilder from "@/components/LogoBuilder";
import { useEffect, useRef } from "react";
import { useDispatch, useSelector } from "react-redux";
import { setLogoCmsMode } from "@/redux/header/logoCms";

const MediaText = ({ bgColor, title, text, media, mediaContent }) => {
  const bgColorGradient = getBgColorGradient(bgColor);
  const ref = useRef(null);
  const mobileMenuOpen = useSelector((state) => state.navigation.mobileMenuOpen);
  const mobileSearchOpen = useSelector((state) => state.navigation.mobileSearchOpen);
  const dispatch = useDispatch();
  dispatch(setLogoCmsMode("dark"));

  return (
    <div className={bgColorGradient} ref={ref}>
      <div className={`${(mobileMenuOpen || mobileSearchOpen) ? 'hidden' : 'visible'}`}>
        <LogoBuilder containerRef={ref} />
      </div>

      <div className={`media-text mx-auto w-full relative`}>
        <Title title={title} text={text} containerRef={ref} />
        <Media data={media} content={mediaContent} />
      </div>
    </div>
  );
};

export default MediaText;

const getBgColorGradient = (bgColor) => {
  switch (bgColor) {
    case "white":
      return "bg-white";
    case "lightGrey":
      return "bg-gradient-to-b from-base-300 to-base-400";
    case "greyBlue":
      return "bg-gradient-to-b from-blue-200 to-blue-300 text-white";
    case "blue":
      return "bg-gradient-to-b from-blue-300 to-blue-100 text-white";
    case "green":
      return "bg-gradient-to-b from-green-300 to-green-100 text-white";
    case "orange":
      return "bg-gradient-to-b from-orange-400 to-orange-50 text-white";
    case "dark":
      return "bg-gradient-to-b from-[#1F1E25] to-[#2A2A2C] text-white";
    default:
      return "bg-white";
  }
};

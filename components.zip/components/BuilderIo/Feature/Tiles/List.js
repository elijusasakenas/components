import ListItem from "@/components/BuilderIo/Feature/Tiles/ListItem";
import { motion } from "framer-motion";

import "swiper/css";
import "swiper/css/navigation";
import { Navigation } from "swiper/modules";
import { Swiper, SwiperSlide } from "swiper/react";
import "./styles.scss";

const List = ({ items }) => {
  return (
    items &&
    items.length > 0 && (
      <div className="mb-14 lg:mb-24 pl-6 md:pl-12 xl:pl-0">
        <Swiper
          slidesPerView={"auto"}
          navigation={true}
          modules={[Navigation]}
          className="feature-tiles-slider"
        >
          {items.map((item, index) => (
            <SwiperSlide key={index}>
              <motion.div
                variants={item}
                className="w-full"
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.7, delay: 0.2 }}
              >
                <ListItem data={item} />
              </motion.div>
            </SwiperSlide>
          ))}
        </Swiper>
      </div>
    )
  );
};

export default List;

// example data
const items = [
  {
    id: 1,
    image: "https://placehold.co/300x525/131313/FFF@2x.png",
    title: "1 - Ac odio eu nibh lorem bibendum donec. Tincidunt ",
    modal: {
      title: "1 - Hochwertiger Rohrsatz für mehr Balance und Dauerhaltbarkeit",
      text1:
        "Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum.",
      image: "https://placehold.co/326x326/ffffff/131313@2x.png",
      text2:
        "Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. empor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum.",
    },
  },
  {
    id: 2,
    image: "https://placehold.co/300x525/131313/FFF@2x.png",
    title: "2 - Ac odio eu nibh lorem bibendum donec. Tincidunt ",
    modal: {
      title: "2 - Hochwertiger Rohrsatz für mehr Balance und Dauerhaltbarkeit",
      text1:
        "Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum.",
      image: "https://placehold.co/326x326/ffffff/131313@2x.png",
      text2:
        "Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. empor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum.",
    },
  },
  {
    id: 3,
    image: "https://placehold.co/300x525/131313/FFF@2x.png",
    title: "3 - Ac odio eu nibh lorem bibendum donec. Tincidunt ",
    modal: {
      title: "3 - Hochwertiger Rohrsatz für mehr Balance und Dauerhaltbarkeit",
      text1:
        "Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum.",
      image: "https://placehold.co/326x326/ffffff/131313@2x.png",
      text2:
        "Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. empor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum.",
    },
  },
  {
    id: 4,
    image: "https://placehold.co/300x525/131313/FFF@2x.png",
    title: "4 - Ac odio eu nibh lorem bibendum donec. Tincidunt ",
    modal: {
      title: "4 - Hochwertiger Rohrsatz für mehr Balance und Dauerhaltbarkeit",
      text1:
        "Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum.",
      image: "https://placehold.co/326x326/ffffff/131313@2x.png",
      text2:
        "Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. empor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum.",
    },
  },
  {
    id: 5,
    image: "https://placehold.co/300x525/131313/FFF@2x.png",
    title: "5 - Ac odio eu nibh lorem bibendum donec. Tincidunt ",
    modal: {
      title: "5 - Hochwertiger Rohrsatz für mehr Balance und Dauerhaltbarkeit",
      text1:
        "Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum.",
      image: "https://placehold.co/326x326/ffffff/131313@2x.png",
      text2:
        "Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. empor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum.",
    },
  },
];

import { motion } from "framer-motion";

const Title = ({ content }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.7 }}
      className="headline-large px-6 md:px-12 pt-14 pb-8 xl:text-center xl:max-w-[830px] xl:mx-auto"
    >
      {content}
    </motion.div>
  );
};

export default Title;

import { Dialog, DialogPanel } from "@headlessui/react";
import { AnimatePresence, motion } from "framer-motion";
import BuilderImage from "@/components/BuilderImage";

const ListItemModal = ({ open, setOpen, data }) => {
  return (
    <AnimatePresence>
      <Dialog open={open} onClose={setOpen}>
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="z-30 fixed inset-0 bg-base-50/70 duration-300 ease-out data-[closed]:opacity-0 transition-all"
        />

        <div className="z-30 fixed inset-0 w-screen overflow-y-auto">
          <div className="flex min-h-full items-center justify-center">
            <DialogPanel
              as={motion.div}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="lg:max-w-[744px] bg-base-50 text-white pb-14 w-full duration-300 ease-out data-[closed]:scale-95 data-[closed]:opacity-0 transition-all"
            >
              <div className="sticky top-0 text-right pt-8 mb-6 pr-6">
                <div className="absolute top-0 left-0 h-2 w-full bg-orange-200"></div>

                <button
                  className="rounded-full bg-base-200 hover:bg-orange-100 p-2"
                  onClick={() => setOpen(false)}
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                  >
                    <path
                      d="M13.2261 11.8745L17.8276 16.4761C17.939 16.5874 17.939 16.7729 17.8276 16.9214L17.0112 17.7378C16.8628 17.8491 16.6772 17.8491 16.5659 17.7378L15.7866 16.9585L12.0015 13.1362L7.3999 17.7378C7.28857 17.8491 7.10303 17.8491 6.95459 17.7378L6.13818 16.9214C6.02686 16.7729 6.02686 16.5874 6.13818 16.4761L10.7397 11.8745L6.13818 7.31006C6.02686 7.19873 6.02686 7.01318 6.13818 6.86475L6.95459 6.04834C7.10303 5.93701 7.28857 5.93701 7.3999 6.04834L12.0015 10.6499L16.5659 6.04834C16.6772 5.93701 16.8628 5.93701 17.0112 6.04834L17.8276 6.86475C17.939 7.01318 17.939 7.19873 17.8276 7.31006L17.0483 8.08936L13.2261 11.8745Z"
                      fill="white"
                    />
                  </svg>
                </button>
              </div>

              <div className="px-8 md:px-12">
                <div className="headline-medium mb-4">{data.modal.title}</div>

                {data.modal.text1 && (
                  <div
                    className="body"
                    dangerouslySetInnerHTML={{ __html: data.modal.text1 }}
                  ></div>
                )}

                {data.modal.image && (
                  <div className="mt-14 mb-8 rounded-lg overflow-hidden">
                    <BuilderImage
                      src={data.modal.image}
                      width={300}
                      height={525}
                      alt="Feature Bg Image"
                      className="w-full object-cover max-w-80 mx-auto"
                    />
                  </div>
                )}

                {data.modal.text2 && (
                  <div
                    className="body"
                    dangerouslySetInnerHTML={{ __html: data.modal.text2 }}
                  ></div>
                )}
              </div>
            </DialogPanel>
          </div>
        </div>
      </Dialog>
    </AnimatePresence>
  );
};

export default ListItemModal;

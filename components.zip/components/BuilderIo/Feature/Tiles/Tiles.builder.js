import { Builder } from "@builder.io/react";
import FeatureTiles from "@/components/BuilderIo/Feature/Tiles/Tiles";

// Register Feature component
Builder.registerComponent(FeatureTiles, {
  name: "FeatureTiles",
  friendlyName: "Feature: Tiles",
  screenshot:
    "https://cdn.builder.io/api/v1/image/assets%2F90182f3615654f8c9be2b012f26cc6c0%2F2cf36f11e7f549b79d696b70b7886a89",
  
  inputs: [
    {
      name: "title",
      friendlyName: "Title",
      type: "string",
      defaultValue: "Headline",
    },
    {
      name: "featuresList",
      friendlyName: "Features",
      type: "list",
      subFields: [
        {
          name: "image",
          friendlyName: "Image",
          type: "file",
          defaultValue: "https://placehold.co/300x525/131313/FFF@2x.png",
        },
        {
          name: "bgColor",
          friendlyName: "Background Color",
          type: "select",
          defaultValue: "white",
          enum: [
            { label: "Weiß", value: "white" },
            { label: "Hellgrau", value: "lightGrey" },
            { label: "Grau Blau", value: "greyBlue" },
            { label: "Blau", value: "blue" },
            { label: "Grün", value: "green" },
            { label: "Orange", value: "orange" },
            { label: "Dunkel", value: "dark" },
          ],
        },
        {
          name: "title",
          friendlyName: "Title",
          type: "string",
          defaultValue: "Ac odio eu nibh lorem bibendum donec. Tincidunt",
        },
        {
          name: "modal",
          friendlyName: "Modal",
          type: "object",
          subFields: [
            {
              name: "title",
              friendlyName: "Title",
              type: "string",
              defaultValue:
                "Hochwertiger Rohrsatz für mehr Balance und Dauerhaltbarkeit",
            },
            {
              name: "text1",
              friendlyName: "Text 1",
              type: "richText",
              defaultValue:
                "Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum.",
            },
            {
              name: "image",
              friendlyName: "Image",
              type: "file",
              defaultValue: "https://placehold.co/326x326/ffffff/131313@2x.png",
            },
            {
              name: "text2",
              friendlyName: "Text 2",
              type: "richText",
              defaultValue:
                "Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. empor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum.",
            },
          ],
        },
      ],
    },
  ],
});

import List from "@/components/BuilderIo/Feature/Tiles/List";
import Title from "@/components/BuilderIo/Feature/Tiles/Title";

const FeatureTiles = ({title, featuresList}) => {
  return (
    <div className="max-w-7xl mx-auto w-full relative">
      <Title content={title} />
      <List items={featuresList} />
    </div>
  );
};

export default FeatureTiles;

"use client";

import ListItemModal from "components/BuilderIo/Feature/Tiles/ListItemModal";
import { useState } from "react";
import BuilderImage from "@/components/BuilderImage";

const ListItem = ({ data }) => {
  const [modalOpen, setModalOpen] = useState(false);
  const bgColorGradient = getBgColorGradient(data.bgColor);

  return (
    <>
      <div
        className={`relative rounded-lg overflow-hidden min-h-[525px] ${
          data.modal && "cursor-pointer"
        } ${bgColorGradient}`}
        onClick={() => setModalOpen(true)}
      >
        {data.modal && (
          <div className="absolute top-4 right-4">
            <button
              className="flex items-center p-1 rounded-[4px] bg-orange-200 hover:bg-orange-100 focus:bg-orange-400 text-white"
              onClick={() => setModalOpen(true)}
            >
              <div className="sr-only">View</div>
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
              >
                <path
                  d="M12.8726 12.7595V19.2671C12.8726 19.4245 12.7414 19.5557 12.5578 19.5819H11.4032C11.2195 19.5557 11.0883 19.4245 11.0883 19.2671V18.165L11.1145 12.7857H4.60695C4.44951 12.7857 4.3183 12.6545 4.29206 12.4708V11.3163C4.3183 11.1326 4.44951 11.0014 4.60695 11.0014H11.1145L11.0883 4.52002C11.0883 4.36258 11.2195 4.23137 11.4032 4.20513H12.5578C12.7414 4.23137 12.8726 4.36258 12.8726 4.52002V11.0276L19.354 11.0014C19.5114 11.0014 19.6426 11.1326 19.6689 11.3163V12.4708C19.6426 12.6545 19.5114 12.7857 19.354 12.7857H18.2519L12.8726 12.7595Z"
                  fill="white"
                />
              </svg>
            </button>
          </div>
        )}
        <div>
          <BuilderImage
            src={data.image}
            width={300}
            height={525}
            alt="Feature Bg Image"
            className="w-full object-cover"
          />
        </div>

        <div className="absolute bottom-0 inset-x-0 px-6 py-8 z-10">
          <div className="headline-small">{data.title}</div>
        </div>
      </div>
      {data.modal && (
        <ListItemModal open={modalOpen} setOpen={setModalOpen} data={data} />
      )}
    </>
  );
};

export default ListItem;

const getBgColorGradient = (bgColor) => {
  switch (bgColor) {
    case "white":
      return "bg-white text-base-50";
    case "lightGrey":
      return "bg-gradient-to-b from-base-300 to-base-400 text-base-50";
    case "greyBlue":
      return "bg-gradient-to-b from-blue-200 to-blue-300 text-white";
    case "blue":
      return "bg-gradient-to-b from-blue-300 to-blue-100 text-white";
    case "green":
      return "bg-gradient-to-b from-green-300 to-green-100 text-white";
    case "orange":
      return "bg-gradient-to-b from-orange-400 to-orange-50 text-white";
    case "dark":
      return "bg-gradient-to-b from-[#1F1E25] to-[#2A2A2C] text-white";
    default:
      return "bg-white";
  }
};

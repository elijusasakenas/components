import { motion } from "framer-motion";

const Content = ({ data }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{
        duration: 0.7,
        delay: 0.25,
      }}
      className="mt-12 pb-24 md:pb-40 lg:pb-56 mx-6 md:mx-12 lg:mx-auto max-w-4xl"
    >
      <div className="headline-large mb-2 md:mb-4">{data.title}</div>
      <div className="body-small text-base-300 mb-8 lg:mb-10">{data.subtitle}</div>
      <div className="body" dangerouslySetInnerHTML={{ __html: data.text }} />
    </motion.div>
  );
};

export default Content;

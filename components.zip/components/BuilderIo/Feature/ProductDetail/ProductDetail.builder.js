import { Builder } from "@builder.io/react";
import FeatureProductDetail from "./ProductDetail";

Builder.registerComponent(FeatureProductDetail, {
  name: "FeatureProductDetail",
  friendlyName: "Feature: Product Detail",
  screenshot:
    "https://cdn.builder.io/api/v1/image/assets%2F90182f3615654f8c9be2b012f26cc6c0%2F249c06063ca541dabe303d36e2e47154",
  
  inputs: [
    {
      name: "sections",
      friendlyName: "Sections",
      type: "list",
      defaultValue: [
        {
          image:
            "https://cdn.builder.io/api/v1/image/assets%2F90182f3615654f8c9be2b012f26cc6c0%2F12041ab088fc4445883c3e8eb65e8971",
          imageMobile:
            "https://cdn.builder.io/api/v1/image/assets%2F90182f3615654f8c9be2b012f26cc6c0%2Ff3816d346d674098b17e3e27219e224e",
          title: "2,5x leichter ",
          subtitle: "als beim X Modell",
          text: "Volutpat at sed neque mus. Pulvinar non pellentesque quam pellentesque facilisis ac. Pharetra eros massa nulla posuere tristique.",
        },
        {
          image:
            "https://cdn.builder.io/api/v1/image/assets%2F90182f3615654f8c9be2b012f26cc6c0%2F17b9094d32dd411383613204074e9808",
          imageMobile:
            "https://cdn.builder.io/api/v1/image/assets%2F90182f3615654f8c9be2b012f26cc6c0%2F558b177dd792418eb863682020ddebb9",
          title: "2,5x leichter ",
          subtitle: "als beim X Modell",
          text: "Volutpat at sed neque mus. Pulvinar non pellentesque quam pellentesque facilisis ac. Pharetra eros massa nulla posuere tristique.",
        },
        {
          image:
            "https://cdn.builder.io/api/v1/image/assets%2F90182f3615654f8c9be2b012f26cc6c0%2Ffbc9cd63c9bb4ee2a8ef6de798b864ad",
          imageMobile:
            "https://cdn.builder.io/api/v1/image/assets%2F90182f3615654f8c9be2b012f26cc6c0%2Fc84f7267d1854471914511ea9d89f541",
          title: "2,5x leichter ",
          subtitle: "als beim X Modell",
          text: "Volutpat at sed neque mus. Pulvinar non pellentesque quam pellentesque facilisis ac. Pharetra eros massa nulla posuere tristique.",
        },
      ],
      subFields: [
        {
          name: "image",
          friendlyName: "Image",
          type: "file",
        },
        {
          name: "imageMobile",
          friendlyName: "Image Mobile",
          type: "file",
        },
        {
          name: "title",
          friendlyName: "Title",
          type: "string",
        },
        {
          name: "subtitle",
          friendlyName: "Subtitle",
          type: "string",
        },
        {
          name: "text",
          friendlyName: "Text",
          type: "richText",
        },
      ],
    },
  ],
});

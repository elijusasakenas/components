import Media from "@/components/BuilderIo/Feature/ProductDetail/Media";
import Content from "@/components/BuilderIo/Feature/ProductDetail/Content";

const FeatureProductDetail = ({ sections }) => {  
  return (
    <div className="bg-gradient-base text-base-500">
      {sections.map((props, index) => (
        <div key={index}>
          <Media data={props} index={index} />
          <Content data={props} />
        </div>
      ))}
    </div>
  );
};

export default FeatureProductDetail;

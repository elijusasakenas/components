import { motion } from "framer-motion";
import BuilderImage from "@/components/BuilderImage";

const Images = ({ imageLeft, imageRight }) => {
  return (
    <div className="flex justify-between items-center gap-10 mb-6 lg:mb-12">
      {imageLeft && (
        <motion.div
          initial={{ opacity: 0, x: "-90%" }}
          whileInView={{ opacity: 1, x: "0%" }}
          transition={{ duration: 0.7 }}
          className="w-1/2"
        >
          <BuilderImage
            src={imageLeft}
            width={580}
            height={540}
            alt="media"
            className="w-full mr-auto ml-0"
            priority
          />
        </motion.div>
      )}

      {imageRight && (
        <motion.div
          initial={{ opacity: 0, x: "90%" }}
          whileInView={{ opacity: 1, x: "0%" }}
          transition={{ duration: 0.7 }}
          className="w-1/2"
        >
          <BuilderImage
            src={imageRight}
            width={580}
            height={540}
            alt="media"
            className="w-full ml-auto mr-0"
            priority
          />
        </motion.div>
      )}
    </div>
  );
};

export default Images;

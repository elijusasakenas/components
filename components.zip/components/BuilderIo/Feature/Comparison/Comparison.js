import Title from "@/components/BuilderIo/Feature/Comparison/Title";
import Text from "@/components/BuilderIo/Feature/Comparison/Text";
import Images from "@/components/BuilderIo/Feature/Comparison/Images";

const FeaturesComparison = ({...params}) => {
  return (
    <div className="w-full overflow-hidden">
      <div className="max-w-7xl mx-auto w-full relative">
        <Title title={params.title} subTitle={params.subTitle} />
        <Text text={params.text} />
        {params.media && <Images imageLeft={params.media.imageLeft} imageRight={params.media.imageRight} />}
      </div>
    </div>
  );
}

export default FeaturesComparison;
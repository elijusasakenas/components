import { Builder } from "@builder.io/react";
import FeaturesComparison from "@/components/BuilderIo/Feature/Comparison/Comparison";

Builder.registerComponent(FeaturesComparison, {
  name: "FeaturesComparison",
  friendlyName: "Feature: Comparison",
  screenshot: "https://cdn.builder.io/api/v1/image/assets%2F90182f3615654f8c9be2b012f26cc6c0%2F652f95bc24024b3aa24d1df47f1264cb",
  
  inputs: [
    {
      name: "title",
      friendlyName: "Title",
      type: "string",
      defaultValue: "Headline"
    },
    {
      name: "subTitle",
      friendlyName: "Subtitle",
      type: "string",
      defaultValue: "Sub Title",
    },
    {
      name: "text",
      friendlyName: "Text",
      type: "richText",
      defaultValue: "Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet.",
    },
    {
      name: "media",
      friendlyName: "Media",
      type: "object",
      subFields: [
        {
          name: "imageLeft",
          friendlyName: "Image left",
          type: "file",
        },
        {
          name: "imageRight",
          friendlyName: "Image right",
          type: "file",
        },
      ],
    },
  ]
});

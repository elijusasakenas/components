import { motion } from "framer-motion";

const Title = ({ title, subTitle }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.7 }}
      className="px-6 md:px-12 lg:px-16 xl:px-0 pt-14 lg:pt-24 xl:max-w-[830px] xl:mx-auto"
    >
      {title && <div className="headline-large">{title}</div>}
      {subTitle && <div className="headline-medium mt-2 md:mt-4">{subTitle}</div>}
    </motion.div>
  );
};

export default Title;

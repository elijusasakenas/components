import { motion } from "framer-motion";

const Text = ({ text }) => {
  return (
    text &&     <motion.div
    initial={{ opacity: 0, y: 30 }}
    whileInView={{ opacity: 1, y: 0 }}
    transition={{ duration: 0.7 }}
    className="body px-6 md:px-12 lg:px-16 xl:px-0 pt-10 pb-14 lg:pt-14 lg:pb-16 xl:max-w-[830px] xl:mx-auto" dangerouslySetInnerHTML={{ __html: text }} />
  );
};

export default Text;

import { motion } from "framer-motion";
import BuilderImage from "@/components/BuilderImage";

export function NameOriginTitle({ title, roadImage, contextImage }) {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{
        duration: 0.7,
        delay: .5
      }}
      className="flex gap-6 justify-center items-start p-6 md:py-10 lg:py-14 md:px-14 w-full"
    >
      <div className="flex relative flex-col self-stretch my-auto min-w-[240px] w-full sm:w-1/2 max-md:max-w-full">
        <div className="flex z-0 flex-col items-center self-center text-4xl xl:text-[60px] font-bold leading-none text-white uppercase whitespace-nowrap tracking-[4.2px] max-md:text-2xl">
          <div className="gap-2 self-stretch px-2 border-b-2 border-base-500 pb-3">
            {title}
          </div>
        </div>
        {roadImage && (
          <div className="flex z-0 flex-col justify-center items-center px-6 py-2 w-full max-md:px-5 max-md:max-w-full lg:mt-4">
            <div className="relative w-[375px] aspect-[1.4] sm:w-[261px] lg:w-[502px]">
              <BuilderImage
                src={roadImage}
                alt="Name origin decorative element"
                fill
                className="object-contain"
                sizes="(max-width: 768px) 100vw, 550px"
              />
            </div>
          </div>
        )}
      </div>
      {contextImage && (
        <div className="relative min-w-[240px] w-[299px] lg:w-[550px] aspect-[1.21] max-md:flex max-md:max-w-full max-sm:hidden">
          <BuilderImage
            src={contextImage}
            alt="Name origin feature image"
            fill
            className="object-contain"
            sizes="(max-width: 768px) 100vw, 550px"
          />
        </div>
      )}
    </motion.div>
  );
}

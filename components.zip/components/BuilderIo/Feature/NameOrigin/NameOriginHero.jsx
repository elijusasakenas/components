import { NameOriginTitle } from "@/components/BuilderIo/Feature/NameOrigin/NameOriginTitle";
import { NameOriginContent } from "@/components/BuilderIo/Feature/NameOrigin/NameOriginContent";
import NameOriginHeroMedia from "@/components/BuilderIo/Feature/NameOrigin/NameOriginHeroMedia";

export function NameOriginHero({
  media,
  roadImage,
  contextImage,
  title,
  subtitle,
  text,
}) {
  return (
    <div className="bg-base-200">
      <div className="flex overflow-hidden flex-col max-w-7xl mx-auto w-full relative">
        <div className="flex flex-col px-6 md:px-12 pt-6 md:pt-12 xl:px-0 xl:pt-14 w-full">
          <div className="flex overflow-hidden flex-col w-full">
            <NameOriginHeroMedia data={media} />
          </div>
        </div>
        <NameOriginTitle title={title} roadImage={roadImage} contextImage={contextImage} />
        <NameOriginContent subtitle={subtitle} text={text} />
      </div>
    </div>
  );
}

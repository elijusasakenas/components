import { Builder } from "@builder.io/react";
import { NameOriginHero } from "@/components/BuilderIo/Feature/NameOrigin/NameOriginHero";

Builder.registerComponent(NameOriginHero, {
  name: 'FeatureNameOrigin',
  friendlyName: 'Name Origin',
  description: 'Name Origin - Hero',
  screenshot: "https://cdn.builder.io/api/v1/image/assets%2F90182f3615654f8c9be2b012f26cc6c0%2Fdc40aa99ed4343b69de0e91638a14e0f",
  inputs: [
    {
      name: "media",
      friendlyName: "Media",
      type: "object",
      defaultValue: {
        imageDesktop:
          "https://cdn.builder.io/api/v1/image/assets%2F90182f3615654f8c9be2b012f26cc6c0%2F0fc541c9ba2f42eca0894831b0967255",
        imageTablet:
          "https://cdn.builder.io/api/v1/image/assets%2F90182f3615654f8c9be2b012f26cc6c0%2Fd0011c33f6e84543b638fcde6193a2ea",
        imageMobile:
          "https://cdn.builder.io/api/v1/image/assets%2F90182f3615654f8c9be2b012f26cc6c0%2F23cbf7e07b9f4b6faf33f71940792b8e",
        type: "image",
      },
      subFields: [
        {
          name: "imageDesktop",
          friendlyName: "Image Desktop",
          type: "file",
        },
        {
          name: "imageTablet",
          friendlyName: "Image Tablet",
          type: "file",
        },
        {
          name: "imageMobile",
          friendlyName: "Image Mobile",
          type: "file",
        },
        {
          name: "videoDesktop",
          friendlyName: "Video Desktop",
          type: "file",
        },
        {
          name: "videoTablet",
          friendlyName: "Video Tablet",
          type: "file",
        },
        {
          name: "videoMobile",
          friendlyName: "Video Mobile",
          type: "file",
        },
        {
          name: "type",
          friendlyName: "Type",
          type: "select",
          enum: [
            { label: "Image", value: "image" },
            { label: "Video", value: "video" },
          ],
        },
      ],
    },
    {
      name: "roadImage",
      friendlyName: "Road Image",
      type: "file",
      allowedFileTypes: ['svg'] 
    },
    {
      name: "contextImage",
      friendlyName: "Context Image",
      type: "file",
      allowedFileTypes: ['svg'] 
    },
    {
      name: "title",
      friendlyName: "Title",
      type: "string",
      defaultValue: "Title",
    },
    {
      name: "subtitle",
      friendlyName: "Sub-Title",
      type: "string",
    },
    {
      name: "text",
      friendlyName: "Text",
      type: "richText",
      defaultValue: "Lorem ipsum dolor sit amet.",
    },
    
  ],
})
import { motion } from "framer-motion";

export function NameOriginContent({ subtitle, text }) {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{
        duration: 0.7,
        delay: .7
      }}
      className="flex flex-col w-full max-md:max-w-full lg:max-w-3xl mx-auto"
    >
      <div className="w-full body-emphasis text-orange-200 text-ellipsis max-md:max-w-full px-6 md:px-12">
        {subtitle}
      </div>
      <div className="pt-6 pb-16 w-full max-md:max-w-full px-6 md:px-12">
        <div
          className="body text-white"
          dangerouslySetInnerHTML={{ __html: text }}
        />
      </div>
    </motion.div>
  );
}

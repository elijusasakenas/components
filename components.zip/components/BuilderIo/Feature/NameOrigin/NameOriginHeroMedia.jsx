import BuilderImage from "@/components/BuilderImage";
import { motion } from "framer-motion";

/**
 * Renders a media component based on the provided data.
 * @param {Object} data - The data object containing information about the media.
 * @returns {JSX.Element} The rendered media component.
 */
const NameOriginHeroMedia = ({ data }) => {
  return (
    <div className="relative w-full aspect-[2.29]">
      {data.type === "video" ? (
        <>
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{
              duration: 0.7,
            }}
            className="overflow-hidden"
          >
            {data.videoMobile && (
              <video
                src={data.videoMobile}
                autoPlay
                loop
                muted
                playsInline
                className="rounded-lg w-full overflow-hidden object-cover h-[342px] sm:hidden"
              />
            )}

            {data.videoTablet && (
              <video
                src={data.videoTablet}
                autoPlay
                loop
                muted
                playsInline
                className="rounded-lg w-full overflow-hidden object-cover h-[342px] hidden sm:block lg:hidden"
              />
            )}

            {data.videoDesktop && (
              <video
                src={data.videoDesktop}
                autoPlay
                loop
                muted
                playsInline
                className="rounded-lg w-full overflow-hidden object-cover h-[550px] hidden lg:block xl:max-w-[1260px] xl:mx-auto"
              />
            )}
          </motion.div>
        </>
      ) : (
        <>
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{
              duration: 0.7,
            }}
            className="overflow-hidden"
          >
            {data.imageMobile && (
              <BuilderImage
                src={data.imageMobile}
                width={342}
                height={342}
                alt="media"
                className="rounded-lg overflow-hidden w-full object-cover sm:hidden"
                priority
              />
            )}

            {data.imageTablet && (
              <BuilderImage
                src={data.imageTablet}
                width={648}
                height={342}
                alt="media"
                className="rounded-lg overflow-hidden w-full object-cover hidden sm:block lg:hidden"
                priority
              />
            )}

            {data.imageDesktop && (
              <BuilderImage
                src={data.imageDesktop}
                width={1260}
                height={550}
                alt="media"
                className="rounded-lg overflow-hidden w-full object-cover hidden lg:block xl:max-w-[1260px] xl:mx-auto"
                priority
              />
            )}
          </motion.div>
        </>
      )}
    </div>
  );
};

export default NameOriginHeroMedia;

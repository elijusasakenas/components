/**
 * Represents a media component with color and brightness selectors.
 * @component
 * @param {Object} props - The component props.
 * @param {string} props.image - The image source URL.
 * @returns {JSX.Element} The rendered media component.
 */
import { useEffect, useRef } from "react";
import { motion } from "framer-motion";
import "./styles.scss";
import BuilderImage from "@/components/BuilderImage";

const Media = ({ image, defaultColor, defaultBrightness }) => {
  const colorSlider = useRef(null);
  const colorSliderBg = useRef(null);
  const brightnessSlider = useRef(null);
  const imageContainer = useRef(null);

  useEffect(() => {
    const updateBackgroundColor = () => {
      const color = colorSlider.current.value;
      const brightness = brightnessSlider.current.value;
      const adjustedBrightness = (100 - brightness) * 2;
      const bgColor = `hsl(${color}, 100%, ${adjustedBrightness / 2}%)`;

      imageContainer.current.style.backgroundColor = bgColor;

      updateSliders(color, bgColor);
    };

    const updateSliders = (color, bgColor) => {
      colorSlider.current.style.background = `linear-gradient(to right, 
        hsl(0, 100%, 50%), 
        hsl(60, 100%, 50%), 
        hsl(115, 100%, 50%), 
        hsl(180, 100%, 50%), 
        hsl(240, 100%, 50%),
        hsl(300, 100%, 50%))`;

      colorSlider.current.style.setProperty(
        "--SliderColor",
        `hsl(${color}, 100%, 50%)`
      );
      //colorSliderBg.current.style.setProperty("--SliderColor", bgColor);

      brightnessSlider.current.style.background = `linear-gradient(to right, white, hsl(${color}, 100%, 50%), black)`;

      brightnessSlider.current.style.setProperty("--SliderColor", bgColor);
    };

    updateBackgroundColor();

    colorSlider.current.addEventListener("input", updateBackgroundColor);
    brightnessSlider.current.addEventListener("input", updateBackgroundColor);
  }, []);

  return (
    <div className="color-selector overflow-hidden relative py-6 max-w-4xl mx-auto ">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7 }}
        className="-mx-10 lg:mx-auto relative z-10 max-w-[1067px] max-h-[598px]"
      >
        <div ref={imageContainer} className="">
          <BuilderImage
            src={image}
            width={1067}
            height={600}
            alt="media"
            className="w-full object-contain"
          />
        </div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7, delay: 0.2 }}
        className="w-full relative py-8 md:pb-16 color-selector-bg"
        ref={colorSliderBg}
      >
        <div className="mb-4 mx-6 relative z-10 lg:max-w-[700px] lg:mx-auto">
          <input
            type="range"
            min="0"
            max="300"
            defaultValue={defaultColor || 33}
            ref={colorSlider}
            className="w-full h-4 rounded-xl ring ring-base-500/50 shadow-md appearance-none"
          />
        </div>

        <div className="mb-8 mx-6 relative z-10 lg:max-w-[700px] lg:mx-auto">
          <input
            type="range"
            min="0"
            max="100"
            defaultValue={defaultBrightness || 50}
            ref={brightnessSlider}
            className="w-full h-4 rounded-xl border border-base-400 shadow-md appearance-none"
          />
        </div>
      </motion.div>
    </div>
  );
};

export default Media;

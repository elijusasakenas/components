import Title from "@/components/BuilderIo/Feature/ColorSelector/Title";
import Media from "@/components/BuilderIo/Feature/ColorSelector/Media";

/**
 * Component for rendering a color selector.
 * @component
 */
const FeatureColorSelector = ({
  title,
  subtitle,
  image,
  defaultColor,
  defaultBrightness,
}) => {
  return (
    <div className="max-w-7xl mx-auto w-full relative">
      <Title title={title} subtitle={subtitle} />
      <Media
        image={image}
        defaultColor={defaultColor}
        defaultBrightness={defaultBrightness}
      />
    </div>
  );
};

export default FeatureColorSelector;

/**
 *
 * @module ColorSelector.builder
 * @description Builder configuration for the FeatureColorSelector component.
 */

/**
 * Registers the FeatureColorSelector component with Builder.
 *
 * @function
 * @name registerComponent
 * @memberof module:ColorSelector.builder
 * @param {React.Component} component - The FeatureColorSelector component.
 * @param {Object} options - The options for registering the component.
 * @param {string} options.name - The name of the component.
 * @param {string} options.friendlyName - The friendly name of the component.
 * @param {Array} options.inputs - The inputs for the component.
 */
import { Builder } from "@builder.io/react";
import FeatureColorSelector from "@/components/BuilderIo/Feature/ColorSelector/ColorSelector";

Builder.registerComponent(FeatureColorSelector, {
  name: 'FeatureColorSelector',
  friendlyName: 'Feature: Color Selector',
  screenshot: 'https://cdn.builder.io/api/v1/image/assets%2F90182f3615654f8c9be2b012f26cc6c0%2Faf03183706a24c458da44ffbeaa13996',
  
  inputs: [
    {
      name: "title",
      friendlyName: "Title",
      type: "string",
      defaultValue: "Title",
    },
    {
      name: 'subtitle',
      friendlyName: 'Subtitle',
      type: 'string',
      defaultValue: 'Subtitle',
    },
    {
      name: 'image',
      friendlyName: 'Bike Image',
      type: 'file',
      defaultValue: 'https://cdn.builder.io/api/v1/image/assets%2F90182f3615654f8c9be2b012f26cc6c0%2F44784ad5816f49778130b6c828682f83'
    },{
      name: 'defaultColor',
      friendlyName: 'Default Color',
      type: 'number',
      defaultValue: 33,
      min: 0,
      max: 300
    },{
      name: 'defaultBrightness',
      friendlyName: 'Default Brightness',
      type: 'number',
      defaultValue: 50,
      min: 0,
      max: 100
    }
  ]
});

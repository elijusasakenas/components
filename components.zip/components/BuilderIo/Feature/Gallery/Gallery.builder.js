import { Builder } from "@builder.io/react";
import FeatureGallery from "@/components/BuilderIo/Feature/Gallery/Gallery";

// Register Feature component
Builder.registerComponent(FeatureGallery, {
  name: "FeatureGallery",
  friendlyName: "Feature: Gallery",
  screenshot:
    "https://cdn.builder.io/api/v1/image/assets%2F90182f3615654f8c9be2b012f26cc6c0%2F78c79bb2ba5445738ac8a98e6d92289a",
  
  inputs: [
    {
      name: "title",
      friendlyName: "Title",
      type: "string",
      defaultValue: "Headline",
    },
    {
      name: "featuresList",
      friendlyName: "Features",
      type: "list",
      subFields: [
        {
          name: "image",
          friendlyName: "Image",
          type: "file",
          defaultValue: "https://placehold.co/300x525/131313/FFF@2x.png",
        },
        {
          name: "title",
          friendlyName: "Title",
          type: "string",
          defaultValue: "Ac odio eu nibh lorem bibendum donec. Tincidunt",
        },
      ],
    },
  ],
});

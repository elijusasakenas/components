import ListItem from "@/components/BuilderIo/Feature/Gallery/ListItem";
import "swiper/css";
import "swiper/css/navigation";
import { Navigation } from "swiper/modules";
import { Swiper, SwiperSlide } from "swiper/react";
import "./styles.scss";

const List = ({ items }) => {
  return (
    items &&
    items.length > 0 && (
      <div className="mb-32 pl-6 md:pl-12 xl:pl-0">
        <Swiper 
          slidesPerView={"auto"} 
          navigation={true}
          modules={[Navigation]}
          className="features-gallery-slider"
        >
          {items.map((item, index) => (
            <SwiperSlide key={index}>
              <ListItem data={item} />
            </SwiperSlide>
          ))}
        </Swiper>
      </div>
    )
  );
};

export default List;

import { motion } from "framer-motion";
import BuilderImage from "@/components/BuilderImage";

const ListItem = ({ data }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.7, delay: 0.2 }}>
      <div className={`relative h-full w-full max-w-[300px] lg:w-auto rounded-lg overflow-hidden`}>
        <div>
          <BuilderImage
            src={data.image}
            width={300}
            height={525}
            alt="Feature Bg Image"
            className="w-full object-cover h-[525px]"
          />
        </div>

        <div className="absolute bottom-0 inset-x-0 px-6 py-8 z-10">
          <div className="headline-medium text-white">{data.title}</div>
        </div>
      </div>
      </motion.div>
  );
};

export default ListItem;

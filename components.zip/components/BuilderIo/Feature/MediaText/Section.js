/**
 * Represents a section component with a title and text.
 * @param {Object} props - The properties object.
 * @param {string} props.title - The title of the section.
 * @param {string} props.text - The text content of the section.
 * @returns {JSX.Element} The rendered section component.
 */
const Section = ({ title, text }) => {
  return (
    <div className="px-6 md:px-12 lg:px-16 xl:px-0 xl:max-w-[830px] xl:mx-auto">
      <div className="display pt-12">{title}</div>
      <div
        className="pt-4 lg:pt-6 pb-8 lg:pb-20 body text-base-100 [&_strong]:text-base-50"
        dangerouslySetInnerHTML={{ __html: text }}
      />
    </div>
  );
};

export default Section;

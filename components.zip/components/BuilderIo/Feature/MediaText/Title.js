import { motion } from "framer-motion";

/**
 * Renders a title component with optional button.
 *
 * @param {Object} props - The component props.
 * @param {string} props.content - The title content.
 * @param {boolean} props.button - Whether to display a button.
 * @param {string} props.buttonText - The text for the button.
 * @param {string} props.buttonLink - The link for the button.
 * @returns {JSX.Element} The rendered title component.
 */
const Title = ({ content, button, buttonText, buttonLink }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.7 }}
      className="px-6 md:px-12 pt-14 pb-10 md:pb-14 lg:py-24 xl:px-0 xl:text-center xl:max-w-[830px] xl:mx-auto"
    >
      <div className="headline-large">{content}</div>
      {button && (
        <div className="xl:text-center mt-8 lg:mt-12">
          <button href={buttonLink} className="btn-primary btn-large">
            {buttonText}
          </button>
        </div>
      )}
    </motion.div>
  );
};

export default Title;

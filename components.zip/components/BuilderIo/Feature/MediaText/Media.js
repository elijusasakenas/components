import { motion } from "framer-motion";
import BuilderImage from "@/components/BuilderImage";

/**
 * Renders a media component based on the provided data.
 * @param {Object} data - The data object containing information about the media.
 * @returns {JSX.Element} The rendered media component.
 */
const Media = ({ data }) => {

  return (
    <div className="pt-12 pb-36">
      {data.type === "video" ? (
        data.video && (
          <video
            src={data.video}
            autoPlay
            loop
            muted
            playsInline
            className="w-full overflow-hidden object-cover h-[844px]"
          ></video>
        )
      ) : (
        <>
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{
              duration: 0.7,
              delay: 1
            }}
            className="overflow-hidden"
          >
            <BuilderImage
              src={data.imageMobile}
              width={390}
              height={844}
              alt="media"
              className="w-full object-cover sm:hidden"
            />

            <BuilderImage
              src={data.imageTablet}
              width={768}
              height={844}
              alt="media"
              className="w-full object-cover hidden sm:block xl:hidden"
            />

            <BuilderImage
              src={data.imageDesktop}
              width={1067}
              height={599}
              alt="media"
              className="w-full object-cover hidden xl:block xl:max-w-[1067px] xl:mx-auto"
            />
          </motion.div>
        </>
      )}
    </div>
  );
};

export default Media;

/**
 * Register the FeatureMediaText component with Builder.io.
 */
import { Builder } from "@builder.io/react";
import FeatureMediaText from "@/components/BuilderIo/Feature/MediaText/MediaText";

// Register FeatureMediaText component
Builder.registerComponent(FeatureMediaText, {
  name: "FeatureMediaText",
  friendlyName: "Feature: Media Text",
  screenshot: "https://cdn.builder.io/api/v1/image/assets%2F90182f3615654f8c9be2b012f26cc6c0%2F3da2f4309a3649f7a426290384b35929",
  
  inputs: [
    {
      name: "title",
      friendlyName: "Title",
      type: "string",
      defaultValue: "Title",
    },
    {
      name: 'button',
      friendlyName: 'Button',
      type: 'boolean',
    },
    {
      name: 'buttonText',
      friendlyName: 'Button Text',
      type: 'string',
      defaultValue: 'Button Text',
    },
    {
      name: 'buttonLink',
      friendlyName: 'Button Link',
      type: 'string',
      defaultValue: '#',
    },
    {
      name: "sections",
      friendlyName: "Sections",
      type: "list",
      subFields: [
        {
          name: "title",
          friendlyName: "Title",
          type: "string",
          defaultValue: "Title",
        },
        {
          name: "text",
          friendlyName: "Text",
          type: "richText",
          defaultValue: "Lorem ipsum dolor sit amet.",
        },
      ],
    },
    {
      name: "media",
      friendlyName: "Media",
      type: "object",
      defaultValue: {
        imageDesktop:
          "https://cdn.builder.io/api/v1/image/assets%2F90182f3615654f8c9be2b012f26cc6c0%2F069050b239f244a4bc29cd6caee356f0",
        imageTablet:
          "https://cdn.builder.io/api/v1/image/assets%2F90182f3615654f8c9be2b012f26cc6c0%2Fb3699ef978af4869a29f9f73ae30cd72",
        imageMobile:
          "https://cdn.builder.io/api/v1/image/assets%2F90182f3615654f8c9be2b012f26cc6c0%2F7f221d68019b462b9e72bfc6d8d3dfc7",
        type: "image",
      },
      subFields: [
        {
          name: "imageDesktop",
          friendlyName: "Image Desktop",
          type: "file",
        },
        {
          name: "imageTablet",
          friendlyName: "Image Tablet",
          type: "file",
        },
        {
          name: "imageMobile",
          friendlyName: "Image Mobile",
          type: "file",
        },
        {
          name: "video",
          friendlyName: "Video",
          type: "file",
        },
        {
          name: "type",
          friendlyName: "Type",
          type: "select",
          enum: [
            { label: "Image", value: "image" },
            { label: "Video", value: "video" },
          ],
        },
      ],
    },
  ],
});

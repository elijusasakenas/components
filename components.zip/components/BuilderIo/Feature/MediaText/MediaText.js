import Media from "@/components/BuilderIo/Feature/MediaText/Media";
import Section from "@/components/BuilderIo/Feature/MediaText/Section";
import Title from "@/components/BuilderIo/Feature/MediaText/Title";
import { motion } from "framer-motion";

/**
 * Represents a component for displaying media and text in a feature section.
 * @param {Object} props - The component props.
 * @param {string} props.title - The title of the feature.
 * @param {boolean} props.button - Indicates whether a button should be displayed.
 * @param {string} props.buttonText - The text to display on the button.
 * @param {string} props.buttonLink - The link to navigate to when the button is clicked.
 * @param {Array} props.sections - An array of sections to display.
 * @param {Object} props.media - The media to display.
 * @returns {JSX.Element} The rendered FeatureMediaText component.
 */

const FeatureMediaText = ({
  title,
  button,
  buttonText,
  buttonLink,
  sections,
  media,
}) => {
  return (
    <div className="max-w-7xl mx-auto w-full relative">
      <Title
        content={title}
        button={button}
        buttonText={buttonText}
        buttonLink={buttonLink}
      />

      {sections &&
        sections.map((section, index) => (
          <motion.div
            variants={section}
            key={index}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{
              duration: 0.7,
              delay: (index + 1) * 0.25,
            }}
          >
            <Section key={index} title={section.title} text={section.text} />
          </motion.div>
        ))}

      <Media data={media} />
    </div>
  );
};

export default FeatureMediaText;

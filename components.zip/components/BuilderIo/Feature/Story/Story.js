import List from "@/components/BuilderIo/Feature/Story/List";
import { useDispatch } from "react-redux";
import { setLogoEnabled } from "@/redux/header/logo";

/**
 * Renders the FeatureStory component.
 *
 * @param {Object} sliderSettings - The settings for the slider.
 * @param {Array} storyList - The list of stories.
 * @returns {JSX.Element} The rendered FeatureStory component.
 */
const FeatureStory = ({ sliderSettings, storyList }) => {
  const dispatch = useDispatch();
  dispatch(setLogoEnabled(false));
  
  return (
    <div className="bg-base-50">
      <div className="max-w-8xl mx-auto w-full relative lg:pt-20 lg:pb-28">
        <List sliderSettings={sliderSettings} items={storyList} />
      </div>
    </div>
  );
};

export default FeatureStory;

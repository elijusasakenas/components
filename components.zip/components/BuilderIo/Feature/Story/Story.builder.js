import { Builder } from "@builder.io/react";
import FeatureStory from "@/components/BuilderIo/Feature/Story/Story";

Builder.registerComponent(FeatureStory, {
  name: "FeatureStory",
  friendlyName: "Feature: Story",
  screenshot:
    "https://cdn.builder.io/api/v1/image/assets%2F90182f3615654f8c9be2b012f26cc6c0%2F803c5ba492614dd8801c609b4d806613",
  
  inputs: [
    {
      name: "sliderSettings",
      friendlyName: "Slider Einstellungen",
      type: "object",
      subFields: [
        {
          name: "autoplay",
          friendlyName: "Autoplay",
          type: "boolean",
          defaultValue: true,
        },
        {
          name: "delay",
          friendlyName: "Delay",
          type: "number",
          defaultValue: 5000,
        },
        {
          name: "pauseOnMouseEnter",
          friendlyName: "Pause on Mouse Enter",
          type: "boolean",
          defaultValue: true,
        },
        {
          name: "loop",
          friendlyName: "Loop",
          type: "boolean",
          defaultValue: true,
        },
      ],
    },
    {
      name: "storyList",
      friendlyName: "Stories",
      type: "list",
      subFields: [
        {
          name: "media",
          friendlyName: "Media",
          type: "object",
          defaultValue: {
            imageDesktop:
              "https://cdn.builder.io/api/v1/image/assets%2F90182f3615654f8c9be2b012f26cc6c0%2F069050b239f244a4bc29cd6caee356f0",
            imageTablet:
              "https://cdn.builder.io/api/v1/image/assets%2F90182f3615654f8c9be2b012f26cc6c0%2Fb3699ef978af4869a29f9f73ae30cd72",
            imageMobile:
              "https://cdn.builder.io/api/v1/image/assets%2F90182f3615654f8c9be2b012f26cc6c0%2F7f221d68019b462b9e72bfc6d8d3dfc7",
            type: "image",
          },
          subFields: [
            {
              name: "imageDesktop",
              friendlyName: "Image Desktop",
              type: "file",
            },
            {
              name: "imageTablet",
              friendlyName: "Image Tablet",
              type: "file",
            },
            {
              name: "imageMobile",
              friendlyName: "Image Mobile",
              type: "file",
            },
            {
              name: "video",
              friendlyName: "Video",
              type: "file",
            },
            {
              name: "type",
              friendlyName: "Type",
              type: "select",
              enum: [
                { label: "Image", value: "image" },
                { label: "Video", value: "video" },
              ],
            },
            {
              name: "mediaContent",
              friendlyName: "Media Content",
              type: "object",
              defaultValue: {
                headline: "Headline",
                text: "Lorem ipsum dolor sit amet.",
                button: true,
                buttonText: "Button Text",
                buttonLink: "#",
              },
              subFields: [
                {
                  name: "headline",
                  friendlyName: "Headline",
                  type: "string",
                },
                {
                  name: "text",
                  friendlyName: "Text",
                  type: "richText",
                },
                {
                  name: "button",
                  friendlyName: "Button",
                  type: "boolean",
                },
                {
                  name: "buttonText",
                  friendlyName: "Button Text",
                  type: "string",
                  defaultValue: "Button Text",
                },
                {
                  name: "buttonLink",
                  friendlyName: "Button Link",
                  type: "string",
                  defaultValue: "#",
                },
              ],
            },
          ],
        },
      ],
    },
  ],
});

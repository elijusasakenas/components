import BuilderImage from "@/components/BuilderImage";
import { motion } from "framer-motion";
import Link from "next/link";

/**
 * Renders a list item component.
 *
 * @param {Object} props - The component props.
 * @param {Object} props.data - The data for the list item.
 * @param {boolean} props.active - Indicates if the list item is active.
 * @returns {JSX.Element} The rendered list item component.
 */
const ListItem = ({ data, active }) => {
  return (
    <div className="relative w-full h-screen lg:h-auto lg:w-auto">
      {data.type === "video" ? (
        data.video && (
          <video
            src={data.video}
            autoPlay
            loop
            muted
            playsInline
            className="w-full overflow-hidden object-cover lg:max-w-[390px] h-[693px] rounded-lg"
          ></video>
        )
      ) : (
        <>
          <div className={`overflow-hidden transition-all w-full h-full`}>
            {data.imageMobile && (
              <BuilderImage
                src={data.imageMobile}
                width={390}
                height={844}
                alt="media"
                className="w-full h-full object-cover sm:hidden"
              />
            )}

            {data.imageTablet && (
              <BuilderImage
                src={data.imageTablet}
                width={768}
                height={844}
                alt="media"
                className="w-full h-full object-cover hidden sm:block lg:hidden"
              />
            )}

            <BuilderImage
              src={data.imageDesktop}
              width={390}
              height={844}
              alt="media"
              className={`w-full object-cover rounded-lg overflow-hidden lg:w-[390px] h-full mx-auto ${
                active ? "opacity-100" : "opacity-30"
              } ${
                data.imageMobile && data.imageTablet ? "hidden lg:block lg:h-[693px]" : ""
              } ${
                !data.imageMobile && data.imageTablet
                  ? "sm:hidden lg:block"
                  : ""
              }`}
            />
          </div>
        </>
      )}

      {data.mediaContent && (
        <div className="w-full absolute inset-x-0 bottom-0 px-6 pt-12 pb-24 lg:pb-12 text-white bg-content overflow-hidden">
          <div className="mx-auto lg:max-w-[830px]">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7 }}
              className="headline-medium mb-4 line-clamp-2"
            >
              {data.mediaContent.headline}
            </motion.div>
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.2 }}
              className="body"
              dangerouslySetInnerHTML={{ __html: data.mediaContent.text }}
            />

            {data.mediaContent?.button && (
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.7, delay: 0.2 }}
              >
                <Link
                  href={
                    data.mediaContent.buttonLink
                      ? data.mediaContent.buttonLink
                      : "/"
                  }
                  className="btn-primary mt-6"
                >
                  {data.mediaContent.buttonText}
                </Link>
              </motion.div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default ListItem;

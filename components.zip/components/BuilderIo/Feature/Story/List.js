"use client";

import ListItem from "@/components/BuilderIo/Feature/Story/ListItem";
import "swiper/css";
import "swiper/css/effect-coverflow";
import "swiper/css/navigation";
import { Swiper, SwiperSlide } from "swiper/react";
import "./styles.scss";

// import required modules
import { useEffect, useRef, useState } from "react";
import { Autoplay, EffectCoverflow, Navigation } from "swiper/modules";

/**
 * Renders a list of items with a progress bar and a swiper component.
 *
 * @param {Object} props - The component props.
 * @param {Array} props.items - The array of items to render.
 * @param {Object} props.sliderSettings - The settings for the swiper component.
 * @returns {JSX.Element|null} The rendered list component.
 */
const List = ({ items, sliderSettings }) => {
  const [settings, setSettings] = useState(
    {
      autoplay: true,
      delay: 5000,
      pauseOnMouseEnter: true,
      loop: true,
    }
  );
  const progressBar = useRef([]);
  const onAutoplayTimeLeft = (s, time, progress) => {
    // reset all progress bars
    if(!progressBar.current) return;
    progressBar.current.forEach((el, index) => {
      if(!el) return;
      if (index > s.realIndex) el.style.width = "0%";
      if (index < s.realIndex) el.style.width = "100%";
    });
    
    if(progressBar.current[s.realIndex])
      progressBar.current[s.realIndex].style.width = `${(1 - progress) * 100}%`;
  };

  const ProgressBar = ({ idx }) => (
    <div className="w-full h-1 bg-base-500/50 rounded overflow-hidden">
      <div
        className="bg-base-500 h-1 w-[1%]"
        ref={(el) => (progressBar.current[idx] = el)}
      />
    </div>
  );

  useEffect(() => {
    if (sliderSettings) {
      setSettings({
        autoplay: sliderSettings.autoplay,
        delay: sliderSettings.delay,
        pauseOnMouseEnter: sliderSettings.pauseOnMouseEnter,
        loop: sliderSettings.loop,
      });
    }
  }, [sliderSettings]);

  return (
    items &&
    items.length > 0 &&
    (
      <div className="w-full h-screen lg:h-auto">
        {settings.autoplay && (
          <div className="flex justify-center items-center gap-2 px-6 absolute inset-x-0 top-6 z-10 lg:max-w-[390px] lg:mx-auto lg:px-16 lg:top-auto lg:bottom-16">
            {items.map((item, index) => (
              <ProgressBar key={index} idx={index} />
            ))}
          </div>
        )}

        <Swiper
          effect={"coverflow"}
          coverflowEffect={{
            rotate: 0,
            depth: 200,
            modifier: 1,
            scale: 0.8,

            slideShadows: false,
          }}
          navigation={true}
          modules={[Navigation, Autoplay, EffectCoverflow]}
          autoplay={{
            enabled: settings.autoplay ? true : false,
            delay: settings.delay ? settings.delay : 5000,
            pauseOnMouseEnter: settings.pauseOnMouseEnter ? true : false,
          }}
          loop={settings.loop ? true : false}
          onAutoplayTimeLeft={onAutoplayTimeLeft}
          centeredSlides={true}
          slidesPerView={1}
          spaceBetween={0}
          breakpoints={{
            1024: {
              slidesPerView: 3,
              spaceBetween: 32,
            },
            1440: {
              slidesPerView: 3,
              spaceBetween: 32,
            },
          }}
          className="features-story-slider"
        >
          {items.map((item, index) => (
            
              <SwiperSlide key={index}>
                {({ isActive }) => (
                  <ListItem data={item.media} active={isActive} />
                )}
              </SwiperSlide>
            
          ))}
        </Swiper>
      </div>
    )
  );
};

export default List;

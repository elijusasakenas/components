import { motion } from "framer-motion";

function Title(props) {
  const spaceBottomClasses = getSpaceBottomClasses(props.spaceBottom);

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.7 }}
      className={`w-full text-base-50 ${props.type} ${spaceBottomClasses} ${
        props.centerOnDesktop && "xl:text-center"
      }`}
    >
      {props.text}
    </motion.div>
  );
}

export default Title;

const getSpaceBottomClasses = (spaceBottom) => {
  switch (spaceBottom) {
    case 'default':
      return 'mb-8 lg:mb-12';
    case 'small':
      return 'mb-4 lg:mb-6';
    case 'none':
      return 'mb-0';
    default:
      return '';
  }
}
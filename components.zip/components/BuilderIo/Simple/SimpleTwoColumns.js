import React from "react";
import { BuilderBlocks } from "@builder.io/react";

const SimpleTwoColumns = ({ ...props }) => {
  const widthClasses = getWidthClasses(props.width);
  const spaceClasses = getSpaceClasses(props.space);
  const spaceBottomClasses = getSpaceBottomClasses(props.spaceBottom);

  return (
    <div
      className={`mx-auto relative px-6 md:px-12 xl:px-0 ${widthClasses} ${spaceClasses} ${spaceBottomClasses}`}
    >
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <BuilderBlocks
          blocks={props.builderBlock.component.options.sectionLeft}
          parentElementId={props.builderBlock.id}
          dataPath="component.options.sectionLeft"
        />

        <BuilderBlocks
          blocks={props.builderBlock.component.options.sectionRight}
          parentElementId={props.builderBlock.id}
          dataPath={`component.options.sectionRight`}
        />
      </div>
    </div>
  );
};

export default SimpleTwoColumns;

const getWidthClasses = (width) => {
  switch (width) {
    case 'default':
      return 'w-full max-w-7xl';
    case 'narrow':
      return 'w-full xl:max-w-[830px]';
    case 'full':
      return 'w-full';
    default:
      return 'w-full max-w-7xl';
  }
}

const getSpaceClasses = (space) => {
  switch (space) {
    case 'default':
      return 'py-6 lg:py-12';
    case 'large':
      return 'py-14 lg:py-24';
    case 'none':
      return 'py-0';
    default:
      return 'py-14 lg:py-24';
  }
}

const getSpaceBottomClasses = (spaceBottom) => {
  switch (spaceBottom) {
    case 'default':
      return 'mb-8 lg:mb-12';
    case 'small':
      return 'mb-4';
    case 'none':
      return 'mb-0';
    default:
      return 'mb-8 lg:mb-12';
  }
}
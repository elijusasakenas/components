import { Builder } from "@builder.io/react";
import SimpleTitle from "@/components/BuilderIo/Simple/SimpleTitle";
import SimpleText from "@/components/BuilderIo/Simple/SimpleText";
import SimpleImage from "@/components/BuilderIo/Simple/SimpleImage";
import SimpleButton from "@/components/BuilderIo/Simple/SimpleButton";
import SimpleContent from "@/components/BuilderIo/Simple/SimpleContent";
import SimpleTwoColumns from "@/components/BuilderIo/Simple/SimpleTwoColumns";

Builder.registerComponent(SimpleTitle, {
  name: "SimpleTitle",
  requiresParent: {
    message:
      "First, insert a Simple Content component. You can then add the component to this.",
    query: {
      "component.name": { $in: ["SimpleContent", "SimpleTwoColumns"] },
    },
  },

  inputs: [
    {
      name: "text",
      friendlyName: "Title",
      type: "string",
      defaultValue: "Title",
    },
    {
      name: "type",
      friendlyName: "Type",
      type: "select",
      defaultValue: "headline-large",
      enum: [
        { label: "Large", value: "headline-large" },
        { label: "Medium", value: "headline-medium" },
        { label: "Small", value: "headline-small" },
      ],
    },
    {
      name: "spaceBottom",
      friendlyName: "Space bottom",
      type: "select",
      defaultValue: "default",
      enum: [
        { label: "Standard", value: "default" },
        { label: "Small", value: "small" },
        { label: "None", value: "none" },
      ],
    },
    {
      name: "centerOnDesktop",
      friendlyName: "Center on desktop",
      type: "boolean",
      defaultValue: false,
    },
  ],
});

Builder.registerComponent(SimpleText, {
  name: "SimpleText",
  requiresParent: {
    message:
      "First, insert a Simple Content component. You can then add the component to this.",
    query: {
      "component.name": { $in: ["SimpleContent", "SimpleTwoColumns"] },
    },
  },
  inputs: [
    {
      name: "text",
      type: "richText",
      defaultValue: "Text",
    },
    {
      name: "type",
      type: "select",
      defaultValue: "default",
      enum: [
        { label: "Default", value: "body" },
        { label: "Emphasis", value: "body-emphasis" },
        { label: "Small", value: "body-small" },
        { label: "Small Emphasis", value: "body-small-emphasis" },
        { label: "Extra Small", value: "body-extra-small" },
        { label: "Extra Small Emphasis", value: "body-extra-small-emphasis" },
      ],
    },
    {
      name: "space",
      friendlyName: "Space",
      type: "select",
      defaultValue: "default",
      enum: [
        { label: "Standard", value: "default" },
        { label: "Large", value: "large" },
        { label: "With button", value: "withButton" },
        { label: "None", value: "none" },
      ],
    },
    {
      name: "spaceBottom",
      friendlyName: "Space bottom",
      type: "select",
      defaultValue: "default",
      enum: [
        { label: "Standard", value: "default" },
        { label: "Small", value: "small" },
        { label: "None", value: "none" },
        { label: "Unset", value: "unset" },
      ],
    },
  ],
});

Builder.registerComponent(SimpleImage, {
  name: "SimpleImage",
  requiresParent: {
    message:
      "First, insert a Simple Content component. You can then add the component to this.",
    query: {
      "component.name": { $in: ["SimpleContent", "SimpleTwoColumns"] },
    },
  },
  inputs: [
    {
      name: "desktop",
      friendlyName: "Desktop",
      type: "object",
      defaultValue: {
        type: "image",
        image: "https://cdn.builder.io/api/v1/image/assets%2F1f5b8f3f6f0f4f3b8b6f2e8f4c7b0b7d%2Ff1b5b7f2e8f4c7b0b7d",
      },
      subFields: [
        {
          name: "type",
          friendlyName: "Type",
          type: "select",
          enum: [
            { label: "Image", value: "image" },
            { label: "Video", value: "video" },
          ],
        },
        {
          name: "image",
          friendlyName: "Image",
          type: "file",
          showIf: `options.get('type') === 'image'`,
        },
        {
          name: "video",
          friendlyName: "Video",
          type: "file",
          showIf: `options.get('type') === 'video'`,
        },
      ],
    },

    {
      name: "tablet",
      friendlyName: "Tablet",
      type: "object",
      subFields: [
        {
          name: "type",
          friendlyName: "Type",
          type: "select",
          enum: [
            { label: "Image", value: "image" },
            { label: "Video", value: "video" },
          ],
        },
        {
          name: "image",
          friendlyName: "Image",
          type: "file",
          showIf: `options.get('type') === 'image'`,
        },
        {
          name: "video",
          friendlyName: "Video",
          type: "file",
          showIf: `options.get('type') === 'video'`,
        },
      ],
    },

    {
      name: "mobile",
      friendlyName: "Mobile",
      type: "object",
      subFields: [
        {
          name: "type",
          friendlyName: "Type",
          type: "select",
          enum: [
            { label: "Image", value: "image" },
            { label: "Video", value: "video" },
          ],
        },
        {
          name: "image",
          friendlyName: "Image",
          type: "file",
          showIf: `options.get('type') === 'image'`,
        },
        {
          name: "video",
          friendlyName: "Video",
          type: "file",
          showIf: `options.get('type') === 'video'`,
        },
      ],
    },

    {
      name: "spaceTop",
      friendlyName: "Space Top",
      type: "select",
      defaultValue: "default",
      enum: [
        { label: "Standard", value: "default" },
        { label: "Large", value: "large" },
        { label: "None", value: "none" },
      ],
    },

    {
      name: "spaceBottom",
      friendlyName: "Space bottom",
      type: "select",
      defaultValue: "default",
      enum: [
        { label: "Standard", value: "default" },
        { label: "Large", value: "large" },
        { label: "None", value: "none" },
      ],
    },

    {
      name: "image",
      friendlyName: "Old-Image (Please remove)",
      type: "file",
      defaultValue: "https://placehold.co/1440x960/131313/FFF@2x.png",
    },
  ],
});

Builder.registerComponent(SimpleButton, {
  name: "SimpleButton",
  requiresParent: {
    message:
      "First, insert a Simple Content component. You can then add the component to this.",
    query: {
      "component.name": { $in: ["SimpleContent", "SimpleTwoColumns"] },
    },
  },
  inputs: [
    {
      name: "text",
      friendlyName: "Button text",
      type: "string",
      defaultValue: "Button",
    },
    {
      name: "href",
      friendlyName: "Button link",
      type: "string",
      defaultValue: "/",
    },
    {
      name: "newTab",
      friendlyName: "Open in new tab",
      type: "boolean",
      defaultValue: false,
    },
    {
      name: "type",
      friendlyName: "Type",
      type: "select",
      defaultValue: "btn-primary",
      enum: [
        { label: "Primary", value: "btn-primary" },
        { label: "Secondary", value: "btn-secondary" },
      ],
    },
    {
      name: "size",
      friendlyName: "Size",
      type: "select",
      enum: [
        { label: "Default", value: "btn" },
        { label: "Large", value: "btn-large" },
        { label: "Small", value: "btn-small" },
      ],
    },
    {
      name: "fullWidth",
      friendlyName: "Full width",
      type: "boolean",
      defaultValue: false,
    },
    {
      name: "centerOnDesktop",
      friendlyName: "Center on desktop",
      type: "boolean",
      defaultValue: false,
    },
  ],
});

Builder.registerComponent(SimpleContent, {
  name: "SimpleContent",
  screenshot:
    "https://cdn.builder.io/api/v1/image/assets%2F90182f3615654f8c9be2b012f26cc6c0%2F297119b7da6f4f8aa17b631b2377373d",
  canHaveChildren: true,
  inputs: [
    {
      name: "width",
      friendlyName: "Width",
      type: "select",
      defaultValue: "default",
      enum: [
        { label: "Standard", value: "default" },
        { label: "Narrow", value: "narrow" },
        { label: "Full", value: "full" },
      ],
    },
    {
      name: "space",
      friendlyName: "Space",
      type: "select",
      defaultValue: "default",
      enum: [
        { label: "Standard", value: "default" },
        { label: "Large", value: "large" },
        { label: "None", value: "none" },
      ],
    },
    {
      name: "spaceBottom",
      friendlyName: "Space bottom",
      type: "select",
      defaultValue: "default",
      enum: [
        { label: "Standard", value: "default" },
        { label: "Small", value: "small" },
        { label: "None", value: "none" },
      ],
    },
  ],
  defaultChildren: [
    {
      "@type": "@builder.io/sdk:Element",
      component: {
        name: "SimpleTitle",
        options: {
          text: "Hello, world!",
          type: "headline-large",
        },
      },
    },
  ],
  childRequirements: {
    message: "Add a simple component",
    query: {
      "component.name": {
        $in: ["SimpleTitle", "SimpleText", "SimpleImage", "SimpleButton"],
      },
    },
  },
});

Builder.registerComponent(SimpleTwoColumns, {
  name: "SimpleTwoColumns",
  canHaveChildren: true,
  childRequirements: {
    message: "Add a simple component",
    query: {
      "component.name": {
        $in: ["SimpleTitle", "SimpleText", "SimpleImage", "SimpleButton"],
      },
    },
  },
  inputs: [
    {
      name: "sectionLeft",
      type: "uiBlocks",
      hideFromUI: true,
      helperText: "This is an editable region.",
      defaultValue: [],
    },
    {
      name: "sectionRight",
      type: "uiBlocks",
      hideFromUI: true,
      helperText: "This is an editable region.",
      defaultValue: [],
    },
    {
      name: "width",
      friendlyName: "Width",
      type: "select",
      defaultValue: "default",
      enum: [
        { label: "Standard", value: "default" },
        { label: "Narrow", value: "narrow" },
        { label: "Full", value: "full" },
      ],
    },
    {
      name: "space",
      friendlyName: "Space",
      type: "select",
      defaultValue: "default",
      enum: [
        { label: "Standard", value: "default" },
        { label: "Large", value: "large" },
        { label: "None", value: "none" },
      ],
    },
    {
      name: "spaceBottom",
      friendlyName: "Space bottom",
      type: "select",
      defaultValue: "default",
      enum: [
        { label: "Standard", value: "default" },
        { label: "Small", value: "small" },
        { label: "None", value: "none" },
      ],
    },
  ],
});

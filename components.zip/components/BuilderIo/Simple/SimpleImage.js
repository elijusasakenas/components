import { motion } from "framer-motion";
import BuilderImage from "@/components/BuilderImage";

function SimpleImage(props) {
  const spaceTopClasses = getSpaceTopClasses(props.spaceTop);
  const spaceBottomClasses = getSpaceBottomClasses(props.spaceBottom);

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.7 }}
      className={`w-full ${spaceTopClasses} ${spaceBottomClasses}`}
    >
      {props.desktop && (
        props.desktop.type === "image" && (
          <Image src={props.desktop.image} alt="Desktop Image" viewport="desktop" />
        ) || props.desktop.type === "video" && (
          <Video src={props.desktop.video} alt="Desktop Video" viewport="desktop" />
        )
      )}

      {props.tablet && (
        props.tablet.type === "image" && (
          <Image src={props.tablet.image} alt="Tablet Image" viewport="tablet" />
        ) || props.tablet.type === "video" && (
          <Video src={props.tablet.video} alt="Tablet Video" viewport="tablet" />
        )
      )}

      {props.mobile && (
        props.mobile.type === "image" && (
          <Image src={props.mobile.image} alt="Mobile Image" viewport="mobile" />
        ) || props.mobile.type === "video" && (
          <Video src={props.mobile.video} alt="Mobile Video" viewport="mobile" />
        )
      )}
    </motion.div>
  );
}

export default SimpleImage;

const Image = ({ src, viewport }) => {
  if (viewport === "mobile") {
    return (
      <BuilderImage
        src={src}
        alt={"Image"}
        className="w-full h-auto object-contain sm:hidden"
        width={1440}
        height={960}
      />
    );
  }

  if (viewport === "tablet") {
    return (
      <BuilderImage
        src={src}
        alt={"Image"}
        className="w-full h-auto object-contain hidden sm:block xl:hidden"
        width={1440}
        height={960}
      />
    );
  }

  if (viewport === "desktop") {
    return (
      <BuilderImage
        src={src}
        alt={"Image"}
        className="w-full h-auto object-contain hidden xl:block"
        width={1440}
        height={960}
      />
    );
  }
};

const Video = ({ src, viewport }) => {
  if (viewport === "mobile") {
    return (
      <video
        src={src}
        autoPlay
        loop
        muted
        playsInline
        className="w-full h-auto object-contain sm:hidden"
      ></video>
    );
  }

  if (viewport === "tablet") {
    return (
      <video
        src={src}
        autoPlay
        loop
        muted
        playsInline
        className="w-full h-auto object-contain hidden sm:block xl:hidden"
      ></video>
    );
  }

  if (viewport === "desktop") {
    return (
      <video
        src={src}
        autoPlay
        loop
        muted
        playsInline
        className="w-full h-auto object-contain hidden xl:block"
      ></video>
    );
  }
}

const getSpaceTopClasses = (space) => {
  switch (space) {
    case 'default':
      return 'pt-4 lg:pt-6';
    case 'large':
      return 'pt-10 lg:pt-14';
    case 'none':
      return 'pt-0';
    default:
      return '';
  }
}

const getSpaceBottomClasses = (space) => {
  switch (space) {
    case 'default':
      return 'pb-4 lg:pb-6';
    case 'large':
      return 'pb-10 lg:pb-14';
    case 'none':
      return 'pb-0';
    default:
      return '';
  }
}
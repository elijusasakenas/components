import Link from "next/link";
import { motion } from "framer-motion";

const SimpleButton = (props) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.7 }}
      className={`w-full ${props.centerOnDesktop && "xl:text-center"}`}
    >
      <Link
        href={props.href}
        target={`${props.newTab ? "_blank" : "_self"}`}
        className={`${props.type} ${props.size} ${
          props.fullWidth ? "w-full" : ""
        }`}
      >
        {props.text}
      </Link>
    </motion.div>
  );
};

export default SimpleButton;

import { motion } from "framer-motion";

function SimpleText(props) {
  const spaceClasses = getSpaceClasses(props.space);
  const spaceBottomClasses = getSpaceBottomClasses(props.spaceBottom);

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.7 }}
      className={`w-full text-base-50 ${props.type} ${spaceClasses} ${spaceBottomClasses}`}
      dangerouslySetInnerHTML={{ __html: props.text }}
    />
  );
}

export default SimpleText;

const getSpaceClasses = (space) => {
  switch (space) {
    case 'default':
      return 'mt-4 lg:mt-6 mb-6 md:mb-12 lg:mb-16';
    case 'large':
      return 'mt-10 mb-14 lg:mt-14 lg:mb-16';
    case 'withButton':
      return 'mt-10 mb-6 lg:mt-14';
    case 'none':
      return 'mt-0 mb-0';
    default:
      return '';
  }
}

const getSpaceBottomClasses = (spaceBottom) => {
  switch (spaceBottom) {
    case 'default':
      return '!mb-6 md:!mb-12 lg:!mb-16';
    case 'small':
      return '!mb-4 md:!mb-8 lg:!mb-12';
    case 'none':
      return '!mb-0';
    case 'unset':
      return '';
    default:
      return '';
  }
}
import { BuilderBlocks } from "@builder.io/react";

const SimpleContent = ({...props}) => {
  const widthClasses = getWidthClasses(props.width);
  const spaceClasses = getSpaceClasses(props.space);
  const spaceBottomClasses = getSpaceBottomClasses(props.spaceBottom);

  return (
    <div className={`mx-auto relative px-6 md:px-12 xl:px-4 ${widthClasses} ${spaceClasses} ${spaceBottomClasses}`}>
      <BuilderBlocks blocks={props.builderBlock.children} parentElementId={props.builderBlock.id} dataPath="children" />
    </div>
  );
}

export default SimpleContent;

const getWidthClasses = (width) => {
  switch (width) {
    case 'default':
      return 'w-full max-w-7xl';
    case 'narrow':
      return 'w-full xl:max-w-[830px]';
    case 'full':
      return 'w-full';
    default:
      return 'w-full max-w-7xl';
  }
}

const getSpaceClasses = (space) => {
  switch (space) {
    case 'default':
      return 'py-6 lg:py-12';
    case 'large':
      return 'py-14 lg:py-24';
    case 'none':
      return 'py-0';
    default:
      return 'py-14 lg:py-24';
  }
}

const getSpaceBottomClasses = (spaceBottom) => {
  switch (spaceBottom) {
    case 'default':
      return 'mb-8 lg:mb-12';
    case 'small':
      return 'mb-4';
    case 'none':
      return 'mb-0';
    default:
      return 'mb-8 lg:mb-12';
  }
}
import { motion, useScroll, useTransform, easeInOut } from "framer-motion";
import useScreenSize from "@/utility/useScreenSize";
import BuilderImage from "@/components/BuilderImage";

const MediaText = ({ containerRef, data, content }) => {
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start start", "end start"],
  });

  const screenSize = useScreenSize();
  let translateXValue = '0%';
  if (screenSize.width >= 1440) {
    translateXValue = '0%';
  }

  let translateX = useTransform(scrollYProgress, [0, 0.1], ["-100%", translateXValue], {
    ease: easeInOut,
  });
  let scale = useTransform(scrollYProgress, [0, 0.1], [0.3, 1], {
    ease: easeInOut,
  });

  let translateYContentValue = 200;
  if (screenSize.width >= 768) {
    translateYContentValue = 250;
  }
  if (screenSize.width >= 1440) {
    translateYContentValue = 300;
  }

  const opacity = useTransform(scrollYProgress, [0, 0.1], [0, 1]);
  const translateYContent = useTransform(
    scrollYProgress,
    [0, 0.1],
    [translateYContentValue, 0],
    { ease: easeInOut }
  );

  return (
    <motion.div
      style={
        {
          translateX: translateX,
          scale: scale,
        }
      }
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.7 }}
      className="h-screen w-full absolute bottom-0 overflow-hidden xl:h-auto xl:max-h-[886px]"
    >
      <BuilderImage
        src={data.imageMobile}
        width={390}
        height={844}
        alt="media content mobile"
        className="w-full object-cover md:hidden"
        priority
      />

      <BuilderImage
        src={data.imageTablet}
        width={768}
        height={1024}
        alt="media content tablet"
        className="w-full object-cover hidden md:block xl:hidden"
        priority
      />

      <BuilderImage
        src={data.imageDesktop}
        width={1260}
        height={844}
        alt="media content desktop"
        className="w-full object-cover hidden xl:block"
        priority
      />

      {content && (
        <motion.div
          className="w-auto absolute inset-x-0 bottom-0 px-6 md:px-16 pt-12 pb-40 lg:pb-24 text-white bg-content overflow-hidden"
          style={{
            opacity: opacity,
            translateY: translateYContent,
          }}
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7 }}
        >
          <div className="mx-auto lg:max-w-[830px]">
            <div className="headline-medium mb-4 line-clamp-2">
              {content.headline}
            </div>
            <div
              className="body"
              dangerouslySetInnerHTML={{ __html: content.text }}
            />

            {content?.button && (
              <button href={content.buttonLink} className="btn-primary mt-6">
                {content.buttonText}
              </button>
            )}
          </div>
        </motion.div>
      )}
    </motion.div>
  );
};

export default MediaText;

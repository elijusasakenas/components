import { Builder } from "@builder.io/react";
import TextProductMotifFront from "@/components/BuilderIo/TextProductMotif/Front/Front";

Builder.registerComponent(TextProductMotifFront, {
  name: "TextProductMotifFront",
  screenshot: 'https://cdn.builder.io/api/v1/image/assets%2F90182f3615654f8c9be2b012f26cc6c0%2Fd362da05eeee437bb11afda7aaa3b4c6',
  
  inputs: [
    {
      name: "bgColor",
      friendlyName: "Background Color",
      type: "select",
      defaultValue: "white",
      enum: [
        { label: "Weiß", value: "white" },
        { label: "Hellgrau", value: "lightGrey" },
        { label: "Grau Blau", value: "greyBlue" },
        { label: "Blau", value: "blue" },
        { label: "Grün", value: "green" },
        { label: "Orange", value: "orange" },
        { label: "Dunkel", value: "dark" },
      ],
    },
    {
      name: "title",
      friendlyName: "Title",
      type: "string",
      defaultValue: "Title",
    },
    {
      name: "text",
      friendlyName: "Text",
      type: "string",
      defaultValue: "Lorem ipsum dolor sit amet.",
    },
    {
      name: "image",
      friendlyName: "Image",
      type: "file",
      defaultValue: "https://cdn.builder.io/api/v1/image/assets%2F90182f3615654f8c9be2b012f26cc6c0%2F05a2d3c2fae4455f81975dbe3e4ba297"
    },
    {
      name: "media",
      friendlyName: "Media",
      type: "object",
      defaultValue: {
        imageDesktop: "https://placehold.co/1440x886@2x.png",
        imageTablet: "https://placehold.co/720x1133@2x.png",
        imageMobile: "https://placehold.co/390x844@2x.png",
      },
      subFields: [
        {
          name: "imageDesktop",
          friendlyName: "Image Desktop",
          type: "file",
        },
        {
          name: "imageTablet",
          friendlyName: "Image Tablet",
          type: "file",
        },
        {
          name: "imageMobile",
          friendlyName: "Image Mobile",
          type: "file",
        },
      ],
    },
    {
      name: "mediaContent",
      friendlyName: "Media Content",
      type: "object",
      subFields: [
        {
          name: "headline",
          friendlyName: "Headline",
          type: "string",
        },
        {
          name: "text",
          friendlyName: "Text",
          type: "richText",
        },
        {
          name: "button",
          friendlyName: "Button",
          type: "boolean",
        },
        {
          name: "buttonText",
          friendlyName: "Button Text",
          type: "string",
          defaultValue: "Button Text",
        },
        {
          name: "buttonLink",
          friendlyName: "Button Link",
          type: "string",
          defaultValue: "#",
        },
      ],
    },
  ]
})
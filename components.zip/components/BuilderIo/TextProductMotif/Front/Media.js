import { motion, useScroll, useTransform } from "framer-motion";
import BuilderImage from "@/components/BuilderImage";

const Media = ({ image, containerRef }) => {
  
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start start", "end start"],
  });

  const opacity = useTransform(scrollYProgress, [0, 0.1], [1, 0]);
  const translateY = useTransform(scrollYProgress, [0, 0.5], ["0%", "-200%"]);

  return (
      <motion.div 
        style={{ translateY: translateY, opacity: opacity }}
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7 }}
        className={`media w-full relative overflow-hidden h-[446px] md:h-[596px]`}
      >
        <BuilderImage
          src={image}
          width={390}
          height={446}
          alt="media mobile"
          className={`h-full w-auto object-cover object-top md:hidden`}
          priority
        />

        <BuilderImage
          src={image}
          width={768}
          height={844}
          alt="media tablet"
          className="h-full w-auto object-cover object-top hidden md:block lg:hidden"
          priority
        />

        <BuilderImage
          src={image}
          width={1340}
          height={650}
          alt="media desktop"
          className="w-auto mx-auto object-contain object-top hidden lg:block h-[650px]"
          priority
        />
      </motion.div>
    
  );
};

export default Media;

import { motion, useScroll, useTransform, easeInOut } from "framer-motion";
import useScreenSize from "@/utility/useScreenSize";

const Content = ({ containerRef, content }) => {
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start start", "end start"],
  });

  const screenSize = useScreenSize();
  let translateYContentValue = '15%';

  if (screenSize.width >= 1440) {
    translateYContentValue = '25%';
  }

  const opacity = useTransform(scrollYProgress, [0, 0.1], [0, 1]);
  const translateYContent = useTransform(
    scrollYProgress,
    [0, 0.1],
    ['25%', translateYContentValue]
  );

  return (
    content &&
    <motion.div
      className="w-auto absolute z-10 inset-0 xl:bottom-0 px-6 md:px-16 pt-12 pb-40 overflow-hidden"
      style={{
        opacity: opacity,
        translateY: translateYContent,
      }}
    >
      <div className="mx-auto lg:max-w-[830px]">
        <div className="headline-medium mb-4 line-clamp-2">
          {content.headline}
        </div>
        <div
          className="body"
          dangerouslySetInnerHTML={{ __html: content.text }}
        />

        {content?.button && (
          <button href={content.buttonLink} className="btn-primary mt-6">
            {content.buttonText}
          </button>
        )}
      </div>
    </motion.div>
  );
};

export default Content;

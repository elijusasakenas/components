import { Builder } from "@builder.io/react";
import TextProductMotifProfile from "@/components/BuilderIo/TextProductMotif/Profile/Profile";

Builder.registerComponent(TextProductMotifProfile, {
  name: "TextProductMotifProfile",
  screenshot: 'https://cdn.builder.io/api/v1/image/assets%2F90182f3615654f8c9be2b012f26cc6c0%2F045cb368b71645beb63e59522d29bb26',
  
  inputs: [
    {
      name: "bgColor",
      friendlyName: "Hintergrundfarbe",
      type: "select",
      defaultValue: "white",
      enum: [
        { label: "Weiß", value: "white" },
        { label: "Hellgrau", value: "lightGrey" },
        { label: "Grau Blau", value: "greyBlue" },
        { label: "Blau", value: "blue" },
        { label: "Grün", value: "green" },
        { label: "Orange", value: "orange" },
        { label: "Dunkel", value: "dark" },
      ],
    },
    {
      name: "title",
      friendlyName: "Title",
      type: "string",
      defaultValue: "Title",
    },
    {
      name: "text",
      friendlyName: "Text",
      type: "string",
      defaultValue: "Lorem ipsum dolor sit amet.",
    },
    {
      name: "image",
      friendlyName: "Image",
      type: "file",
      defaultValue: "https://cdn.builder.io/api/v1/image/assets%2F90182f3615654f8c9be2b012f26cc6c0%2F7b2dfd5ca41b4e4cb1e123f34a1f1626"
    },
    {
      name: "content",
      friendlyName: "Content",
      type: "object",
      subFields: [
        {
          name: "headline",
          friendlyName: "Headline",
          type: "string",
        },
        {
          name: "text",
          friendlyName: "Text",
          type: "richText",
        },
        {
          name: "button",
          friendlyName: "Button",
          type: "boolean",
        },
        {
          name: "buttonText",
          friendlyName: "Button Text",
          type: "string",
          defaultValue: "Button Text",
        },
        {
          name: "buttonLink",
          friendlyName: "Button Link",
          type: "string",
          defaultValue: "#",
        },
      ],
    },
  ]
})
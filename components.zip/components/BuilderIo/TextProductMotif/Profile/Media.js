import BuilderImage from "@/components/BuilderImage";
import useScreenSize from "@/utility/useScreenSize";
import { easeInOut, motion, useScroll, useTransform } from "framer-motion";

const Media = ({ image, containerRef }) => {
  const screenSize = useScreenSize();

  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start start", "end start"],
  });

  let translateYValue = "96px";
  let translateXValue = ["-50%", "2%"];
  if (screenSize.width >= 1440) {
    translateYValue = "192px";
    translateXValue = ["0%", "0%"];
  }

  const translateX = useTransform(scrollYProgress, [0, 0.2], translateXValue, {
    ease: easeInOut,
  });
  const translateY = useTransform(
    scrollYProgress,
    [0, 0.1],
    ["0px", translateYValue],
    { ease: easeInOut }
  );

  return (
    <motion.div
      style={{ translateX: translateX, translateY: translateY }}
      initial={{ opacity: 0 }}
      whileInView={{ opacity: 1 }}
      transition={{ duration: 0.7 }}
      className={`media min-w-[876px] md:min-w-[1234px] lg:min-w-[1700px] xl:min-w-[1067px] xl:max-w-[1067px] xl:mx-auto`}
    >
      <BuilderImage
        src={image}
        width={1067}
        height={609}
        alt="media"
        className="w-full h-auto object-contain"
        priority
      />
    </motion.div>
  );
};

export default Media;

import LogoBuilder from "@/components/LogoBuilder";
import Media from "@/components/BuilderIo/TextProductMotif/Full/Media";
import MediaText from "@/components/BuilderIo/TextProductMotif/Full/MediaText";
import Title from "@/components/BuilderIo/TextProductMotif/Full/Title";

import { setLogoEnabled, setLogoMode } from "@/redux/header/logo";
import { useRef } from "react";
import { useDispatch } from "react-redux";

const TextProductMotifFull = ({ bgColor, title, text, image, media, mediaContent }) => {
  const ref = useRef(null);
  const dispatch = useDispatch();
  const bgColorGradient = getBgColorGradient(bgColor);
  const logoColor = getLogoColor(bgColor);
  dispatch(setLogoEnabled(false));
  dispatch(setLogoMode(logoColor));

  return (
    <>
    <div className={bgColorGradient} ref={ref}>
      <div className={`w-full min-h-screen xl:min-h-0 relative flex flex-col overflow-hidden`}>
        <LogoBuilder containerRef={ref} mode={logoColor} />

        <div className="flex flex-col justify-start flex-1 xl:mb-24">
          <Title title={title} text={text} containerRef={ref} />
          <Media image={image} containerRef={ref} />
        </div>
      </div>

      
      <MediaText data={media} content={mediaContent} containerRef={ref} />
        
    </div>
    
    </>
  );
};

export default TextProductMotifFull;

const getLogoColor = (bgColor) => {
  switch (bgColor) {
    case "white":
      return "dark";
    case "lightGrey":
      return "dark";
    case "greyBlue":
      return "light";
    case "blue":
      return "light";
    case "green":
      return "light";
    case "orange":
      return "light";
    case "dark":
      return "light";
    default:
      return "dark";
  }
};

const getBgColorGradient = (bgColor) => {
  switch (bgColor) {
    case "white":
      return "bg-white";
    case "lightGrey":
      return "bg-gradient-to-b from-base-300 to-base-400";
    case "greyBlue":
      return "bg-gradient-to-b from-blue-200 to-blue-300 text-white";
    case "blue":
      return "bg-gradient-to-b from-blue-300 to-blue-100 text-white";
    case "green":
      return "bg-gradient-to-b from-green-300 to-green-100 text-white";
    case "orange":
      return "bg-gradient-to-b from-orange-400 to-orange-50 text-white";
    case "dark":
      return "bg-gradient-to-b from-[#1F1E25] to-[#2A2A2C] text-white";
    default:
      return "bg-white";
  }
};

import { motion, useScroll, useTransform, easeInOut } from "framer-motion";
import BuilderImage from "@/components/BuilderImage";

const Media = ({ image, containerRef }) => {  
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start start", "end start"],
  });

  const opacity = useTransform(scrollYProgress, [0, 0.1], [1, 0], { ease: easeInOut });
  const translateY = useTransform(scrollYProgress, [0, 0.1], ["0%", "100%"], { ease: easeInOut });

  return (
      <motion.div 
        style={{ translateX: translateY, opacity: opacity }}
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7 }}
        className={`media w-full relative overflow-hidden h-[258px] md:h-[490px] xl:h-[599px]`}
      >
        <BuilderImage
          src={image}
          width={390}
          height={446}
          alt="media mobile"
          className={`h-full w-auto object-cover object-top md:hidden`}
          priority
        />

        <BuilderImage
          src={image}
          width={768}
          height={844}
          alt="media tablet"
          className="h-full w-auto object-cover object-top hidden md:block lg:hidden"
          priority
        />

        <BuilderImage
          src={image}
          width={1440}
          height={890}
          alt="media desktop"
          className="h-full w-auto mx-auto object-contain object-top hidden lg:block"
          priority
        />
      </motion.div>
    
  );
};

export default Media;

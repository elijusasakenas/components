import { motion, useScroll, useTransform, easeInOut } from "framer-motion";

const Title = ({ title, text, containerRef }) => {
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start start", "end start"],
  });

  const opacity = useTransform(scrollYProgress, [0, 0.1], [1, 0], { ease: easeInOut });
  const translateY = useTransform(scrollYProgress, [0, 0.1], ["0%", "-100%"], { ease: easeInOut });

  return (
    <motion.div
      style={
        { opacity: opacity, translateY: translateY }
      }
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.7 }}
      className="mt-16 md:mt-32 lg:mt-40 px-6 text-center xl:px-0 w-full xl:max-w-[830px] mx-auto max-w-7xl "
    >
      {title && <h1 className="display mb-2">{title}</h1>}
      {text && <div className="body mb-6">{text}</div>}

      <div className="xl:mb-24">
        <div className="arrow">
          <span></span>
          <span></span>
        </div>
      </div>
    </motion.div>
  );
};

export default Title;

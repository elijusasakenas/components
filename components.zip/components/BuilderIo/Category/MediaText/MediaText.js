import Media from "@/components/BuilderIo/Category/MediaText/Media";
import Title from "@/components/BuilderIo/Category/MediaText/Title";
import LogoBuilder from "@/components/LogoBuilder";
import { useRef } from "react";
import { useSelector } from "react-redux";

/**
 * CategoryMediaText component.
 *
 * @param {Object} props - The component props.
 * @param {string} props.title - The title of the media text.
 * @param {string} props.subTitle - The subtitle of the media text.
 * @param {string} props.text - The text content of the media text.
 * @param {Object} props.media - The media data for the media text.
 * @returns {JSX.Element} The rendered CategoryMediaText component.
 */
const CategoryMediaText = ({ title, subTitle, text, media }) => {
  const ref = useRef(null);
  const mobileMenuOpen = useSelector((state) => state.navigation.mobileMenuOpen);
  const mobileSearchOpen = useSelector((state) => state.navigation.mobileSearchOpen);

  return (
    <div ref={ref} className="relative">
      <div className={`absolute top-0 inset-x-0 z-10 ${(mobileMenuOpen || mobileSearchOpen) ? 'hidden' : 'visible'}`}>
        <LogoBuilder containerRef={ref} />
      </div>

      <Media data={media} />
      <Title title={title} subTitle={subTitle} text={text} containerRef={ref} />
    </div>
  );
};

export default CategoryMediaText;

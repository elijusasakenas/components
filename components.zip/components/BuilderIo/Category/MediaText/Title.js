import { motion } from "framer-motion";
import { useEffect, useState } from "react";
import { animateScroll } from "react-scroll";

/**
 * Renders a title component with optional subtitle, text, and scroll functionality.
 *
 * @param {Object} props - The component props.
 * @param {string} props.title - The main title.
 * @param {string} [props.subTitle] - The optional subtitle.
 * @param {string} [props.text] - The optional text.
 * @param {React.Ref} props.containerRef - The reference to the container element.
 * @returns {JSX.Element} The rendered title component.
 */
const Title = ({ title, subTitle, text, containerRef }) => {
  const [height, setHeight] = useState(null);

  useEffect(() => {
    if (containerRef.current) {
      setHeight(containerRef.current.offsetHeight);
    }
  }, [containerRef]);

  const scrollToNextSection = () => {
    animateScroll.scrollTo(height, {
      duration: 500,
      smooth: true,
    });
  };

  return (
    <div className="w-full max-w-7xl text-center absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 px-6 md:px-12 xl:px-24 text-base-500">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7 }}
      >
        <div className="text-4xl md:text-6xl lg:text-8xl leading-none font-bold uppercase">
          {title}
        </div>

        <div className="text-transparent webkit-stroke text-4xl md:text-6xl lg:text-8xl leading-none font-bold uppercase mb-2">
          {subTitle}
        </div>

        <div className="body mb-8 md:mb-16">{text}</div>

        <button onClick={scrollToNextSection}>
          <div className="arrow">
            <span></span>
            <span></span>
          </div>
        </button>
      </motion.div>
    </div>
  );
};

export default Title;

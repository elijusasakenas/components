import BuilderImage from "@/components/BuilderImage";

/**
 * Renders a media component based on the provided data.
 *
 * @param {Object} props - The component props.
 * @param {Object} props.data - The data object containing information about the media.
 * @returns {JSX.Element} The rendered media component.
 */
const Media = ({ data }) => {
  return (
    <div
      className={`media mx-auto w-full h-full lg:h-auto relative overflow-hidden lg:max-h-[890px]`}
    >
      {data.type === "video" ? (
        data.video && (
          <video
            src={data.video}
            autoPlay
            loop
            muted
            playsInline
            className="w-full overflow-hidden object-cover h-[844px]"
          ></video>
        )
      ) : (
        <>
          <div className="overflow-hidden">
            <BuilderImage
              src={data.imageMobile}
              width={780}
              height={1688}
              alt="media"
              className="w-full object-cover md:hidden"
              priority
            />

            <BuilderImage
              src={data.imageTablet}
              width={1488}
              height={2266}
              alt="media"
              className="w-full object-cover hidden md:block lg:hidden"
              priority
            />

            <BuilderImage
              src={data.imageDesktop}
              width={2880}
              height={1780}
              alt="media"
              className="w-full object-cover hidden lg:block"
              priority
            />
          </div>
        </>
      )}
    </div>
  );
};

export default Media;

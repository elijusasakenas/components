import CategoryMediaText from "@/components/BuilderIo/Category/MediaText/MediaText";
import { Builder } from "@builder.io/react";

// Register Category MediaText component
Builder.registerComponent(CategoryMediaText, {
  name: "CategoryMediaText",
  friendlyName: "Category: Media + Text",
  screenshot:
    "https://cdn.builder.io/api/v1/image/assets%2F90182f3615654f8c9be2b012f26cc6c0%2Fc5c14627b18e4b49b072beaec1c9c48e",
  inputs: [
    {
      name: "title",
      friendlyName: "Title",
      type: "string",
      defaultValue: "Title",
    },
    {
      name: "subTitle",
      friendlyName: "Sub Title",
      type: "string",
      defaultValue: "Sub Title",
    },
    {
      name: "text",
      friendlyName: "Text",
      type: "string",
      defaultValue: "Lorem ipsum dolor sit amet.",
    },
    {
      name: "media",
      friendlyName: "Media",
      type: "object",
      defaultValue: {
        imageDesktop:
          "https://cdn.builder.io/api/v1/image/assets%2F90182f3615654f8c9be2b012f26cc6c0%2F628f01c72b2d42038466712808edad28",
        imageTablet:
          "https://cdn.builder.io/api/v1/image/assets%2F90182f3615654f8c9be2b012f26cc6c0%2F86be7698783d4a28a90fa3b548717fae",
        imageMobile:
          "https://cdn.builder.io/api/v1/image/assets%2F90182f3615654f8c9be2b012f26cc6c0%2F614a0f9e92b140029b1b90d1ba18bcf3",
        type: "image",
      },
      subFields: [
        {
          name: "imageDesktop",
          friendlyName: "Image Desktop",
          type: "file",
        },
        {
          name: "imageTablet",
          friendlyName: "Image Tablet",
          type: "file",
        },
        {
          name: "imageMobile",
          friendlyName: "Image Mobile",
          type: "file",
        },
        {
          name: "video",
          friendlyName: "Video",
          type: "file",
        },
        {
          name: "videoTablet",
          friendlyName: "Video Tablet",
          type: "file",
        },
        {
          name: "videoMobile",
          friendlyName: "Video Mobile",
          type: "file",
        },
        {
          name: "type",
          friendlyName: "Type",
          type: "select",
          enum: [
            { label: "Image", value: "image" },
            { label: "Video", value: "video" },
          ],
        },
      ],
    },
  ],
});

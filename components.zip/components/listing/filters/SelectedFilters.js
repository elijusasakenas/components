import {useSelector} from "react-redux";
import {setManufacturerFilter} from "@/redux/category/filters";

export default function GetSelectedFilters(){
    // Get the currently selected sorting and filters from the Redux store.
    const selectedSorting = useSelector((state) => state.sorting.sorting);
    const selectedPriceFilter = useSelector((state) => state.filters.priceFilter);
    const selectedShippingFreeFilter = useSelector((state) => state.filters.shippingFreeFilter);
    const setFilterFilter = useSelector((state) => state.filters.filterFilter);

    return {
        'selectedSorting': selectedSorting,
        'filters': {
            'min-price':selectedPriceFilter.min,
            'max-price':selectedPriceFilter.max,
            'shipping-free': selectedShippingFreeFilter,
            'filter': setFilterFilter
        }
    };
}

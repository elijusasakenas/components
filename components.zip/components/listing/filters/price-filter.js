import * as React from 'react';
import Box from '@mui/material/Box';
import Slider from '@mui/material/Slider';
import {getListing} from "@/shopware/category";
import {setListing} from "@/redux/category/listing";
import {useDispatch, useSelector} from "react-redux";
import {setPriceFilter} from "@/redux/category/filters";
import GetSelectedFilters from "@/components/listing/filters/SelectedFilters";

function valuetext(value) {
    return `${value} €`;
}

const marks = [
    {
        value: 1000,
        label: '1000 €',
    },
    {
        value: 3000,
        label: '3000  €',
    },
    {
        value: 5000,
        label: '5000 €',
    },
    {
        value: 7000,
        label: '7000 €',
    },
    {
        value: 9000,
        label: '9000 €',
    },
];

export default function PriceFilter({categoryId,start,end,min,max}) {
    const [value, setValue] = React.useState([start, end]);
    // Use the Redux dispatch function.
    const dispatch = useDispatch();
    // Get the currently selected sorting and filters from the Redux store.
    let selectedFilters = GetSelectedFilters();
    const handleChange = (event, newValue) => {
        setValue(newValue);
        // update the selected filter method.
        dispatch(setPriceFilter({'min':newValue[0],'max':newValue[1]}));
        selectedFilters.filters["min-price"] = newValue[0];
        selectedFilters.filters["max-price"] = newValue[1];
        // Get the sorted listing and dispatch an action to update the listing in the Redux store.
        const listing = getListing(categoryId, selectedFilters.filters, selectedFilters.selectedSorting).then((response) => {
            dispatch(setListing(response.elements));
        });
    };

    return (
        <div className={"m-2 rounded-md"}>
            <Box sx={{ width: 300 }}>
                <Slider
                    getAriaLabel={() => 'Price range'}
                    value={value}
                    marks={marks}
                    step={100}
                    onChangeCommitted={handleChange}
                    valueLabelDisplay="auto"
                    min={min}
                    max={max}
                    getAriaValueText={valuetext}
                />
            </Box>
        </div>
    );
}
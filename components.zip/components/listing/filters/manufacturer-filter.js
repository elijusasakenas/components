import Checkbox from '@mui/material/Checkbox';
import TextField from '@mui/material/TextField';
import Autocomplete from '@mui/material/Autocomplete';
import { MinusIcon, CheckCircleIcon } from "@heroicons/react/20/solid";
import { useDispatch, useSelector } from "react-redux";
import { useState } from "react";
import { setFilterFilter, setManufacturerFilter } from "@/redux/category/filters";
import { getListing } from "@/shopware/category";
import { setListing } from "@/redux/category/listing";
import GetSelectedFilters from "@/components/listing/filters/SelectedFilters";
const icon = <MinusIcon fontSize="small" />;
const checkedIcon = <CheckCircleIcon fontSize="small" />;
/**
 * ManufacturerFilter is a React component that provides a manufacturer filter for a product listing.
 * It uses the Material-UI Autocomplete component to allow users to select multiple manufacturers.
 * The selected manufacturers are then used to filter the product listing.
 *
 * @param {Object} categoryId - The ID of the category to filter.
 * @returns {JSX.Element} The rendered Autocomplete component.
 */
export default function ManufacturerFilter(categoryId) {
    // Get the list of products from the Redux store.
    const products = useSelector((state) => state.listing.listing);
    // Extract the manufacturer from each product.
    const manufacturer = products.map((product) => product.manufacturer)
        .filter((manufacturer) => manufacturer && Object.keys(manufacturer).length !== 0);
    // Use the Redux dispatch function.
    const dispatch = useDispatch();
    // Get the unique manufacturers.
    const uniqueManufacturer = Array.from(new Set(manufacturer.map(JSON.stringify))).map(JSON.parse);
    // Dispatch an action to update the manufacturer filter in the Redux store.
    dispatch(setManufacturerFilter(uniqueManufacturer));

    const fixedOptions = [];
    const [value, setValue] = useState([...fixedOptions, null]);
    // Get the currently selected filters.
    let selectedFilters = GetSelectedFilters();

    /**
     * Handles the change event of the Autocomplete component.
     * It updates the selected filters in the Redux store and fetches the filtered listing.
     *
     * @param {Array} newValue - The new value of the Autocomplete component.
     */
    const handleChange = (newValue) => {
        // Update the state of the switch.
        setValue([
            ...fixedOptions,
            ...newValue.filter((option) => fixedOptions.indexOf(option) === -1),
        ]);
        // update the selected filter method.
        const selectedManufacturerIds = newValue.map(item => item.id);
        selectedFilters.filters.filter = selectedManufacturerIds.length > 0 ? [...selectedFilters.filters.filter, { 'type': 'equalsAny', 'field': 'manufacturerId', 'value': selectedManufacturerIds }] : [];
        dispatch(setFilterFilter(selectedFilters.filters.filter));
        // Get the filtered listing and dispatch an action to update the listing in the Redux store.
        const listing = getListing(categoryId.categoryId, selectedFilters.filters, selectedFilters.selectedSorting).then((response) => {
            dispatch(setListing(response.elements));
        });
    };

    if (uniqueManufacturer.length <= 0) return null;
    return (
            <div className={"m-2 rounded-md"}>
                <Autocomplete
                    multiple
                    id="manufacturer-filter"
                    options={manufacturer}
                    disableCloseOnSelect
                    size="small"
                    sx={{ width: 200 }}
                    onChange={(event, newValue) => handleChange(newValue)}
                    getOptionLabel={(option) => option?.translated.name}
                    renderOption={(props, option, { selected }) => (
                        <li key={`option-` + option.id} {...props}>
                            <Checkbox
                                icon={icon}
                                checkedIcon={checkedIcon}
                                style={{ marginRight: 8 }}
                                checked={selected}
                            />
                            {option?.translated.name}
                        </li>
                    )}
                    renderInput={(params) => (
                        <TextField {...params} key={`text-field-` + params?.id} label="Manufacturer" placeholder="Manufacturer" />
                    )}
                />
            </div>
    );
}

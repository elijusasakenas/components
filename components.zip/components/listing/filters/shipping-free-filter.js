import Switch from '@mui/material/Switch';
import {FormControlLabel, FormGroup} from "@mui/material";
import {useState} from "react";
import {useDispatch} from "react-redux";
import {setShippingFreeFilter} from "@/redux/category/filters";
import {getListing} from "@/shopware/category";
import {setListing} from "@/redux/category/listing";
import GetSelectedFilters from "@/components/listing/filters/SelectedFilters";
/**
 * ShippingFreeFilter component for category listings.
 *
 * This component provides a switch for filtering category listings based on whether shipping is free.
 * It dispatches actions to the Redux store to update the selected filter and the filtered listing.
 *
 * @param {Object} categoryId - The ID of the category to be filtered.
 *
 * @returns {JSX.Element} The ShippingFreeFilter component.
 */
export default function ShippingFreeFilter({categoryId,}){
    // Use the useState hook to manage the state of the switch.
    const [checked, setChecked] = useState(false);

    // Use the Redux dispatch function.
    const dispatch = useDispatch();

    // Get the currently selected filters.
    let selectedFilters = GetSelectedFilters();
    /**
     * Handle the change of the switch.
     *
     * This function updates the state of the switch, dispatches an action to update the selected filter in the Redux store,
     * and dispatches an action to update the filtered listing in the Redux store.
     *
     * @param {Object} event - The event triggered when the state of the switch changes.
     */
    const handleChange = (event) => {
        // Update the state of the switch.
        setChecked(event.target.checked);
        // Dispatch an action to update the selected filter in the Redux store.
        dispatch(setShippingFreeFilter(event.target.checked));
        // Update the selected filters.
        selectedFilters.filters["shipping-free"] = event.target.checked;
        // Get the filtered listing and dispatch an action to update the listing in the Redux store.
        const listing = getListing(categoryId, selectedFilters.filters, selectedFilters.selectedSorting).then((response) => {
            dispatch(setListing(response.elements));
        });
    };
    // Render the ShippingFreeFilter component.
    return (
        <div className={"m-2 rounded-md"}>
            <FormGroup>
                <FormControlLabel control={<Switch checked={checked} onChange={handleChange} />} label="ShippingFree" />
            </FormGroup>
        </div>
    )
}

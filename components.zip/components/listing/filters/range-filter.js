export default function RangeFilter(){
    const rangeFilter = null;

    if(!rangeFilter){ return null }

    return (
        <div className={"bg-gray-100 p-2 m-2 rounded-md"}>
            <div>
                <p>RangeFilter</p>
            </div>
        </div>
    )
}
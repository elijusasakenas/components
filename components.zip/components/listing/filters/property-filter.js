import ChevronDownIcon from "@/components/icons/chevron-down";
import SeparationBar from "@/components/icons/separation-bar";
import GetSelectedFilters from "@/components/listing/filters/SelectedFilters";
import { setFilterFilter } from "@/redux/category/filters";
import { setListing } from "@/redux/category/listing";
import { getListing } from "@/shopware/category";
import {
  Checkbox,
  Disclosure,
  DisclosureButton,
  DisclosurePanel,
  Field,
  Label,
} from "@headlessui/react";
import clsx from "clsx";
import { Fragment } from "react";
import { useDispatch, useSelector } from "react-redux";

export default function PropertyFilter({
  categoryId,
  offCanvas = false,
  selectedProperties,
  setSelectedProperties,
  propertyWhitelistValue,
  setFilteredPropertiesLength,
}) {
  const properties = useSelector((state) => state.filters.propertiesFilter);
  let selectedFilters = GetSelectedFilters();
  const dispatch = useDispatch();

  // Handles the change event when a property is selected or deselected
  const handleChange = (property, isCheckbox = false) => {
    const isSelected = selectedProperties.some(
      (selected) => selected.id === property.id
    );

    // Toggle property selection
    let updatedSelectedProperties;
    if (isSelected) {
      // Remove the property if already selected
      updatedSelectedProperties = selectedProperties.filter(
        (selected) => selected.id !== property.id
      );
    } else {
      // Add the property to the selection
      const newProperty = isCheckbox
        ? { ...property, isCheckboxSelected: true }
        : property;
      updatedSelectedProperties = [...selectedProperties, newProperty];
    }

    setSelectedProperties(updatedSelectedProperties);

    // Update the filter with selected property IDs
    const selectedPropertyIds = updatedSelectedProperties.map(
      (item) => item.id
    );
    selectedFilters.filters.filter =
      selectedPropertyIds.length > 0
        ? [
            {
              type: "equalsAny",
              field: "properties.id",
              value: selectedPropertyIds,
            },
          ]
        : [];

    // Dispatch the updated filter to Redux
    dispatch(setFilterFilter(selectedFilters.filters.filter));

    // Get the updated listing and update the Redux store
    getListing(
      categoryId,
      selectedFilters.filters,
      selectedFilters.selectedSorting
    ).then((response) => {
      dispatch(setListing(response.elements));
    });
  };

  if (!properties) return null;

  const filteredProperties = properties.filter(
    (propertyGroup) =>
      Array.isArray(propertyWhitelistValue) &&
      propertyWhitelistValue.includes(propertyGroup.id)
  );

  const propertiesToUse =
    filteredProperties.length > 0 ? filteredProperties : properties;

  if (offCanvas) {
    return propertiesToUse.map((propertyGroup) => (
      <Disclosure key={propertyGroup.id}>
        <DisclosureButton className="group flex w-full justify-between flex-col">
          <div className="body-small-emphasis capitalize flex items-center justify-between w-full text-left group-hover:text-orange-200">
            {propertyGroup.translated.name}
            <ChevronDownIcon className="h-6 w-6 fill-base-50 group-hover:fill-orange-200" />
          </div>
        </DisclosureButton>
        <DisclosurePanel className={"w-full"}>
          {propertyGroup.options.map((property) => (
            <Field
              className="flex items-center justify-start gap-2 mb-2 bg-base-500 p-2 rounded-md w-full"
              key={property.id}
            >
              <Checkbox
                className={"mt-0.5"}
                onChange={() => handleChange(property, true)}
                checked={selectedProperties.some(
                  (selected) => selected.id === property.id
                )}
                autoFocus={true}
              >
                {({ checked, disabled }) => (
                  <span
                    className={clsx(
                      "block size-5 rounded border",
                      !checked && "bg-white",
                      checked && !disabled && "bg-orange-200",
                      checked && disabled && "bg-gray-500",
                      disabled && "cursor-not-allowed opacity-50"
                    )}
                  >
                    <svg
                      className={clsx(
                        "stroke-white",
                        checked ? "opacity-100" : "opacity-0"
                      )}
                      viewBox="0 0 14 14"
                      fill="none"
                    >
                      <path
                        d="M3 8L6 11L11 3.5"
                        strokeWidth={2}
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      />
                    </svg>
                  </span>
                )}
              </Checkbox>
              <Label
                className={
                  "body-small capitalize flex-1 cursor-pointer hover:text-orange-200"
                }
              >
                {property.translated.name}
              </Label>
            </Field>
          ))}
        </DisclosurePanel>
        <SeparationBar stroke={"#979797"} />
      </Disclosure>
    ));
  }
  return propertiesToUse.map((propertyGroup) => (
    <div
      className={"m-2 rounded-md flex flex-col gap-3"}
      key={propertyGroup.id}
    >
      <p className={"body-emphasis"}>{propertyGroup.name}</p>
      <div className="flex flex-wrap gap-3">
        {propertyGroup.options.map((property) => (
          <button
            key={property.id}
            className={`flex py-3 px-6 justify-center items-center gap-2 text-sm rounded-[100px] bg-base-500 ${
              selectedProperties.some((selected) => selected.id === property.id)
                ? "bg-orange-200 text-white"
                : ""
            }`}
            onClick={() => handleChange(property)} // Updated onClick handler
          >
            {property.name}
          </button>
        ))}
      </div>
    </div>
  ));
}


import {FormControl, InputLabel, MenuItem, Select} from "@mui/material";
import {setSorting} from "@/redux/category/sorting";
import {setListing} from "@/redux/category/listing";
import {useDispatch, useSelector} from "react-redux";
import {getListing} from "@/shopware/category";
import GetSelectedFilters from "@/components/listing/filters/SelectedFilters";

/**
 * Sorting component for category listings.
 *
 * This component provides a dropdown menu for sorting category listings.
 * It dispatches actions to the Redux store to update the selected sorting method and the sorted listing.
 *
 * @param {Object} props - The properties passed to the component.
 * @param {string} props.categoryId - The ID of the category to be sorted.
 * @param {Array} props.availableSortings - The available sorting methods.
 *
 * @returns {JSX.Element} The Sorting component.
 */
export default function Sorting({ categoryId, availableSortings }) {
    // Use the Redux dispatch function.
    const dispatch = useDispatch();

    // Get the currently selected sorting method from the Redux store.
    const selectedFilters = GetSelectedFilters();
    const selectedSorting = useSelector((state) => state.sorting.sorting);
    /**
     * Set the sorted listing.
     *
     * This function dispatches actions to the Redux store to update the selected sorting method and the sorted listing.
     *
     * @param {string} sorting - The selected sorting method.
     */
    const setSortedListing = (sorting) => {
        // Dispatch an action to update the selected sorting method.
        dispatch(setSorting(sorting));
        // Get the sorted listing and dispatch an action to update the listing in the Redux store.
        const listing = getListing(categoryId, selectedFilters.filters, sorting).then((response) => {
            dispatch(setListing(response.elements));
        });
    }
    // Render the Sorting component.
    return (
        <div className={"p-2 m-2 rounded-md"}>
            <FormControl sx={{m: 0, minWidth: "100%"}} size="small" className="bg-white text-base-50">
                <InputLabel id="demo-select-small-label">
                    Sorting
                </InputLabel>
                <Select
                    labelId="sorting-label"
                    id="sorting"
                    name="sorting"
                    value={selectedSorting ? selectedSorting : ''}
                    label="Sorting"
                    onChange={(event) =>
                        // When the selected sorting method changes, dispatch actions to update the selected sorting method and the sorted listing.
                    dispatch(setSorting(event.target.value)) && setSortedListing(event.target.value)
                    }
                >
                    {/* Render the available sorting methods as options in the dropdown menu. */}
                    {availableSortings.map((sorting) => (
                        <MenuItem key={sorting.key} value={sorting.key} className={"text-base-50"}>
                            {sorting.translated.label}
                        </MenuItem>
                    ))}
                </Select>
            </FormControl>
        </div>
    )
};

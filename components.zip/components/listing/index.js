"use client";

//import Breadcrumb from "@/components/breadcrumb";
import CreateBlock from "@/components/layout/blocks";
import Image from "next/image";

import dynamic from "next/dynamic";
import ListingNavigation from "./Navigation";
import { useEffect, useState } from "react";
import StoreRocketModal from "@/components/StoreLocator/StoreRocketModal";
import Link from "next/link";
import {useDispatch, useSelector} from "react-redux";
import { setLogoEnabled } from "@/redux/header/logo";
import { setLogoCmsEnabled } from "@/redux/header/logoCms";
import Breadcrumb from "@/components/breadcrumb";
import Layout from "@/components/layout/templates/default";
import { setOpen } from '@/redux/StoreRocketModal/StoreRocketModal';

export default function Listing({
  category,
  mainNavigation,
  footerNavigation,
  snippets,
  breadcrumb,
  languages,
  foreignKey,
}) {
  const dispatch = useDispatch();
  const storeRocketModalOpen = useSelector((state) => state.storeRocketModal.open);

  useEffect(() => {
    dispatch(setLogoEnabled(true));
    dispatch(setLogoCmsEnabled(false));
  }, [dispatch]);

  return (
    category && (
      <Layout
        metaData={category}
        mainNavigation={mainNavigation}
        footerNavigation={footerNavigation}
        snippets={snippets}
        languages={languages}
        foreignKey={foreignKey}
      >
        {/*
        <Breadcrumb 
          breadcrumb={category.breadcrumb} 
          path={category.seoUrls[0].seoPathInfo}
        />
        */}

        <div className="flex max-w-7xl m-auto flex-col lg:flex-row justify-between lg:items-end px-6 md:px-12 xl:px-0 pb-4 md:pb-6 lg:pb-12 mt-14 md:mt-12 lg:mt-14">
            <h1 className="headline-large">
              {snippets.next.listing.categoryName.replace(/{name}/g, category.translated.name)}
            </h1>
          <div className="flex flex-col justify-end gap-5 mt-10 md:mt-12 lg:mt-0">
            <div className="flex items-center gap-4">
              <div className="">
                <Image
                  src={"/static/images/icons/Ellipse.svg"}
                  alt="Listing Banner"
                  width={48}
                  height={48}
                />
              </div>
              <div className="flex flex-col justify-center items-start gap-0">
                <span className="body-small-emphasis">
                  {snippets?.next?.listing.header.contact.headline}
                </span>
                <Link
                  href={
                    snippets?.next.listing.header.contact.link.href
                  }
                  className="text-link-small text-link"
                >
                  {" "}
                  {snippets?.next.listing.header.contact.link.text}
                </Link>
              </div>
            </div>
            <div className="flex items-center gap-4 pb-2">
              <div className="w-12 h-12 bg-orange-200 rounded-full flex justify-center items-center">
                <Image
                  src={"/static/images/icons/drop-point.svg"}
                  alt="Listing Banner"
                  width={15}
                  height={7}
                />
              </div>
              <div className="flex flex-col justify-center items-start gap-0">
                <span className="body-small-emphasis">
                  {snippets?.next.listing.header.storelocator.headline}
                </span>
                <div className="text-link-small text-link">
                  <Link href="#" onClick={() => dispatch(setOpen(true))}>
                    {
                      snippets?.next.listing.header.storelocator.link
                        .text
                    }
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/*
        <ListingNavigation data={category.children} />
        */}

        <div className="content bg-base-400">
          {category.cmsPage.sections?.map((section, s) => (
            <div
              key={`section-${s}`}
              className={"mx-auto max-w-7xl cms-section " + section.cssClass}
            >
              {section.blocks.map((block, b) =>
                CreateBlock(category, block, `block-${b}-${s}`)
              )}
            </div>
          ))}
        </div>
        {storeRocketModalOpen && (
          <StoreRocketModal  />
        )}
      </Layout>
    )
  );
}

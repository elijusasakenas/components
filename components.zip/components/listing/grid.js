"use client";

import useSWR from "swr";
import { useState } from "react";
import * as gtag from "@/utility/gtag";
import Sorting from "@/components/listing/sorting";
import Filters from "@/components/listing/filters";
import ProductBox from "@/components/product/box";
import { useSelector } from "react-redux";

/**
 * ProductGrid is a React component that displays a grid of products.
 * It uses the Redux state to get the list of products and the manufacturer filter.
 * It also dispatches actions to update the manufacturer filter in the Redux store.
 *
 * @param {Object} categoryId - The ID of the category to display products for.
 * @param {Array} availableSortings - The available sorting options for the product listing.
 * @param {Array} filters - The filters to be applied on the product listing.
 * @returns {JSX.Element} The rendered product grid.
 */
const ProductGrid = ({ category, availableSortings, showSorting, filters }) => {
  // State to track if the event has been fired.
  const [eventIsFired, setEventFired] = useState(false);
  // Get the list of products from the Redux store.
  const products = useSelector((state) => state.listing.listing);
  const categoryId = category.id;
  /*
    let categoryItems = [];
    products.map((item) => {
      categoryItems.push({
        item_id: item.productNumber,
        item_name: item.translated.name,
        item_brand: process.env.NEXT_PUBLIC_BRAND_NAME,
        price: item.calculatedPrice.unitPrice,
        quantity: 1
      });
    });
    const dataLayer = {
      event: "view_item_list",
      ecommerce: {
        item_list_id: categoryId,
        item_list_name: category.translated.name,
        items: categoryItems
      }
    };
    if (eventIsFired === false) {
      gtag.dataLayer(dataLayer);
      setEventFired(true);
    }
*/

  return (
    <div className={"listing"} key={categoryId}>
        <div className={"flex flex-row p-4 justify-between "}>
        {filters ? <Filters categoryId={categoryId} data={filters} /> : null}
        {showSorting ? (
          <Sorting
            categoryId={categoryId}
            availableSortings={availableSortings}
          />
        ) : null}
      </div>
      <div className="grid grid-cols-1 gap-y-10 gap-x-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 xl:gap-x-8">
        {products.map((product) =>
          product.seoUrls ? (
            <ProductBox
              product={product}
              key={product.id}
              categoryName={"test"}
            />
          ) : null
        )}
      </div>
    </div>
  );
};

export default ProductGrid;
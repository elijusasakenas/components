import ChevronRightIcon from "@/icons/chevron-right";

import Link from "next/link";
import { useRouter } from "next/navigation";

const ListingNavigation = ({ ...params }) => {
  const router = useRouter();

  const onClickLink = async (e, href) => {
    e.preventDefault();
    router.push(href);
  };

  return (
    <div className="bg-base-400">
      <nav className="max-w-7xl mx-auto pt-12 grid grid-flow-row grid-cols-2 md:grid-cols-4 justify-center items-start md:gap-x-16 gap-y-0 px-6 md:px-12 xl:px-0">
        {params.data.map(
          (child) =>
            child.seoUrls &&
            child.seoUrls.length > 0 && (
              <div key={child.id} className="group pb-4">
                <div itemProp="name" className="relative text-base-50">
                  <div className="py-6">
                    <Link
                      href={`${process.env.NEXT_PUBLIC_SITE_URL}/${child.seoUrls[0].seoPathInfo}`}
                      onClick={(e) =>
                        onClickLink(
                          e,
                          process.env.NEXT_PUBLIC_SITE_URL +
                            "/" +
                            child.seoUrls[0].seoPathInfo
                        )
                      }
                      title={child.name}
                      className="flex justify-start items-center uppercase font-bold text-[18px] leading-5 text-link"
                    >
                      {child.name}
                      <ChevronRightIcon className="fill-[currentColor]" />
                    </Link>
                  </div>
                </div>
                {child.children && child.children.length > 0 && (
                  <ul
                    role="list"
                    aria-labelledby={`${child.name}-heading`}
                    className="flex flex-col uppercase gap-2"
                  >
                    {child.children.map(
                      (child) =>
                        child.seoUrls &&
                        child.seoUrls.length > 0 && (
                          <li key={child.id} className={``}>
                            <Link
                              href={`${process.env.NEXT_PUBLIC_SITE_URL}/${child.seoUrls[0].seoPathInfo}`}
                              onClick={(e) => {
                                onClickLink(
                                  e,
                                  process.env.NEXT_PUBLIC_SITE_URL +
                                    "/" +
                                    child.seoUrls[0].seoPathInfo
                                );
                              }}
                              className={
                                "text-link uppercase no-underline w-full flex items-center rounded-md text-sm"
                              }
                              title={child.name}
                            >
                              {child.name}
                            </Link>
                          </li>
                        )
                    )}
                  </ul>
                )}
              </div>
            )
        )}
      </nav>
    </div>
  );
};

export default ListingNavigation;

"use client";

import { useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";
import { fetchClient } from "@/utility/fetch-client";
import ProductBox from "@/components/product/box";

const SearchList = ({snippets}) => {
  const search = useSearchParams().get("s");
  const [searchResult, setSearchResult] = useState(null);

  const getSearchResult = async (search) => {
    const searchResult = await fetchClient({
      path: "search",
      method: "POST",
      body: {
        search: search,
        filter: [
          {
            type: "equals",
            field:
              "customFields.custom_netzkom_configurator_netzkomIsConfiguratorNumber",
            value: null,
          },
        ],
      },
    });

    setSearchResult(searchResult.elements);
  };

  useEffect(() => {
    getSearchResult(search);
  }, [search]);

  return (
    searchResult && (
      <div className="content mt-8 mb-2">
        <div className="mx-auto max-w-7xl pt-0 md:pt-8 px-4 sm:px-6 lg:px-8 xl:px-0">
          <h1 className={"headline-large lg:text-center mb-2"}>{snippets.next.search.page.title}</h1>
          <div className="body lg:text-center">
            {snippets.next.search.page.text.replace(/{search}/g, search).replace(/{searchCount}/g, searchResult.length)}
          </div>
        </div>

        <section
          aria-labelledby="products-heading"
          className="mx-auto max-w-7xl px-4 pt-12 pb-16 sm:px-6 sm:pt-16 lg:px-8 xl:px-0"
        >
          <div className="grid grid-cols-1 gap-y-10 gap-x-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 xl:gap-x-8">
            {searchResult.map((product) =>
              product.seoUrls ? (
                <ProductBox
                  product={product}
                  key={product.id}
                  categoryName={"search"}
                />
              ) : null
            )}
          </div>
        </section>
      </div>
    )
  );
};

export default SearchList;

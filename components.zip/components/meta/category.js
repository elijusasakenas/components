import Head from "next/head";
import { useRouter } from "next/navigation";

export default function Meta({ item }) {
  const router = useRouter();

  const url = process.env.NEXT_PUBLIC_SITE_URL + router.asPath;
  const brandName = process.env.NEXT_PUBLIC_BRAND_NAME;
  const shopName = process.env.NEXT_PUBLIC_SITE_NAME;

  const maxLength = 255;
  const metaDescription = item.translated.metaDescription
    ? truncate(stripTags(item.translated.metaDescription), maxLength)
    : truncate(stripTags(item.translated.description.trim(), maxLength));
  const metaTitle = item.translated.metaTitle
    ? truncate(stripTags(item.translated.metaTitle), maxLength)
    : truncate(stripTags(item.translated.name), maxLength);
  const metaKeywords = item.translated.keywords;

  function stripTags(str) {
    if (str === null || str === "") return false;
    else str = str.toString();
    return str.replace(/(<([^>]+)>)/gi, "").trim();
  }

  function truncate(str, n) {
    return str.length > n ? str.slice(0, n - 1) + " ...;" : str;
  }

  const JsonObject = {
    "@context": "https://schema.org/",
    "@type": "BreadcrumbList",
    itemListElement: [
      {
        "@type": "ListItem",
        position: 1,
        name: shopName,
        item: process.env.NEXT_PUBLIC_SITE_URL,
      },
      {
        "@type": "ListItem",
        position: 2,
        name: item.translated.name,
        item: url,
      },
    ],
  };

  return (
    <div>
      <Head>
        <title>{metaTitle}</title>
        <meta name="description" content={metaDescription} key="desc" />

        <meta property="og:type" content="website" />
        <meta property="og:site_name" content={shopName} />
        <meta property="og:url" content={url} />
        <meta property="og:title" content={metaTitle} />
        <meta property="og:description" content={metaDescription} />
        <meta
          property="og:image"
          content={process.env.NEXT_PUBLIC_SITE_URL + '/static/images/logo.jpg'}
        />

        <meta name="twitter:card" content="summary" />
        <meta name="twitter:site" content={shopName} />
        <meta name="twitter:title" content={metaTitle} />
        <meta name="twitter:description" content={metaDescription} />
        <meta
          name="twitter:image"
          content={process.env.NEXT_PUBLIC_SITE_URL + '/static/images/logo.logo'}
        />

        <link rel="image_src" href={process.env.NEXT_PUBLIC_SITE_URL + '/static/images/logo.jpg'} />

        <script
          type="application/ld+json"
          id="product-jsonld"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(JsonObject) }}
        />

        <link rel="canonical" href={url} />

      </Head>
    </div>
  );
}

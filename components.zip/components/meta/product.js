import Head from "next/head";
import { useRouter } from "next/navigation";
import React from "react";

export default function ProductMeta({ product }) {
  const router = useRouter();

  const url = process.env.NEXT_PUBLIC_SITE_URL + router.asPath;
  const brandName = process.env.NEXT_PUBLIC_BRAND_NAME;
  const shopName = process.env.NEXT_PUBLIC_SITE_NAME;

  const maxLength = 255;
  const metaDescription = product.translated.metaDescription
    ? truncate(stripTags(product.translated.metaDescription), maxLength)
    : truncate(stripTags(product.translated.description.trim(), maxLength));
  const metaTitle = product.translated.metaTitle
    ? truncate(stripTags(product.translated.metaTitle), maxLength)
    : truncate(stripTags(product.translated.name), maxLength);
  const metaKeywords = product.translated.keywords;

  const metaPrice = product.calculatedPrice.unitPrice;

  const ProductUrl =
    process.env.NEXT_PUBLIC_SITE_URL +
    "/" +
    router.asPath;

  const date = new Date();

  function stripTags(str) {
    if (str === null || str === "") return false;
    else str = str.toString();
    return str.replace(/(<([^>]+)>)/gi, "").trim();
  }

  function truncate(str, n) {
    return str.length > n ? str.slice(0, n - 1) + " ...;" : str;
  }

  const JsonObject = {
    "@context": "https://schema.org/",
    "@type": "Product",
    name: metaTitle,
    image: [product.cover ? product.cover.media.url : null],
    description: metaDescription,
    sku: product.productNumber,
    mpn: product.productNumber,
    brand: {
      "@type": "Brand",
      name: brandName,
    },
    offers: {
      "@type": "Offer",
      priceCurrency: "EUR",
      url: url,
      price: product.calculatedPrice.unitPrice,
      itemCondition: "https://schema.org/NewCondition",
      availability: "https://schema.org/InStock",
      priceValidUntil:
        date.getFullYear() +
        "-" +
        String(date.getMonth() + 1).padStart(2, "0") +
        "-" +
        date.getDate(),
    },
    aggregateRating: {
      "@type": "AggregateRating",
      ratingValue: product.ratingAverage ? product.ratingAverage : 0,
      reviewCount: product.ratingAverage ? 10 : 0, //todo: get real review count
    },
  };

  return (
    <div>
      <Head>
        <title>{metaTitle}</title>
        <meta name="description" content={metaDescription} key="desc"/>

        <meta property="og:type" content="product"/>
        <meta property="og:site_name" content={shopName}/>
        <meta property="og:url" content={url}/>
        <meta property="og:title" content={metaTitle}/>

        <meta property="og:description" content={metaDescription}/>
        <meta
            property="og:image"
            content={product.cover ? product.cover.media.url : null}
        />

        <meta property="product:brand" content={brandName}/>
        <meta property="product:price:amount" content={metaPrice}/>
        <meta property="product:price:currency" content="EUR"/>
        <meta property="product:product_link" content={url}/>

        <meta name="twitter:card" content="product"/>
        <meta name="twitter:site" content={shopName}/>
        <meta name="twitter:title" content={metaTitle}/>
        <meta name="twitter:description" content={metaDescription}/>
        <meta
            name="twitter:image"
            content={product.cover ? product.cover.media.url : null}
        />

        <script
            type="application/ld+json"
            id="product-jsonld"
            dangerouslySetInnerHTML={{__html: JSON.stringify(JsonObject)}}
        />

        <link rel="canonical" href={url}/>
      </Head>

      <div itemType="https://schema.org/Product" itemScope>
        <meta itemProp="mpn" content={product.productNumber} />
        <meta itemProp="name" content={metaTitle} />
        {product.cover ? (
          <link itemProp="image" href={product.cover.media.url} />
        ) : null}
        <meta itemProp="description" content={metaDescription} />
        <div itemProp="offers" itemType="https://schema.org/Offer" itemScope>
          <link itemProp="url" href={ProductUrl} />
          <meta itemProp="availability" content="https://schema.org/InStock" />
          <meta itemProp="priceCurrency" content="EUR" />
          <meta
            itemProp="itemCondition"
            content="https://schema.org/NewCondition"
          />
          <meta itemProp="price" content={product.calculatedPrice.unitPrice} />
        </div>
        <meta itemProp="sku" content={product.productNumber} />
        <div itemProp="brand" itemType="https://schema.org/Brand" itemScope>
          <meta itemProp="name" content={brandName} />
        </div>
        <div
          itemProp="aggregateRating"
          itemType="https://schema.org/AggregateRating"
          itemScope
        >
          <meta
            itemProp="reviewCount"
            content={product.ratingAverage ? "10" : "0"}
          />
          <meta
            itemProp="ratingValue"
            content={product.ratingAverage ? product.ratingAverage : 0}
          />
        </div>
      </div>
    </div>
  );
}

import { useRef, useCallback } from 'react'
import { Swiper, SwiperSlide } from 'swiper/react'
import 'swiper/css'
import ProductCarousel from '@/components/tailgrid/ProductCarousel5'
import ArrowButtons from '@/components/tailgrid/ProductCarousel5/ArrowButtons'

const Preview = () => {
  const sliderRef = useRef(null)

  const handlePrev = useCallback(() => {
    if (!sliderRef.current) return
    sliderRef.current.swiper.slidePrev()
  }, [])

  const handleNext = useCallback(() => {
    if (!sliderRef.current) return
    sliderRef.current.swiper.slideNext()
  }, [])

  return (
    <>
      <section className='bg-white'>
        <div className='container mx-auto overflow-hidden pt-20 pb-20 lg:pt-[120px] lg:pb-[90px]'>
          <Swiper
            breakpoints={{
              640: {
                width: 640,
                slidesPerView: 1,
              },
              768: {
                width: 768,
                slidesPerView: 2.2,
              },
              1024: {
                width: 1024,
                slidesPerView: 2.2,
              },
              1280: {
                width: 1280,
                slidesPerView: 3,
              },
            }}
            loop={true}
            spaceBetween={30}
            ref={sliderRef}
            className='!overflow-visible'
          >
            <SwiperSlide>
              <ProductCarousel
                image='https://cdn.tailgrids.com/1.0/assets/images/ecommerce/products/product-carousel-05/image-01.jpg'
                link='/#'
                name='Apple Watch Series 7'
                details='Lorem ipsum dolor sit amet, consectetur adipiscing elit enim luctus et lorem.'
                price='$299'
                reviews='55'
              />
            </SwiperSlide>
            <SwiperSlide>
              <ProductCarousel
                image='https://cdn.tailgrids.com/1.0/assets/images/ecommerce/products/product-carousel-05/image-02.jpg'
                link='/#'
                name='iPhone 13 Pro Max'
                details='Lorem ipsum dolor sit amet, consectetur adipiscing elit enim luctus et lorem.'
                price='$999'
                reviews='32'
              />
            </SwiperSlide>
            <SwiperSlide>
              <ProductCarousel
                image='https://cdn.tailgrids.com/1.0/assets/images/ecommerce/products/product-carousel-05/image-03.jpg'
                link='/#'
                name='Macbook Pro 13” M1 2020'
                details='Lorem ipsum dolor sit amet, consectetur adipiscing elit enim luctus et lorem.'
                price='$1299'
                reviews='15'
              />
            </SwiperSlide>
            <SwiperSlide>
              <ProductCarousel
                image='https://cdn.tailgrids.com/1.0/assets/images/ecommerce/products/product-carousel-05/image-01.jpg'
                link='/#'
                name='Apple Watch Series 7'
                details='Lorem ipsum dolor sit amet, consectetur adipiscing elit enim luctus et lorem.'
                price='$299'
                reviews='55'
              />
            </SwiperSlide>
            <SwiperSlide>
              <ProductCarousel
                image='https://cdn.tailgrids.com/1.0/assets/images/ecommerce/products/product-carousel-05/image-02.jpg'
                link='/#'
                name='iPhone 13 Pro Max'
                details='Lorem ipsum dolor sit amet, consectetur adipiscing elit enim luctus et lorem.'
                price='$999'
                reviews='32'
              />
            </SwiperSlide>
            <SwiperSlide>
              <ProductCarousel
                image='https://cdn.tailgrids.com/1.0/assets/images/ecommerce/products/product-carousel-05/image-03.jpg'
                link='/#'
                name='Macbook Pro 13” M1 2020'
                details='Lorem ipsum dolor sit amet, consectetur adipiscing elit enim luctus et lorem.'
                price='$1299'
                reviews='15'
              />
            </SwiperSlide>
            <ArrowButtons handlePrev={handlePrev} handleNext={handleNext} />
          </Swiper>
        </div>
      </section>
    </>
  )
}

export default Preview

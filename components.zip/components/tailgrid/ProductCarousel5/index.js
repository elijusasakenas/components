import React from 'react';
import Star from '@/components/tailgrid/ProductCarousel5/Star';
import Image from 'next/image';

const ProductCarousel = ({ image, details, link, name, price, reviews }) => {
  return (
    <div className='overflow-hidden border border-[#e7e7e7] bg-white'>
      <div>
        <Image width={290} height={288} src={image} alt='product' className='w-full' />
      </div>
      <div className='p-6'>
        <h3>
          <a
            href={link}
            className='hover:text-primary xs:text-xl mb-4 block text-lg font-semibold text-black lg:text-lg xl:text-xl'
          >
            {name}
          </a>
        </h3>
        <p className='text-body-color text-base font-medium'>{details}</p>
      </div>
      <div className='flex justify-between border-t border-[#e7e7e7]'>
        <div className='xs:px-4 flex items-center py-4 px-3 lg:px-3 xl:px-4'>
          <Star />
          <Star />
          <Star />
          <Star />
          <Star />
          <span className='text-body-color pl-2 text-sm font-semibold'>
            ({reviews}) Reviews
          </span>
        </div>
        <div className='xs:px-4 border-l border-[#e7e7e7] py-4 px-3 lg:px-3 xl:px-4'>
          <span className='text-base font-semibold text-black'>{price}</span>
        </div>
      </div>
    </div>
  )
}

export default ProductCarousel

import React from 'react';

const SectionTitle = ({ title, details}) => {
  return (
    <div className='-mx-4 flex flex-wrap'>
      <div className='w-full px-4'>
        <div className='mx-auto mb-12 max-w-[510px] text-center lg:mb-20'>
          <h2 className='text-dark mb-4 text-3xl font-bold sm:text-4xl md:text-[40px]'>
            {title}
          </h2>
          <span className='bg-primary mx-auto mb-4 block h-1 w-24'></span>
          <p className='text-body-color text-base'>{details}</p>
        </div>
      </div>
    </div>
  )
}

export default SectionTitle;

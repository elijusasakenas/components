import { useRef, useCallback } from 'react'
import { Swiper, SwiperSlide } from 'swiper/react'
import 'swiper/css'
import ProductCarousel from '@/components/tailgrid/ProductCarousel3'
import SectionTitle from '@/components/tailgrid/ProductCarousel3/SectionTitle'
import ArrowButtons from '@/components/tailgrid/ProductCarousel3/ArrowButtons'

const Preview = () => {
  const sliderRef = useRef(null)

  const handlePrev = useCallback(() => {
    if (!sliderRef.current) return
    sliderRef.current.swiper.slidePrev()
  }, [])

  const handleNext = useCallback(() => {
    if (!sliderRef.current) return
    sliderRef.current.swiper.slideNext()
  }, [])

  return (
    <>
      <section>
        <div className='container mx-auto overflow-hidden pt-20 pb-20 lg:pt-[120px] lg:pb-[90px]'>
          <SectionTitle
            subtitle='Most Popular Products'
            title='Best Selling Items'
            details='There are many variations of passages of Lorem Ipsum available but the majority have suffered alteration in some form.'
          />
          <Swiper
            breakpoints={{
              640: {
                width: 640,
                slidesPerView: 1,
              },
              768: {
                width: 768,
                slidesPerView: 2.2,
              },
              1024: {
                width: 1024,
                slidesPerView: 2.2,
              },
              1280: {
                width: 1280,
                slidesPerView: 4,
              },
            }}
            loop={true}
            spaceBetween={30}
            ref={sliderRef}
            className='!overflow-visible'
          >
            <SwiperSlide>
              <ProductCarousel
                image='https://cdn.tailgrids.com/1.0/assets/images/ecommerce/products/product-carousel-03/image-01.jpg'
                link='/#'
                name='Smart Watch For Man'
                price='$150.00'
                discountedPrice='$75.00'
                rating='5.00 Rating'
              />
            </SwiperSlide>
            <SwiperSlide>
              <ProductCarousel
                hotItem
                image='https://cdn.tailgrids.com/1.0/assets/images/ecommerce/products/product-carousel-03/image-02.jpg'
                link='/#'
                name='Stylish Backpack'
                price='$189.00'
                rating='5.00 Rating'
              />
            </SwiperSlide>
            <SwiperSlide>
              <ProductCarousel
                newItem
                image='https://cdn.tailgrids.com/1.0/assets/images/ecommerce/products/product-carousel-03/image-03.jpg'
                link='/#'
                name='Luxury Wallet For Male'
                price='$95.00'
                rating='5.00 Rating'
              />
            </SwiperSlide>
            <SwiperSlide>
              <ProductCarousel
                image='https://cdn.tailgrids.com/1.0/assets/images/ecommerce/products/product-carousel-03/image-04.jpg'
                link='/#'
                name='Polo T-shirt For Man'
                price='$25.00'
                rating='5.00 Rating'
              />
            </SwiperSlide>
            <SwiperSlide>
              <ProductCarousel
                image='https://cdn.tailgrids.com/1.0/assets/images/ecommerce/products/product-carousel-03/image-01.jpg'
                link='/#'
                name='Smart Watch For Man'
                price='$150.00'
                discountedPrice='$75.00'
                rating='5.00 Rating'
              />
            </SwiperSlide>
            <SwiperSlide>
              <ProductCarousel
                hotItem
                image='https://cdn.tailgrids.com/1.0/assets/images/ecommerce/products/product-carousel-03/image-02.jpg'
                link='/#'
                name='Stylish Backpack'
                price='$189.00'
                rating='5.00 Rating'
              />
            </SwiperSlide>
            <SwiperSlide>
              <ProductCarousel
                newItem
                image='https://cdn.tailgrids.com/1.0/assets/images/ecommerce/products/product-carousel-03/image-03.jpg'
                link='/#'
                name='Luxury Wallet For Male'
                price='$95.00'
                rating='5.00 Rating'
              />
            </SwiperSlide>
            <SwiperSlide>
              <ProductCarousel
                image='https://cdn.tailgrids.com/1.0/assets/images/ecommerce/products/product-carousel-03/image-04.jpg'
                link='/#'
                name='Polo T-shirt For Man'
                price='$25.00'
                rating='5.00 Rating'
              />
            </SwiperSlide>
            <ArrowButtons handlePrev={handlePrev} handleNext={handleNext} />
          </Swiper>
        </div>
      </section>
    </>
  )
}

export default Preview

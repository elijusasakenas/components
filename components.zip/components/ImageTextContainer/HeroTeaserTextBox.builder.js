import { Builder } from "@builder.io/react";
import HeroTeaserTextBox from "@/components/ImageTextContainer/HeroTeaserTextBox";

// Register HeroTeaserTextBox component
Builder.registerComponent(HeroTeaserTextBox, {
  name: "HeroTeaserTextBox",
  screenshot: 'https://cdn.builder.io/api/v1/image/assets%2F90182f3615654f8c9be2b012f26cc6c0%2F5f8d18616b1241bf99c34ce544582323',
  inputs: [
    {
      name: "heroTeaserSettings",
      friendlyName: "Hero Teaser Einstellungen",
      type: "object",
      subFields: [
        {
          name: "bgImageDesktop",
          friendlyName: "Hintergrundbild Desktop",
          type: "file",
        },
        {
          name: "bgImageTablet",
          friendlyName: "Hintergrundbild Tablet",
          type: "file",
        },
        {
          name: "bgImageMobile",
          friendlyName: "Hintergrundbild Mobile",
          type: "file",
        },
        {
          name: "layout",
          friendlyName: "Kantenposition",
          type: "text",
          enum: [
            { label: "Standard", value: "default" },
            { label: "Oben links", value: "topLeft" },
            { label: "Oben rechts", value: "topRight" },
            { label: "Unten links", value: "bottomLeft" },
            { label: "Unten rechts", value: "bottomRight" },
          ],
        },
        {
          name: "edgeColor",
          friendlyName: "Kantenfarbe",
          type: "text",
          enum: [
            { label: "Weiß", value: "edgeWhite" },
            { label: "Blau", value: "edgeBlue" },
          ],
        },
      ],
    },
    {
      name: "textBoxSettings",
      friendlyName: "Text Box Einstellungen",
      type: "object",
      subFields: [
        {
          name: "headline",
          friendlyName: "Überschrift",
          type: "string",
          defaultValue: "Headline",
        },
        {
          name: "bodyText",
          friendlyName: "Text",
          type: "longText",
          defaultValue: "Body Text",
        },
        {
          name: "button",
          friendlyName: "Button anzeigen",
          type: "boolean",
        },
        {
          name: "buttonText",
          friendlyName: "Button Text",
          type: "string",
          defaultValue: "Button Text",
        },
        {
          name: "buttonLink",
          friendlyName: "Button Link",
          type: "string",
          defaultValue: "#",
        },
        {
          name: "scrollIndicator",
          friendlyName: "Scroll-Indikator anzeigen",
          type: "boolean",
        },
        {
          name: "scrollIndicatorAnchor",
          friendlyName: "Scroll-Indikator Link",
          type: "string",
          defaultValue: "#",
        },
      ],
    },
  ],
});

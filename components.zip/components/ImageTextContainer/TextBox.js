'use client'

import React, {useEffect, useState} from 'react';

const BadgeTextBox = ({layout, textBoxSettings}) => {
  const [edgePosition, setEdgePosition] = useState('default');

  useEffect(() => {
    if (layout === 'default' || layout === 'topLeft') {
      setEdgePosition('topLeft');
    } else if (layout === 'topRight') {
      setEdgePosition('topRight');
    } else if (layout === 'bottomLeft') {
      setEdgePosition('bottomLeft topRight');
    } else if (layout === 'bottomRight') {
      setEdgePosition('bottomRight topLeft');
    }
  }, [layout]);

  return (
    <div className="flex flex-col justify-center text-white max-w-[327px] lg:max-w-[480px]">
      <div
        className={`flex flex-col justify-center px-8 lg:px-10 pt-10 pb-6 text-white bg-orange-200 bg-opacity-90 relative edgeTextBox
        ${edgePosition}
      `}
      >
        
        <div className="text-3xl lg:text-5xl font-bold leading-8 uppercase lg:text-center">
          {textBoxSettings?.headline ? textBoxSettings.headline : 'Lorem Ipsum'}
        </div>
        
        <div className="mt-3 text-base lg:text-lg font-medium leading-6 text-ellipsis lg:text-center line-clamp-4">
          {textBoxSettings?.bodyText ? textBoxSettings.bodyText : 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.'}
        </div>

        {textBoxSettings?.button && (
          <>
            <div className="flex justify-center mt-6">
              <button href={textBoxSettings.buttonLink} className="btn-secondary">
                {textBoxSettings.buttonText}
              </button>
            </div>
          </>
        )}

        {textBoxSettings?.scrollIndicator && (
          <div className="flex justify-center mt-6">
            <a href={textBoxSettings?.scrollIndicatorAnchor} className="">
              <svg
                width="41"
                height="40"
                viewBox="0 0 41 40"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M31.2227 12.0182L21.6979 21.5885C21.4701 21.7708 21.151 21.7708 20.9232 21.5885L11.3984 12.0182C11.1706 11.7904 11.1706 11.4714 11.3984 11.2435L12.2643 10.332C12.4922 10.1497 12.8568 10.1497 13.0391 10.332L21.3333 18.5807L29.582 10.332C29.7643 10.1497 30.1289 10.1497 30.3568 10.332L31.2227 11.2435C31.4505 11.4714 31.4505 11.7904 31.2227 12.0182ZM31.2227 18.5352C31.4505 18.763 31.4505 19.082 31.2227 19.3099L21.6979 28.8802C21.4701 29.0625 21.151 29.0625 20.9232 28.8802L11.3984 19.3099C11.1706 19.082 11.1706 18.763 11.3984 18.5352L12.2643 17.6237C12.4922 17.4414 12.8568 17.4414 13.0391 17.6237L21.3333 25.8724L29.582 17.6237C29.7643 17.4414 30.1289 17.4414 30.3568 17.6237L31.2227 18.5352Z"
                  fill="black"
                />
              </svg>
            </a>
          </div>
        )}
      </div>
    </div>
  );
};

export default BadgeTextBox;

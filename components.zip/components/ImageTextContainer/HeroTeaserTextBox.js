'use client'

import React, {useEffect, useState} from 'react';
import Image from "next/image";
import BadgeTextBox from "@/components/ImageTextContainer/TextBox";

const HeroTeaserTextBox = (props) => {
  const layout = props.heroTeaserSettings ? props.heroTeaserSettings.layout : 'default';
  const color = props.heroTeaserSettings ? props.heroTeaserSettings.edgeColor : 'blue';
  const [edgePosition, setEdgePosition] = useState('');
  const [textBoxPosition, setTextBoxPosition] = useState('md:justify-end');

  useEffect(() => {
    if (layout === 'default') {
      setEdgePosition('default');
    } else if (layout === 'topLeft') {
      setEdgePosition('topLeft');
      setTextBoxPosition('md:justify-end');
    } else if (layout === 'topRight') {
      setEdgePosition('topRight');
      setTextBoxPosition('md:justify-start');
    } else if (layout === 'bottomLeft') {
      setEdgePosition('bottomLeft');
      setTextBoxPosition('md:justify-start');
    } else if (layout === 'bottomRight') {
      setEdgePosition('bottomRight');
      setTextBoxPosition('md:justify-end');
    }
  }, [layout]);

  return (
    <div
      className={`hero-teaser-text-box max-w-7xl mx-auto w-full relative flex justify-center self-stretch pt-60 md:pt-20 lg:pt-64 pb-8 md:pb-14 px-6 md:px-12 lg:px-28 ${textBoxPosition} transition-all duration-300 ease-in-out edgeHeroTeaser overflow-hidden
        ${edgePosition} ${color}`}
    >
      {props.heroTeaserSettings && (
      <>
        <Image
          src={props.heroTeaserSettings?.bgImageMobile}
          width={375}
          height={676}
          className="absolute inset-0 z-0 w-full h-full object-cover object-top sm:hidden"
          alt=''
        />
        <Image
          src={props.heroTeaserSettings?.bgImageTablet}
          width={768}
          height={480}
          className="absolute inset-0 z-0 w-full h-full object-cover object-top hidden sm:block lg:hidden"
          alt=''
        />
        <Image
          src={props.heroTeaserSettings?.bgImageDesktop}
          width={1260}
          height={750}
          className="absolute inset-0 z-0 w-full h-full object-cover object-top hidden lg:block"
          alt=''
        />
      </>
      )}
      <BadgeTextBox layout={layout} textBoxSettings={props.textBoxSettings} />
    </div>
  );
};

export default HeroTeaserTextBox;

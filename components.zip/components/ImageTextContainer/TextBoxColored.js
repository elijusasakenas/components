'use client'

import { useState, useEffect } from "react";
import Link from "next/link";
import Image from "next/image";

const TextBoxColored = (props) => {
  const [boxColor, setBoxColor] = useState('text-white bg-blue-300');
  const [hasImage, setHasImage] = useState(false);

  useEffect(() => {
    if (props.bgColor === 'white') {
      setBoxColor('text-base-50 bg-white');
    } else if (props.bgColor === 'blue') {
      setBoxColor('text-base-500 bg-blue-300');
    }

    if(props.imageDesktop || props.imageTablet) {
      setHasImage(true);
    } else {
      setHasImage(false);
    }
  }, [props]);

  return (
    <div className={`text-box-colored max-w-7xl mx-auto w-full relative flex flex-col justify-center items-start self-stretch px-6 md:px-12 lg:px-28 py-14 md:pt-10 lg:pt-20 lg:pb-28 topLeft ${boxColor}`}>
        {props.headline && (
          <div className="text-3xl uppercase w-full lg:text-center lg:text-5xl">
            {props.headline}
          </div>
        )}
        
        {props.imageMobile && (
          <Image
            src={props.imageMobile}
            width={375}
            height={676}
            className="mt-6 md:mt-10 w-full sm:hidden"
            alt=""
          />
        )}
        {props.imageTablet && (
          <Image
            src={props.imageTablet}
            width={768}
            height={480}
            className="mt-6 md:mt-10 w-full hidden sm:block lg:hidden"
            alt=""
          />
        )}
        {props.imageDesktop && (
          <Image
            src={props.imageDesktop}
            width={1260}
            height={750}
            className="mt-6 md:mt-10 w-full hidden lg:block"
            alt=""
          />
        )}
        
        <div className={`lg:flex items-start justify-start gap-6 w-full ${hasImage ? 'lg:mt-16' : ''}`}>
          <div className={`flex items-stretch justify-start gap-5 w-full pl-1.5 mt-6 md:mt-16 lg:mt-0 lg:mr-8`}>
            {props.icon && (
              <>
                <div className="w-[80px] md:w-[100px]">
                  <Image
                    src={props.icon}
                    width={100}
                    height={100}
                    alt=""
                    className="shrink-0 my-auto w-[80px] md:w-[100px]"
                  />
                </div>
                
                <div className="w-px border border-white border-solid"></div> 
              </>   
            )}
          
            <div className="flex flex-col flex-1">
              <div className="text-4xl md:text-7xl uppercase hyphens-auto">{props.iconTitle ? props.iconTitle : 'Lorem Ipsum'}</div>
              <div className="mt-2 text-sm uppercase hyphens-auto">{props.iconText ? props.iconText : 'Lorem Ipsum'}</div>
            </div>
          </div>

          <div className="lg:px-8 lg:pt-3 w-full lg:min-w-[400px]">
            <div className="mt-6 lg:mt-0 text-base">
              {props.text ? props.text : 'Lorem Ipsum'}
            </div>

            {props.button && (
              <div className="mt-6 px-6 md:inline-block">
                <Link href={props.buttonLink ? props.buttonLink : '#'} className="btn btn-primary">{props.buttonText ? props.buttonText : 'Lorem Ipsum'}</Link>
              </div>
            )}
          </div>
        </div>
    </div>
  );
}

export default TextBoxColored;
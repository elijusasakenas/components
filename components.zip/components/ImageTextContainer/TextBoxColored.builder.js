import { Builder } from "@builder.io/react";
import TextBoxColored from "@/components/ImageTextContainer/TextBoxColored";

// Register TextBoxColored component
Builder.registerComponent(TextBoxColored, {
  name: "TextBoxColored",
  friendlyName: "Text Box Colored",
  screenshot: 'https://cdn.builder.io/api/v1/image/assets%2F90182f3615654f8c9be2b012f26cc6c0%2F55ccb566071b436cb6a3e656c1a18b90',
  inputs: [
    {
      name: "bgColor",
      friendlyName: "Hintergrundfarbe",
      type: "text",
      defaultValue: "blue",
      enum: [
        { label: "Weiß", value: "white" },
        { label: "Blau", value: "blue" },
      ],
    },
    {
      name: "headline",
      friendlyName: "Überschrift",
      type: "string",
    },
    {
      name: "imageDesktop",
      friendlyName: "Bild Desktop",
      type: "file",
    },
    {
      name: "imageTablet",
      friendlyName: "Bild Tablet",
      type: "file",
    },
    {
      name: "imageMobile",
      friendlyName: "Bild Mobile",
      type: "file",
    },
    {
      name: "icon",
      friendlyName: "Icon",
      type: "file",
    },
    {
      name: "iconTitle",
      friendlyName: "Icon Titel",
      type: "string",
      defaultValue: "Icon Titel",
    },
    {
      name: "iconText",
      friendlyName: "Icon Text",
      type: "string",
      defaultValue: "Icon Text",
    },
    {
      name: "text",
      friendlyName: "Text",
      type: "longText",
      defaultValue: "Lorem ipsum dolor sit amet.",
    },
    {
      name: "button",
      friendlyName: "Button anzeigen",
      type: "boolean",
    },
    {
      name: "buttonText",
      friendlyName: "Button Text",
      type: "string",
      defaultValue: "Button Text",
    },
    {
      name: "buttonLink",
      friendlyName: "Button Link",
      type: "string",
      defaultValue: "#",
    },
  ],
});

import { useState } from "react";
import { ProductReviewSave, ProductReviews } from "@/shopware/product_reviews";
import { StarIcon } from "@heroicons/react/20/solid";
import Alert from "@mui/material/Alert";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import Rating from "@mui/material/Rating";
import TextField from "@mui/material/TextField";
import useMediaQuery from "@mui/material/useMediaQuery";
import { useTheme } from '@mui/material/styles';

function classNames(...classes) {
  return classes.filter(Boolean).join(" ");
}

export default function Reviews({ product }) {
  const productId = product.parentId ? product.parentId : product.id;
  const productReviews = ProductReviews(productId);
  const [ratingValue, setRatingValue] = useState(5);
  const [reviewResponse, setReviewResponse] = useState("");
  const [writeReview, setWriteReview] = useState(false);
  const theme = useTheme();
  const fullScreen = useMediaQuery(theme.breakpoints.down("md"));

  const handleShowReviewForm = () => {
    setWriteReview(true);
    //ProductReviewSave(productId, {"title":"Test","content":"Test","points":"5"});
  };
  const handleCloseReviewForm = () => {
    setWriteReview(false);
  };

  async function handleSaveReview(event) {
    event.preventDefault();
    const formData = {
      title: event.target.form.reviewTitle.value,
      content: event.target.form.reviewContent.value,
      points: ratingValue,
    };
    ProductReviewSave(productId, formData).then((res) => {
      setReviewResponse(res ? res.message : "Vielen Dank für Ihre Bewertung.");
    });
  }

  function onChangeRatingValue(value) {
    setRatingValue(value);
  }

  if (!productReviews) {
    return <div className="bg-white"></div>;
  }
  const ratingCount = getRatingCount(productReviews);

  return (
    <div>
      <div className="mx-auto max-w-2xl my-6 lg:grid lg:max-w-7xl lg:grid-cols-12 lg:gap-x-8">
        <div className="col-span-12">
          <p className="h3">Kundenbewertungen</p>
          <div className="relative mb-6">
            <div
              className="absolute inset-0 flex items-center"
              aria-hidden="true"
            >
              <div className="w-full border-t border-gray-300" />
            </div>
          </div>
        </div>

        <div className="lg:col-span-4">
          {productReviews.length > 0 ? (
            (
              <div className="mt-3 flex items-center">
                <div>
                  <div className="flex items-center">
                    {[0, 1, 2, 3, 4].map((rating, key) => (
                      <StarIcon
                        key={key}
                        className={classNames(
                          product.ratingAverage > rating
                            ? "text-yellow-400"
                            : "text-neutral-300",
                          "h-5 w-5 flex-shrink-0"
                        )}
                        aria-hidden="true"
                      />
                    ))}
                  </div>
                  <p className="sr-only">
                    {product.ratingAverage} von 5 Sternen
                  </p>
                </div>
                <p className="ml-2 text-sm text-neutral-900">
                  {" "}
                  von insgesamt {productReviews.length} Bewertungen
                </p>
              </div>
            ) && (
              <div className="mt-6">
                <dl className="space-y-3">
                  {ratingCount.map((count, key) => (
                    <div key={key} className="flex items-center text-sm">
                      <dt className="flex flex-1 items-center">
                        <p className="w-3 font-medium text-neutral-900">
                          {count.rating}
                          <span className="sr-only"> star reviews</span>
                        </p>
                        <div
                          aria-hidden="true"
                          className="ml-1 flex flex-1 items-center"
                        >
                          <StarIcon
                            className={classNames(
                              count.count > 0
                                ? "text-yellow-400"
                                : "text-neutral-300",
                              "h-5 w-5 flex-shrink-0"
                            )}
                            aria-hidden="true"
                          />

                          <div className="relative ml-3 flex-1">
                            <div className="h-3 rounded-full border border-gray-200 bg-neutral-100" />
                            {count.count > 0 ? (
                              <div
                                className="absolute inset-y-0 rounded-full border border-yellow-400 bg-yellow-400"
                                style={{
                                  width: `calc(${count.count} / ${productReviews.length} * 100%)`,
                                }}
                              />
                            ) : null}
                          </div>
                        </div>
                      </dt>
                      <dd className="ml-3 w-10 text-right text-sm tabular-nums text-neutral-900">
                        {Math.round(
                          (count.count / productReviews.length) * 100
                        )}
                        %
                      </dd>
                    </div>
                  ))}
                </dl>
              </div>
            )
          ) : (
            <div>Keine Bewertungen vorhanden</div>
          )}
          <div className="mt-10">
            <div className="h3">Bewertung schreiben</div>
            <p className="mt-1 text-sm text-neutral-600">
              Bewertungen werden nach Überprüfung freigeschaltet.
            </p>

            <button
              onClick={handleShowReviewForm}
              className={
                "mt-6 inline-flex w-full items-center justify-center rounded-md border border-gray-300 bg-white px-8 py-2 text-sm font-medium text-neutral-900 hover:bg-neutral-50 sm:w-auto lg:w-full"
              }
            >
              Bewertung schreiben
            </button>
          </div>
        </div>

        <div className="mt-16 lg:col-span-7 lg:col-start-6 lg:mt-0">
          <h3 className="sr-only">aktuelle Bewertungen</h3>
          <div className="flow-root">
            <div className="-my-12 divide-y divide-gray-200">
              {productReviews.map((review, key) => (
                <div key={key} className="py-12">
                  <div className="flex items-center">
                    <div className="ml-0">
                      <h4 className="text-sm font-bold text-neutral-900">
                        {review.title}
                      </h4>
                      <div className="mt-1 flex items-center">
                        {[0, 1, 2, 3, 4].map((rating, key) => (
                          <StarIcon
                            key={key}
                            className={classNames(
                              review.points > rating
                                ? "text-yellow-400"
                                : "text-neutral-300",
                              "h-5 w-5 flex-shrink-0"
                            )}
                            aria-hidden="true"
                          />
                        ))}
                      </div>
                      <p className="sr-only">{review.points} von 5 Sternen</p>
                    </div>
                  </div>

                  <div
                    className="mt-4 space-y-6 text-base italic text-neutral-600"
                    dangerouslySetInnerHTML={{ __html: review.content }}
                  />
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
      <Dialog
        open={writeReview}
        onClose={handleCloseReviewForm}
        fullScreen={fullScreen}
        sx={{
          minWidth: "80%",
        }}
      >
        <DialogContent>
          <form>
            <div className="space-y-12">
              <div className="pb-2">
                <h2 className="text-base font-semibold leading-7 text-neutral-900">
                  Schreiben Sie eine Bewertung für {product.translated.name}
                </h2>
                <p className="mt-1 text-sm leading-6 text-neutral-600">
                  Bewertungen werden nach Überprüfung freigeschaltet.
                </p>
                {reviewResponse.length > 0 ? (
                  <Alert severity="info" className="mt-2">
                    {reviewResponse}
                  </Alert>
                ) : null}
                <div className="mt-10">
                  <div className="col-span-full">
                    <label
                      htmlFor="about"
                      className="block text-sm font-medium leading-6 text-neutral-900"
                    >
                      Ihre Bewertung
                    </label>
                    <Rating
                      name="size-medium"
                      defaultValue={5}
                      onChange={(event, newValue) => {
                        onChangeRatingValue(newValue);
                      }}
                    />
                  </div>
                  <div className="mt-2">
                    <TextField
                      required
                      fullWidth
                      id="reviewTitle"
                      label="Zusammenfassung"
                      defaultValue=""
                      className={""}
                    />
                  </div>
                  <div className="col-span-full">
                    <div className="mt-2">
                      <TextField
                        label="Ihre Meinung"
                        required
                        fullWidth
                        id="reviewContent"
                        multiline
                        maxRows={4}
                        inputProps={{ minLength: 40 }}
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <p className="mt-3 text-sm leading-6 text-neutral-600 text-right text-xs">
              Die mit einem * markierten Felder sind Pflichtfelder.
              <br />
              Ich habe die Datenschutzbestimmungen zur Kenntnis genommen.
            </p>
            <div className="mt-6 flex items-center justify-end gap-x-6 pb-8">
              <DialogActions>
                <button
                  type="button"
                  className="text-sm leading-6 text-neutral-900"
                  onClick={handleCloseReviewForm}
                >
                  Abbrechen
                </button>
                <button
                  onClick={handleSaveReview}
                  type="submit"
                  className="rounded-md bg-blue-600 px-3 py-2 text-sm font-semibold text-white shadow-sm hover:bg-blue-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-600"
                >
                  Speichern
                </button>
              </DialogActions>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function getRatingCount(reviews) {
  const ratingCount = [
    { rating: 1, count: 0 },
    { rating: 2, count: 0 },
    { rating: 3, count: 0 },
    { rating: 4, count: 0 },
    { rating: 5, count: 0 },
  ];
  reviews.forEach((review) => {
    ratingCount[Math.ceil(review.points) - 1].count++;
  });

  return ratingCount.reverse();
}

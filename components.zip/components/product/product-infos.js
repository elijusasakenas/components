import { NumericFormat } from "react-number-format";
import Link from "next/link";

const ProductInfos = ({ detail }) => {
  return (
    <>
      <h1 className="p-0 text-neutral-900">{detail.translated?.name}</h1>
      <div className="mt-3">
        <h2 className="sr-only">Produktinformationen</h2>
        {detail.calculatedPrice?.listPrice ? (
          <p className={"text-red-600 line-through"}>
            <NumericFormat
              value={detail.calculatedPrice?.unitPrice}
              decimalSeparator=","
              decimalScale="2"
              fixedDecimalScale="true"
              displayType={"text"}
              thousandSeparator="."
              suffix={" €*"}
            />
          </p>
        ) : null}
        <p className="text-3xl tracking-tight text-neutral-900">
          <NumericFormat
            value={detail.calculatedPrice?.unitPrice}
            decimalSeparator=","
            decimalScale="2"
            fixedDecimalScale="true"
            displayType={"text"}
            thousandSeparator="."
            suffix={" €*"}
          />
        </p>
        <span className="truncate text-xs text-left block text-neutral-900">
          {detail.unit
            ? "Inhalt: " +
              detail.purchaseUnit +
              " " +
              detail.unit.translated.shortCode
            : null}
          {detail.calculatedPrice?.referencePrice ? (
            <NumericFormat
              value={detail.calculatedPrice.referencePrice.price}
              decimalSeparator=","
              decimalScale="2"
              fixedDecimalScale="true"
              displayType={"text"}
              thousandSeparator="."
              prefix={" ("}
              suffix={
                " €* / " +
                detail.calculatedPrice.referencePrice.referenceUnit +
                " " +
                detail.calculatedPrice.referencePrice.unitName +
                ")"
              }
            />
          ) : null}
          {detail.purchaseUnit === detail.referenceUnit && detail.unit ? (
            <NumericFormat
              value={detail.calculatedPrice.unitPrice}
              decimalSeparator=","
              decimalScale="2"
              fixedDecimalScale="true"
              displayType={"text"}
              thousandSeparator="."
              prefix={" ("}
              suffix={
                " €* / " +
                detail.referenceUnit +
                " " +
                detail.unit.translated.shortCode +
                ")"
              }
            />
          ) : null}
        </span>
        <span className={"text-xs text-neutral-900"}>
          inkl. MwSt., zzgl.{" "}
          <Link href={"/versand-zahlung"} className={"underline"}>
            Versandkosten
          </Link>
        </span>
        {detail.deliveryTime && (
          <span className={"text-xs text-neutral-900 block"}>
            Lieferzeit: {detail.deliveryTime.translated.name}
          </span>
        )}
        <ul className={"list-disc text-xs text-neutral-400 list-inside"}>
          <li>Mo-Do bis 9 Uhr bestellt: Lieferung am Folgetag</li>
          <li>Do. nach 9 Uhr bestellt: Lieferung am Dienstag</li>
          <li>Sonn- und Feiertage: keine Zustellung</li>
        </ul>
      </div>
    </>
  );
};

export default ProductInfos;

import { useState } from "react";
import { AddToCart } from "@/shopware/cart";
import axiosInstance from "@/shopware/client";

const BuyForm = ({ detail, configurator, setIsLoading, setDetail }) => {
  const [addCart, setAddCart] = useState(false);

  const handleAddToCartClick = () => {
    setAddCart(true);
  };

  const handleSearch = async (search) => {
    if (detail.parentId) {
      setIsLoading(true);
      await axiosInstance
        .post(`/product/${detail.parentId}/find-variant`, {
          options: [search.id],
          switchGroup: search.groupId,
        })
        .then(function (res) {
          axiosInstance
            .post(`/product/${res.data.variantId}`)
            .then(function (res) {
              setDetail(res.data.product);
              setIsLoading(false);
            });
        });
    }
  };

  const handleVariantSelection = (option) => {
    handleSearch(option);
  };

  return (
    <form
      className={`mt-6 py-4 -mx-6 px-6 md:relative md:bg-none md:z-0 transition-transform`}
    >
      {configurator && configurator[0] && (
        <>
          <h3 className="text-sm text-neutral-600 mb-1 font-bold">Inhalt</h3>
          {configurator[0].options?.map((option) => (
            <span
              key={option.id}
              data-value={option.id}
              className={
                (option.id === detail.optionIds[0]
                  ? "bg-neutral-100 border border-blue-600"
                  : "bg-neutral-50") +
                " cursor-pointer inline-flex items-center rounded-full  hover:bg-neutral-100 mr-1 px-4 py-2 text-xs font-medium text-neutral-600 ring-1 ring-inset ring-gray-500/10"
              }
              onClick={() => handleVariantSelection(option)}
            >
              {option.translated.name}
            </span>
          ))}
        </>
      )}

      <div className="mt-4">
        <button
          onClick={handleAddToCartClick}
          type="button"
          className="w-full flex flex-1 items-center justify-center rounded-md border border-transparent bg-blue-600 py-3 px-8 text-base font-medium text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 focus:ring-offset-gray-50"
        >
          {addCart && (
            <AddToCart
              productId={detail.id}
              quantity={1}
              setAddCart={setAddCart}
              product={detail}
              categoryName={
                detail.seoCategory?.translated?.name
                  ? detail.seoCategory.translated.name
                  : null
              }
            />
          )}
          {!addCart && <span>In den Warenkorb</span>}
        </button>
      </div>
    </form>
  );
};

export default BuyForm;

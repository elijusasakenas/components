import { useCallback, useRef } from "react";
import "swiper/css";
import { Swiper, SwiperSlide } from "swiper/react";
import dynamic from 'next/dynamic';
import { ProductCrossSelling } from "@/shopware/product_cross-selling";

const ArrowButtons = dynamic(() => import("@/components/tailgrid/ProductCarousel5/ArrowButtons"), {
  ssr: false,
});

const ProductBox = dynamic(() => import("@/components/product/box"), {
  ssr: false,
});

export default function CrossSelling({ product }) {
  const productId = product.parentId ? product.parentId : product.id;
  const productCrossSelling = ProductCrossSelling(productId);

  const sliderRef = useRef(null);

  const handlePrev = useCallback(() => {
    if (!sliderRef.current) return;
    sliderRef.current.swiper.slidePrev();
  }, []);

  const handleNext = useCallback(() => {
    if (!sliderRef.current) return;
    sliderRef.current.swiper.slideNext();
  }, []);

  if (!productCrossSelling) {
    return <div className="bg-white">no non cross-selling</div>;
  }

  return (
    <section>
      {productCrossSelling.map((crossSelling, key) =>
        crossSelling.products.length > 0 ? (
          <div
            key={key}
            className="container mx-auto overflow-hidden pt-20 pb-20 lg:pt-[120px] lg:pb-[90px]"
          >
            <div className="h2 my-4">
              {crossSelling.crossSelling.translated.name}
            </div>
            <Swiper
              breakpoints={{
                640: {
                  width: 640,
                  slidesPerView: 1,
                },
                768: {
                  width: 768,
                  slidesPerView: 2,
                },
                1024: {
                  width: 1024,
                  slidesPerView: 4,
                },
                1280: {
                  width: 1280,
                  slidesPerView: 4,
                },
              }}
              loop={true}
              spaceBetween={30}
              ref={sliderRef}
              className="!overflow-visible"
            >
              {crossSelling.products.map((product, key2) =>
                product.seoUrls ? (
                  <SwiperSlide key={key2}>
                    <div className="overflow-hidden rounded-lg bg-white">
                      <ProductBox product={product} key={product.id} />
                    </div>
                  </SwiperSlide>
                ) : null
              )}
              <ArrowButtons handlePrev={handlePrev} handleNext={handleNext} />
            </Swiper>
          </div>
        ) : null
      )}
    </section>
  );
}

const Description = ({ description }) => (
  <div className="mt-6 lg:hidden">
    <div
      className="text-base text-neutral-700"
      dangerouslySetInnerHTML={{
        __html: description,
      }}
    />
  </div>
);

export default Description;
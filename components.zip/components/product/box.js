import ProductBoxImage from "@/components/product/product_box_image";
import { AddToCart } from "@/shopware/cart";
import { useState } from "react";
import { NumericFormat } from "react-number-format";

export default function ProductBox({ product, categoryName }) {
  const isAvailable =
    product.availableStock >= product.minPurchase ? true : false;
  const displayFrom = product.calculatedPrices.length > 1;
  const displayBuyButton = isAvailable && !displayFrom;

  const [addCart, setAddCart] = useState(false);

  const handleClick = () => {
    setAddCart(true);
  };

  return (
    <>
      <div className="flex w-[404px] py-6 px-14 flex-col items-center gap-10">
        <a
          href={`/${product.seoUrls[0].seoPathInfo}`}
          className={"group"}
          key={product.id}
          title={product.translated.name}
        >
          <div className="flex w-[340px] h-[193px] justify-center items-center relative">
            <ProductBoxImage product={product} />
          </div>
          <div className="flex px-2 flex-col justify-center items-start gap-8">
            <div>
              <div className="headline-small leading-7">
                {product.translated.name}
              </div>
            </div>
            <div className="flex flex-col justify-center items-start gap-4 leading-9">
              {/* Description ONHOLD */}
              <p>A ullamcorper tortor morbi sem porttitor erat nunc. Tortor a sed </p>
              <p>Porttitor erat nunc Tortor a sed asflgiraöse</p>
              <p>Porttitor erat nunc Tortor a sed asflgiraöse</p>
              <p>Porttitor erat nunc Tortor a sed asflgiraöse</p>
            </div>
            <div>
              <div
                aria-hidden="true"
                className="absolute inset-x-0 bottom-0 h-36 bg-gradient-to-t from-black-400 opacity-50"
              />
              <div className="body-emphasis">
                <NumericFormat
                  value={product.calculatedPrice.unitPrice}
                  decimalSeparator=","
                  decimalScale="2"
                  fixedDecimalScale="true"
                  displayType={"text"}
                  thousandSeparator="."
                  suffix={" €*"}
                />
              </div>
              <div className="body-emphasis">
                {product.calculatedPrice.referencePrice
                  ? "Inhalt: " +
                  product.calculatedPrice.referencePrice.purchaseUnit +
                  " " +
                  product.calculatedPrice.referencePrice.unitName
                  : null}
                {product.calculatedPrice.referencePrice ? (
                  <NumericFormat
                    value={product.calculatedPrice.referencePrice.price}
                    decimalSeparator=","
                    decimalScale="2"
                    fixedDecimalScale="true"
                    displayType={"text"}
                    thousandSeparator="."
                    prefix={" ("}
                    suffix={
                      " €* / " +
                      product.calculatedPrice.referencePrice.referenceUnit +
                      " " +
                      product.calculatedPrice.referencePrice.unitName +
                      ")"
                    }
                  />
                ) : null}
              </div>
            </div>
          </div>
          <div>
            {displayBuyButton ? (
              <div className="mt-6">
                <button
                  onClick={handleClick}
                  type="button"
                  className="flex py-5 px-8 justify-center items-center gap-2 bg-orange-200 rounded-lg text-[18px] font-bold leading-[18px] tracking-[0.9px] uppercase text-center text-white"
                  data-buy-btn="true"
                >
                  {addCart && (
                    <AddToCart
                      productId={product.id}
                      quantity={1}
                      setAddCart={setAddCart}
                      product={product}
                      categoryName={categoryName}
                    />
                  )}
                  {!addCart && <span>{product.parentId ? ("Variante auswählen") : "Wählen"}</span>}
                </button>
              </div>
            ) : null}
          </div>
        </a>
      </div>
    </>
  );
}

'use client';

import Image from "next/image";
import { useEffect, useState } from "react";
import useSWR from "swr";
import * as gtag from "utility/gtag";
import axiosInstance from "@/shopware/client";
//import { fbEvent } from '@netzkombyse/facebook-conversion-api-nextjs';

const fetcherFilter = (url, filter) =>
  axiosInstance.post(url, filter).then((res) => res.data);
const fetcherProduct = (url) => axiosInstance.post(url).then((res) => res.data);

import LoadingScreen from "@/components/LoadingScreen";
import Layout from "@/components/layout/templates/default";
import AdditionalInfos from "@/components/product/additional-infos";
import BuyForm from "@/components/product/buy-form";
import CrossSelling from "@/components/product/cross-selling";
import ProductInfos from "@/components/product/product-infos";
import Reviews from "@/components/product/reviews";
import Stars from "@/components/product/stars";
import Newsletter from "@/components/product/newsletter";
import Description from "@/components/product/description";
import { notFound } from "next/navigation";

const ProductDetail = ({
  productNumber,
  mainNavigation,
  footerNavigation,
  snippets,
}) => {
  const [isLoading, setIsLoading] = useState(true);
  const [eventViewItemIsFired, setEventFired] = useState(false);
  const [detail, setDetail] = useState(null);
  const [configurator, setConfigurator] = useState(null);
  const [productId, setProductId] = useState(null);
  const [showAdditionalInfos, setShowAdditionalInfos] = useState(false);

  const { data: detailData, error } = useSWR(
    productNumber ? `/product` : null,
    (url) =>
      fetcherFilter(url, {
        filter: [
          {
            type: "equals",
            field: "productNumber",
            value: productNumber,
          },
        ],
      })
  );

  const { data: productData, errorProductData } = useSWR(
    productId ? `/product/${productId}` : null,
    (url) => fetcherProduct(url)
  );

  useEffect(() => {
    if (detailData && detailData.elements.length > 0) {
      setProductId(detailData?.elements[0]?.id);
      Object.keys(detailData.elements[0].translated.customFields).map((key) =>
        key.indexOf("custom_netzkom_additional_product_infos") > -1
          ? setShowAdditionalInfos(true)
          : null
      );

      const dataLayer = {
        event: "view_item",
        ecommerce: {
          currency: "EUR",
          value: detailData.elements[0].calculatedPrice?.unitPrice,
          items: [
            {
              item_id: detailData.elements[0].productNumber,
              item_name: detailData.elements[0].translated.name,
              index: 0,
              item_brand: process.env.NEXT_PUBLIC_BRAND_NAME,
              item_category:
                detailData.elements[0].seoCategory?.translated.name,
              price: detailData.elements[0].calculatedPrice?.unitPrice,
              quantity: 1,
            },
          ],
        },
      };
      if (eventViewItemIsFired === false) {
        gtag.dataLayer(dataLayer);
        setEventFired(true);
      }
    } else {
      //notFound();
    }
  }, [detailData, eventViewItemIsFired]);

  useEffect(() => {
    if (productData) {
      setDetail(productData.product);
      setConfigurator(productData.configurator);

      setIsLoading(false);
    }
  }, [productData]);

  useEffect(() => {
    if (detailData) {
      /*
      fbEvent({
        eventName: 'ViewContent',
        currency: 'EUR',
        products: {
          sku: detailData.elements[0].productNumber,
          quantity: 1
        },
        value: detailData.elements[0].calculatedPrice?.unitPrice,
        enableStandardPixel: true,
        testEventCode: process.env.NEXT_PUBLIC_FB_TEST_EVENT_CODE
      });*/
    }
  }, [detailData]);

  if (error || errorProductData) {
    {console.log('error',error)}
    {console.log('errorProductData',errorProductData)}
    return(
        notFound()
    )
  }

  return detail && (
    <Layout
      mainNavigation={mainNavigation}
      footerNavigation={footerNavigation}
      snippets={snippets}
    >
      <div className="mx-auto max-w-7xl pt-0 md:pt-8 px-4 sm:px-6 lg:px-8 xl:px-0 mt-8 pb-8">
        <div className="lg:grid lg:grid-cols-2 lg:items-start lg:gap-x-8">
          <div className="relative   product-detail-description">
            <div className="relative">
              <div className="h-[230px] sm:h-[400px] md:h-[480px] lg:h-[310px] xl:h-[440px]">
                {detail.cover.media.thumbnails[2].width < 600 ? (
                  <Image
                    src={detail.cover.media.thumbnails[3].url}
                    alt={detail.cover.media.translated.title ? detail.cover.media.translated.title : 'product image'}
                    placeholder="blur"
                    blurDataURL={`${detail.cover.media.thumbnails[3].url}?auto=format,compress&q=1&blur=500&w=2`}
                    priority={true}
                    fill
                    sizes="100vw"
                    style={{
                      objectPosition: "center",
                      objectFit: "cover",
                    }}
                  />
                ) : (
                  <Image
                    src={detail.cover.media.thumbnails[2].url}
                    alt={detail.cover.media.translated.title ? detail.cover.media.translated.title : 'product image'}
                    placeholder="blur"
                    blurDataURL={`${detail.cover.media.thumbnails[2].url}?auto=format,compress&q=1&blur=500&w=2`}
                    priority={true}
                    fill
                    sizes="100vw"
                    style={{
                      objectPosition: "center",
                      objectFit: "cover",
                    }}
                  />
                )}
              </div>
            </div>

            <div className="mt-6 hidden lg:block">
              <div
                className="text-base text-neutral-700"
                dangerouslySetInnerHTML={{
                  __html: detail.translated?.description,
                }}
              />
            </div>
          </div>

          {/* Product info */}
          <div className="mt-6 lg:mt-0 relative  product-detail-buybox">
            <ProductInfos detail={detail} />

            <Stars ratingAverage={detail.ratingAverage} />

            <BuyForm
              detail={detail}
              configurator={configurator}
              setIsLoading={setIsLoading}
              setDetail={setDetail}
            />

            <Newsletter />

            <Description description={detail.translated?.description} />
          </div>
        </div>

        <AdditionalInfos
          showAdditionalInfos={showAdditionalInfos}
          detail={detail}
        />
        <CrossSelling product={detail} />
        <Reviews product={detail} />
      </div>
    </Layout>
  );
};

export default ProductDetail;

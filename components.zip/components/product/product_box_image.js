import Image from "next/image";

export default function ProductBoxImage(props) {
  if (props.product.cover != null) {
    const thumbnail =
      props.product.cover.media.thumbnails[1].width > 300
        ? props.product.cover.media.thumbnails[1]
        : props.product.cover.media.thumbnails[0];
    return (
      <Image
          className={"object-contain w-full"}
        src={thumbnail.url}
        alt={props.product.cover.media.alt ? props.product.cover.media.alt : props.product.translated.name}
        placeholder="blur"
        blurDataURL={`${thumbnail.url}?auto=format,compress&q=1&blur=500&w=2`}
        priority={true}
        width={thumbnail.width}
        height={thumbnail.height}
      />
    );
  } else {
    return (
      <Image
      className={"object-contain object-top w-full"}
        src="https://fakeimg.pl/356x219/e5e5e5/131313?text=Bild folgt&font=bebas"
        alt={props.product.translated.name}
        width={356}
        height={219}
      />
    );
  }
}

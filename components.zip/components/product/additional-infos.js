import { Disclosure } from "@headlessui/react";
import { ChevronDownIcon, ChevronUpIcon } from "@heroicons/react/20/solid";

const AdditionalInfos = ({ showAdditionalInfos, detail }) => {
  return (
    showAdditionalInfos && (
      <section aria-labelledby="details-heading" className="mt-6">
        <h2 id="details-heading" className="mb-2 h3">
          Zusätzliche Angaben
        </h2>
        <div className="lg:flex lg:flex-wrap lg:gap-4">
          {Object.keys(detail.translated?.customFields).map((key) =>
            key.indexOf("custom_netzkom_additional_product_infos") > -1 ? (
              <Disclosure as="div" key={key} className="flex-1">
                {({ open }) => (
                  <div>
                    <div>
                      <Disclosure.Button className="group relative flex w-full items-center justify-start py-3 text-left border-b mb-3">
                        <span className="mr-6 flex items-center">
                          {open ? (
                            <ChevronUpIcon
                              className="block h-6 w-6 text-blue-400 group-hover:text-blue-500"
                              aria-hidden="true"
                            />
                          ) : (
                            <ChevronDownIcon
                              className="block h-6 w-6 text-neutral-400 group-hover:text-neutral-500"
                              aria-hidden="true"
                            />
                          )}
                        </span>
                        <span
                          className={classNames(
                            open ? "text-blue-600" : "text-neutral-900",
                            "text-sm font-semibold group-hover:text-blue-500"
                          )}
                        >
                          {customFieldMapping[key]}
                        </span>
                      </Disclosure.Button>
                    </div>
                    <Disclosure.Panel as="div" className="prose prose-sm pb-6">
                      <div
                        dangerouslySetInnerHTML={{
                          __html: detail.translated?.customFields[key],
                        }}
                      ></div>
                    </Disclosure.Panel>
                  </div>
                )}
              </Disclosure>
            ) : null
          )}
        </div>
      </section>
    )
  );
};

export default AdditionalInfos;

function classNames(...classes) {
  return classes.filter(Boolean).join(" ");
}

const customFieldMapping = {
  custom_netzkom_additional_product_infos_ingredients: "Zutaten & Nährstoffe",
  custom_netzkom_additional_product_infos_recommendations:
    "Verzehrempfehlungen",
  custom_netzkom_additional_product_infos_eol: "Lagerung & Haltbarkeit",
};
